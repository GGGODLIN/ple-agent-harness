# Roof Deck Design Basis Report — DC-2 Helena Data Centre, Building A

## 1. Executive Summary

This report documents the structural design and cost optimization of the steel roof deck system for **Building A of the DC-2 Data Centre** in Lewis and Clark County, Montana (`240 ft × 180 ft` footprint, `43,200 sf` gross roof area, `42,192 sf` net deck area excluding framed openings). The roof framing consists of open-web steel joists (`24K7`) at `6 ft-0 in.` on centre spanning `30 ft-0 in.` between joist girders (`36G8N15K`), with **NORDECK 1.5B (`B-36`) wide-rib steel roof deck** (`Fy = 50 ksi`, `Fu = 65 ksi`) spanning continuously over at least three `6 ft-0 in.` joist bays.

Using a cell-by-cell finite-element and mixed-integer linear programming (MILP) optimization over the `40 × 30` grid of `6 ft × 6 ft` modules, the roof is partitioned into **5 zones (`Z1`–`Z5`)** composed of **14 non-overlapping rectangles** utilizing **2 available deck gages (`18 ga` and `22 ga`)** and **3 screw-fastened attachment patterns (`36/9` with `3` sidelap screws, `36/7` with `3` sidelap screws, and `36/4` with `2` sidelap screws)**. The design satisfies all 21 hard constraint families across all 10 scenarios (`S01`–`S10`) at a total installed cost of **$176,336.88** (`$4.18/sf` of net deck area).

---

## 2. Document Precedence & Resolution of Conflicts

Per **Transmittal `T-118` (`2026-08-01`)** and **Owner's Basis of Design `OBD-DC2-A Rev A` (`2026-07-31`, Section 9)**, the project documents contain deliberate historical revisions and interdisciplinary discrepancies that were resolved according to the mandatory order of precedence:

1. **Structural Design Criteria (`EOR-DC-RD-01 Rev 2`, `2026-07-31`) vs. Superseded `Rev 1` (`2026-04-14`)**:
   - `EOR-DC-RD-01 Rev 2` governs and supersedes `archive/EOR-DC-RD-01_Structural_Design_Criteria_Roof_Rev1.pdf`.
   - **Roof Live Load (`Clause 4.2`)**: Rev 2 mandates an unreduced roof live load `LR_PSF = 20 psf` per `UFC 3-301-01 Table E-1 Item 51` (`At = 18 sf <= 200 sf`, so `R1 = 1.0`, `R2 = 1.0`), superseding the erroneously reduced `12 psf` in Rev 1.
   - **Snow Drift Rules (`Clause 5.4`)**: Rev 2 requires evaluating **both leeward (`hd`) and windward (`0.75 hd`) snow drifts** in all four cardinal wind directions using the upwind roof fetch (`lu`, minimum `20 ft`) for rooftop penthouses, RTUs, equipment screens, and the `3.5 ft` perimeter parapet, superseding Rev 1's leeward-only rule.
   - **Effective Seismic Weight (`Clause 7.2`)**: Because the balanced flat-roof snow load `pf = 43.66 psf` exceeds `30 psf`, Rev 2 includes `20%` of `pf` (`8.732 psf`) in addition to the `18.0 psf` dead load, yielding `W_SEISMIC_PSF = 26.73 psf` (`1,154.82 kip` total) and `FPX_KIP = 195.43 kip` (superseding Rev 1's `18.0 psf` and `131.60 kip`).
   - **Diaphragm Deflection Limit (`Clause 9.2`)**: Rev 2 establishes an allowable in-plane diaphragm deflection of `1.60 in.` (superseding `1.40 in.` in Rev 1).
   - **Perimeter & Opening Attachment Rule (`Clause 10.4`)**: Rev 2 requires every zone touching the roof perimeter or a framed opening to use at least a `36/7` support fastener pattern and at least `3` sidelap connectors per span.

2. **3D Structural Model (`DC2-A-STR_Roof_Structure_Model_RevC.ifc`) & `A-201 Rev C` vs. Superseded `A-201 Rev B` & 2D CAD Simplifications**:
   - Per `OBD-DC2-A Rev A Section 9` and `DC2-A-STR_Model_Note.txt`, the 3D IFC model (`Rev C`, `2026-07-31`) is the authoritative geometric record of framing, openings, parapets, and rooftop obstructions.
   - **North Equipment Screen (`SCR-N`) Relocation**: In superseded `A-201 Rev B`, `SCR-N` was drawn at `y = 158 ft` (`22 ft` from Grid G) and `SCR-E` at `y = 18..138 ft`. In `A-201 Rev C`, `M-401 Rev C`, and the governing IFC model, `SCR-N` is located at **`y = 164.0 ft` (`16 ft` south of Grid G), `x = 18.0..222.0 ft`, height `6.0 ft`**, and `SCR-E` is at **`x = 216.0 ft` (`24 ft` west of Grid 9), `y = 24.0..144.0 ft`, height `7.0 ft`**.
   - **East Equipment Screen (`SCR-E`) Representation**: In `A-201 Rev C` and `M-401 Rev C`, `SCR-E` is plotted as a single zero-width line at `x = 216.0 ft`, whereas the governing IFC model and `Rooftop_Equipment_Schedule.xlsx` confirm it is a `7.0 ft` tall, `120 ft` long louvred screen producing significant East/West snow drifts (`pd = 100.54 psf` east leeward/windward drift and `98.17 psf` west windward drift).

3. **Site-Specific Ground Snow Load (`SNOW-2026-014`) vs. Single-Station & Archival Records**:
   - `SNOW-2026-014` (`2026-06-18`) establishes the governing 50-year MRI ground snow load **`PG_PSF = 63 psf`** at the `4,120 ft` site elevation in accordance with `UFC 3-301-01 Section 2-4.5` and `ASCE 7-22 Section 7.2`.
   - Raw low-elevation station observations (`Met_Station_Records_Canyon_Ferry.csv`, `34 psf` at `3,830 ft`) and archival calculations from another county (`Hall_A_Deck_Design_2019_Butte.pdf`, `41 psf` and discontinued Cascade `C-30` deck) do not govern.

4. **Site Seismic Hazard (`USGS_ASCE7-22_RC-III_SiteClass-D_46.6832_-111.9756.json`) vs. 2019 Preliminary File**:
   - The 2026 ASCE 7-22 Risk Category III Site Class D record (**`SDS = 0.44`**, **`SD1 = 0.24`**) governs over the preliminary 2019 ASCE 7-16 Risk Category II Site Class C record (`SDS = 0.407`).

5. **Mechanical Schedule Filtering & Procurement Stock Lead Times**:
   - In `Rooftop_Equipment_Schedule.xlsx`, rows for `DC1-RTU-11` and `DC1-EF-3` are explicitly designated `"DC-1 Building B (existing, not this project)"` and are excluded from Building A.
   - Per `OBD-DC2-A Section 5` (`9-week` maximum delivery allowance) and `Deck_Stock_Availability_2026-07.xlsx`, gages `22` (`2 weeks`), `20` (`3 weeks`), and `18` (`4 weeks`) are available ex-stock, whereas **`16 gage` (`14 weeks` mill rolling lead time) is disqualified**.

---

## 3. Gravity, Snow Drift, Wind Uplift & Seismic Design Basis

### 3.1 Canonical Design Basis Parameters (`DesignBasis` Sheet)

| Key | Value | Units / Notes | Governing Citation |
|---|---:|---|---|
| `PG_PSF` | `63` | psf (50-year MRI site ground snow load) | `SNOW-2026-014 Section 5`; `EOR-DC-RD-01 Rev 2 Clause 5.1` |
| `CE` | `0.90` | Windward exposure factor (Exposure C, unobstructed) | `EOR-DC-RD-01 Rev 2 Clause 5.1`; `ASCE 7-22 Table 7.3-1` |
| `CT` | `1.00` | Thermal factor (heated data hall) | `EOR-DC-RD-01 Rev 2 Clause 5.1`; `ASCE 7-22 Table 7.3-2` |
| `IS` | `1.10` | Snow importance factor (Risk Category III) | `EOR-DC-RD-01 Rev 2 Clause 5.1`; `ASCE 7-22 Table 1.5-2` |
| `PF_PSF` | `43.66` | psf (`0.7 * 0.90 * 1.00 * 1.10 * 63 = 43.659 -> 43.66`) | `EOR-DC-RD-01 Rev 2 Clause 5.1`; `ASCE 7-22 Eq. 7.3-1` |
| `GAMMA_PCF` | `22.19` | pcf (`min(30, 0.13 * 63 + 14) = 22.19`; `hb = 1.968 ft`) | `EOR-DC-RD-01 Rev 2 Clause 5.2`; `ASCE 7-22 Eq. 7.7-1` |
| `LR_PSF` | `20` | psf (unreduced for `At = 18 sf <= 200 sf`) | `EOR-DC-RD-01 Rev 2 Clause 4.2`; `UFC 3-301-01 Table E-1` |
| `QH_PSF` | `29.93` | psf (`0.00256 * 1.04 * 1.00 * 0.85 * 1.00 * 115^2`) | `EOR-DC-RD-01 Rev 2 Clause 6.1`; `ASCE 7-22 Eq. 26.10-1` |
| `A_ZONE_FT` | `12.8` | ft (`min(0.10 * 180, 0.40 * 32) = 12.8 ft`) | `EOR-DC-RD-01 Rev 2 Clause 6.2.1`; `ASCE 7-22 Ch. 30` |
| `SDS` | `0.44` | g (Site Class D, Risk Category III) | `USGS_ASCE7-22_RC-III_SiteClass-D`; `Clause 7.1` |
| `IE` | `1.25` | Seismic importance factor (Risk Category III) | `EOR-DC-RD-01 Rev 2 Clause 7.1`; `ASCE 7-22 Table 1.5-2` |
| `R` | `3.25` | Response modification factor (steel CBF not detailed) | `EOR-DC-RD-01 Rev 2 Clause 7.1` |
| `W_SEISMIC_PSF` | `26.73` | psf (`18.0 + 0.20 * 43.66 = 26.732 psf`) | `EOR-DC-RD-01 Rev 2 Clause 7.2`; `ASCE 7-22 Section 12.7.2` |
| `FPX_KIP` | `195.43` | kip (`Cs = 0.16923`, `W = 1,154.82 kip`) | `EOR-DC-RD-01 Rev 2 Clause 7.3` |
| `WIND_X_KIP` | `118.0` | kip (`0.6556 klf * 180 ft`) | `LAT-2026-003 Table 4-1` |
| `WIND_Y_KIP` | `152.0` | kip (`0.6333 klf * 240 ft`) | `LAT-2026-003 Table 4-1` |
| `DIAPHRAGM_CLASS` | `semi-rigid` | Required modeling & confirmed by `d_MDD / d_AD < 2.0` | `EOR-DC-RD-01 Rev 2 Clause 9.3`; `LAT-2026-003 Clause 3.3` |

### 3.2 Snow Drift Surcharges (`Drifts` Sheet & Scenarios `S02`–`S04`)

With `pg = 63 psf`, `pf = 43.66 psf`, `gamma = 22.19 pcf`, and balanced snow depth `hb = pf / gamma = 1.9676 ft`, leeward drift height is `hd = 0.43 * max(lu, 20)^(1/3) * (63 + 10)^(1/4) - 1.5`, and windward drift height is `0.75 * hd` using the upwind roof fetch `lu`:

1. **`MEP-PH-1` Face `W` (`x = 60.0 ft`, `y in [60, 120]`, `h = 12.0 ft`, `hc = 10.032 ft`, Scenario `S02`)**:
   - Leeward drift (east wind over the `120.0 ft` E-W length of `MEP-PH-1`) governs over windward drift (`60.0 ft` west fetch): `hd = 4.6995 ft <= hc`.
   - Peak surcharge: **`104.28 psf`** (`total snow = 147.94 psf`), width `w = 4 * hd = 18.80 ft`, extending from **`band_from_ft = 60.0`** to **`band_to_ft = 41.20`**.
2. **`SCR-N` Face `S` (`y = 164.0 ft`, `x in [18, 222]`, `h = 6.0 ft`, `hc = 4.032 ft`, Scenario `S04`)**:
   - Windward drift (south wind over the `164.0 ft` fetch from Grid A to `y = 164.0 ft`) governs over leeward drift (`lu = 20.0 ft` minimum screen fetch): `hd0 = 5.3806 ft`, `hd = 0.75 * 5.3806 = 4.0355 ft > hc = 4.0324 ft` (truncated at `hc`).
   - Peak surcharge: **`89.48 psf`** (`total snow = 133.14 psf`), width `w = 4 * hd^2 / hc = 16.15 ft`, extending from **`band_from_ft = 164.0`** to **`band_to_ft = 147.85`**.
3. **`PARAPET` Face `N` (`y = 180.0 ft`, `x in [0, 240]`, `h = 3.5 ft`, `hc = 1.532 ft`, Scenario `S03`)**:
   - Windward drift (south wind over `lu = 180.0 ft` N-S roof dimension): `hd0 = 5.5967 ft`, `hd = 0.75 * 5.5967 = 4.1975 ft > hc = 1.5324 ft` (truncated at `hc`, with `w = min(4 * hd^2 / hc, 8 * hc) = 8 * hc = 12.26 ft`).
   - Peak surcharge: **`34.01 psf`** (`total snow = 77.67 psf`), extending from **`band_from_ft = 180.0`** to **`band_to_ft = 167.74`**.
4. **`RTU-1` Face `E` (`x = 36.0 ft`, `y in [24, 32]`, `h = 7.0 ft`, `hc = 5.032 ft`, Scenario `S04`)**:
   - Windward drift (east wind over `lu = 240.0 - 36.0 = 204.0 ft` fetch from Grid 9 to `x = 36.0 ft`) governs over leeward drift (`lu = 20.0 ft`): `hd0 = 5.8990 ft`, `hd = 0.75 * 5.8990 = 4.4243 ft <= hc`.
   - Peak surcharge: **`98.17 psf`** (`total snow = 141.83 psf`), width `w = 4 * hd = 17.70 ft`, extending from **`band_from_ft = 36.0`** to **`band_to_ft = 53.70`**.

---

## 4. In-Plane Diaphragm Analysis & Classification

In accordance with `EOR-DC-RD-01 Rev 2 Section 9` and `LAT-2026-003 Sections 2–6`, the roof diaphragm was analyzed using a 2D plane-stress / truss-frame finite-element model over the `40 × 6` grid of `6 ft × 30 ft` joist-bay by girder-bay shear panels (`41 × 7 = 287` nodes, `574` DOFs):
- **Shear Panels (`40 × 6 = 240` panels)**: Each `6 ft × 30 ft` panel carries pure shear with effective stiffness `G'_{panel} = (1/5 * sum_{m=1}^5 1/G'_m)^(-1)` where the `5` stacked `6 ft × 6 ft` cells across the `30 ft` girder bay act in series under constant shear flow (`G'_{panel} = 0` for any panel containing a framed opening cell).
- **Framing Axial Bars**: Joist girders along `y = 0, 30, 60, 90, 120, 150, 180 ft` (`A_g = 5.40 in^2`), open-web joists along `x = 0, 6, ..., 240 ft` (`A_j = 1.65 in^2`), plus the continuous perimeter edge angle `L6x4x1/4` (`A_e = 2.56 in^2`) added to the four boundary lines (`A = 7.96 in^2` on `y = 0, 180 ft`; `A = 4.21 in^2` on `x = 0, 240 ft`), with `E = 29,500 ksi`.
- **Braced Frame Springs**: Each of the 8 perimeter concentrically braced frames is modeled as two translational springs of `0.5 * k_BF` at its two column nodes:
  - South wall (`y = 0`): `BF-X1` (`x = 30..60 ft`) and `BF-X2` (`x = 180..210 ft`), `k_BF = 55.0 kip/in.` each (`27.5 kip/in.` per node).
  - North wall (`y = 180`): `BF-X3` (`x = 60..90 ft`) and `BF-X4` (`x = 150..180 ft`), `k_BF = 18.0 kip/in.` each (`9.0 kip/in.` per node).
  - West wall (`x = 0`): `BF-Y1` (`y = 30..60 ft`) and `BF-Y2` (`y = 120..150 ft`), `k_BF = 22.0 kip/in.` each (`11.0 kip/in.` per node).
  - East wall (`x = 240`): `BF-Y3` (`y = 60..90 ft`) and `BF-Y4` (`y = 90..120 ft`), `k_BF = 68.0 kip/in.` each (`34.0 kip/in.` per node).

### Summary of Diaphragm Analysis Results (`Diaphragm` Sheet)

| Scenario | Direction | Max Shear (`plf`) | Max Deflection `d_MDD` (`in.`) | Avg Frame Disp `d_AD` (`in.`) | Ratio `d_MDD / d_AD` | Chord Force (`kip`) | Collector Force (`kip`) | Classification |
|---|---|---:|---:|---:|---:|---:|---:|---|
| `S05` (Wind X) | `X` | `341.8` | `0.430` | `0.957` | `0.449` | `9.16` | `14.39` | `semi-rigid` |
| `S06` (Wind Y) | `Y` | `776.0` | `0.842` | `1.075` | `0.783` | `23.42` | `16.27` | `semi-rigid` |
| `S07` (Seismic X) | `X` | `572.8` | `0.700` | `1.632` | `0.429` | `15.14` | `27.14` | `semi-rigid` |
| `S08` (Seismic Y) | `Y` | `1011.4` | `1.033` | `1.323` | `0.781` | `29.74` | `21.14` | `semi-rigid` |
| `S10` (Seismic X + `Omega_0`) | `X` | `572.8` | `0.700` | `1.632` | `0.429` | `15.14` | `54.28` | `semi-rigid` |

In all lateral scenarios:
- The stiffness ratio `d_MDD / d_AD` ranges from `0.429` to `0.783` (`< 2.0`), confirming **`semi-rigid`** behavior per `ASCE 7-22 Section 12.3.1.3` and `EOR-DC-RD-01 Rev 2 Clause 9.3`.
- Maximum diaphragm deflection is `1.033 in. <= 1.60 in.` (`Clause 9.2`).
- Maximum chord force (`29.74 kip`) and maximum collector force including `\Omega_0 = 2.0` amplification in `S10` (`54.28 kip`) are strictly below the **`55.0 kip`** splice capacity limit (`Clause 9.4`).

---

## 5. Zoning Decisions, What Drove Each Zone, & Cost Optimization

To minimize installed cost while respecting the constructability limits (`<= 2` gages, `<= 3` patterns, `<= 12` zones, `<= 14` rectangles on the `6 ft × 6 ft` grid) and boundary attachment rules (`>= 36/7` and `>= 3` sidelaps on all perimeter and opening-adjacent zones), the roof was partitioned into **5 zones (`14` rectangles)** covering all `1,172` deck cells (`42,192 sf`), leaving the `28` cells touched by `RO-1` (`[96, 108] × [48, 60]`), `RO-2` (`[132, 144] × [120, 132]`), and `RO-3` (`[180, 210] × [60, 84]`) completely open:

1. **Zone `Z1` (`18 gage`, `36/9` support screws, `3` sidelap screws/span; `2` rectangles, `8,640 sf`)**:
   - *Rectangles*: West perimeter strip `[0, 18] × [0, 180]` and East perimeter strip `[210, 240] × [0, 180]`.
   - *What drove it*:
     1. **Corner Wind Uplift (`S09`)**: Wind Zone 3 (`12.8 ft × 12.8 ft` at all four corners, touching the `18 ft × 18 ft` corner cell blocks) produces `101.2 psf` gross uplift (`94.90 psf` net uplift on 18 ga), which cannot be carried by 22 gage (`74.50 psf` max net capacity at `36/9`) or by 18 gage `36/7` (`93.14 psf` net capacity) and therefore requires **`18 gage` with `36/9`** (`119.75 psf` net capacity).
     2. **East Collector Bay Diaphragm Shear (`S08`) & `SCR-E` Snow Drift (`S04`)**: Because the East braced frames (`BF-Y3`, `BF-Y4`, `k_BF = 68 kip/in.` each) are `3.1×` stiffer than the West frames (`BF-Y1`, `BF-Y2`, `22 kip/in.`) and sit immediately east of the `30 ft × 20 ft` opening `RO-3` (`x = 180..210 ft`), the highest diaphragm shear on the roof (`1,011.4 plf` in `S08`) and the `SCR-E` east drift (`144.20 psf` snow, `157.20 psf` total load in `S04`) both occur in `x = 210..240 ft`. Running single full-height `18 ga 36/9` strips along `x = [0, 18]` and `x = [210, 240]` covers all four corners and the entire East high-shear/drift corridor using just 2 rectangles (`D/C = 0.895`, governed by `S08`).

2. **Zone `Z2` (`18 gage`, `36/7` support screws, `3` sidelap screws/span; `7` rectangles, `16,560 sf`)**:
   - *Rectangles*: Surround the snow-drift aprons of `MEP-PH-1` (`S02`), `SCR-N`, `SCR-E`, `RTU-1..4` (`S04`), and frame around openings `RO-1`, `RO-2`, and `RO-3`.
   - *What drove it*: Total gravity snow loads in these drift bands reach `154.83–160.94 psf` (exceeding the `106.0 psf` capacity of 22-gage deck and requiring `18 gage` at `177.0 psf` capacity). Because these rectangles border the framed openings `RO-1`, `RO-2`, and `RO-3`, `Clause 10.4` mandates at least `36/7` support attachment and `3` sidelap screws/span (`D/C = 0.909`, governed by `S02`).

3. **Zone `Z3` (`18 gage`, `36/4` support screws, `2` sidelap screws/span; `1` rectangle, `2,016 sf`)**:
   - *Rectangle*: `[42, 66] × [48, 132]` (west leeward snow-drift apron of `MEP-PH-1`).
   - *What drove it*: This band carries the peak `MEP-PH-1` west leeward drift (`160.94 psf` total gravity load in `S02`, requiring `18 gage`), but lies entirely in the roof interior (`>= 42 ft` from the roof perimeter, inside Wind Zone 1-prime with `26.00 psf` net uplift, and `>= 30 ft` from the nearest opening `RO-1`). Using `36/4` with `2` sidelap screws saves fastener cost AND reduces interior diaphragm shear stiffness (`G' = 27 kip/in.`), which moderates the X-direction seismic force transferred to the stiff South braced frames and keeps the `S10` amplified collector force (`54.28 kip`) below `55.0 kip` (`D/C = 0.909`, governed by `S02`).

4. **Zone `Z4` (`22 gage`, `36/9` support screws, `3` sidelap screws/span; `2` rectangles, `6,912 sf`)**:
   - *Rectangles*: South perimeter strip `[18, 210] × [0, 24]` (`4,608 sf`) and North perimeter strip `[18, 210] × [168, 180]` (`2,304 sf`).
   - *What drove it*: Outside the `18 ft` corners and inside the `3.5 ft` parapet drift / `RTU` drift skirts (`max total gravity load = 98.18 psf <= 106.0 psf`), **`22 gage` deck** satisfies all gravity strength, deflection (`L/240`), and bearing checks at `$1.37/sf` lower deck cost than 18 gage. However, because these strips lie within **Wind Zone 2** (`12.8 ft` edge strip, `74.20 psf` gross uplift, `68.71 psf` net uplift on 22 ga), `22 ga 36/7` (`57.94 psf` net capacity) is insufficient; upgrading to **`36/9` with `3` sidelap screws** provides `74.50 psf` net uplift capacity (`79.99 psf` gross) and `637.0 plf` shear capacity while satisfying `Clause 10.4` (`D/C = 0.926`, governed by `S04` / `S09`).

5. **Zone `Z5` (`22 gage`, `36/7` support screws, `3` sidelap screws/span; `2` rectangles, `8,856 sf`)**:
   - *Rectangles*: West interior field `[18, 42] × [48, 132]` (`2,016 sf`) and Central `MEP-PH-1` footprint `[66, 180] × [60, 120]` (`6,840 sf`).
   - *What drove it*: In the West interior field (outside the `41.20 ft` extent of the `MEP-PH-1` west drift) and beneath the `MEP-PH-1` enclosure footprint (`[66, 180] × [60, 120]`, where the `60..66 ft` west edge strip is kept in `Z2` to capture the west drift line at `x = 60 ft`), total gravity demand is at most `60.19 psf <= 106.0 psf`, enabling **`22 gage` deck**. Because `[66, 180] × [60, 120]` borders `RO-1`, `RO-2`, and `RO-3` (`Clause 10.4`) and `[18, 42] × [48, 132]` overlaps Wind Zone 1 (`41.81 psf` net uplift > `33.11 psf` capacity of `36/4`), **`36/7` with `3` sidelap screws** (`57.94 psf` net uplift capacity, `528.5 plf` shear capacity) is used (`D/C = 0.839`, governed by `S08`).

### Zone Verification & Bill of Materials Summary

| Zone | Gage | Pattern | Sidelap | Area (`sf`) | Gov. Scenario | Shear `D / C` (`plf`) | Gravity `D / C` (`psf`) | Net Uplift `D / C` (`psf`) | Max `D/C` |
|---|---:|---|---|---:|---|---:|---:|---:|---:|
| `Z1` | `18` | `36/9` | `screw × 3` | `8,640` | `S08` | `1011.4 / 1130.5` | `157.20 / 177.00` | `94.90 / 119.75` | `0.895` |
| `Z2` | `18` | `36/7` | `screw × 3` | `16,560` | `S02` | `648.8 / 938.0` | `160.94 / 177.00` | `67.90 / 93.14` | `0.909` |
| `Z3` | `18` | `36/4` | `screw × 2` | `2,016` | `S02` | `329.2 / 469.0` | `160.94 / 177.00` | `26.00 / 53.22` | `0.909` |
| `Z4` | `22` | `36/9` | `screw × 3` | `6,912` | `S04` | `570.9 / 637.0` | `98.18 / 106.00` | `68.71 / 74.50` | `0.926` |
| `Z5` | `22` | `36/7` | `screw × 3` | `8,856` | `S08` | `443.6 / 528.5` | `60.19 / 106.00` | `41.81 / 57.94` | `0.839` |

- **Deck Area `18 gage`**: `26,424 sf` × `$4.42/sf` = `$116,794.08`
- **Deck Area `22 gage`**: `15,768 sf` × `$3.05/sf` = `$48,092.40`
- **Support Fasteners (`#12-24` self-drilling screws)**: `17,800 ea` × `$0.48/ea` = `$8,544.00`
- **Sidelap Connectors (`#10-16` TEK screws)**: `6,920 ea` × `$0.42/ea` = `$2,906.40`
- **Total Installed Cost**: **`$176,336.88`**
