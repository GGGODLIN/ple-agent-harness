# CONTINUATION SHEET - AMENDMENT 0003

**WORK ORDER NO.:** 74213
**SOLICITATION NO.:** N40085-26-R-2041
**PROJECT TITLE:** Fleet Data Center Increment 2 — Bid Package 2 (BP-2: Central Utility Plant and Site Utilities)
**LOCATION:** Naval Support Activity Ventura Bay
**AMENDMENT NO.:** 0003
**DATE:** 14 September 2026

---

## PACKAGE BP-2: CENTRAL UTILITY PLANT AND SITE UTILITIES (SOLICITATION N40085-26-R-2041)

**CONTINUATION SHEET — AMENDMENT 0003**

### DRAWINGS:

**On NAVFAC Drawing No. 74213-GI001 (GI-001)**

ADD the two newly inserted sheets listed below to the DRAWING INDEX under their respective discipline designator (delivered with Amendment 0003):

* `S-201A` `74213-S201A` `BRACED BAY FRAMING ELEVATIONS` - ADDED SHEET
* `M-502A` `74213-M502A` `CHILLER PAD ANCHORAGE DETAILS` - ADDED SHEET

REPLACE the fourteen revised sheets listed below in the DRAWING INDEX under their respective discipline designator (delivered with Amendment 0003):

* `GI-001` `74213-GI001` `DRAWING INDEX` - REPLACED SHEET
* `C-101` `74213-C101` `SITE UTILITY PLAN` - REPLACED SHEET
* `S-101` `74213-S101` `CUP FOUNDATION PLAN` - REPLACED SHEET
* `S-102` `74213-S102` `CUP ROOF FRAMING PLAN` - REPLACED SHEET
* `S-301` `74213-S301` `CUP BUILDING SECTIONS` - REPLACED SHEET
* `S-502` `74213-S502` `FRAMING DETAILS` - REPLACED SHEET
* `M-101` `74213-M101` `CUP CHILLED WATER PLAN` - REPLACED SHEET
* `M-301` `74213-M301` `CHILLED WATER PLANT SECTIONS` - REPLACED SHEET
* `M-401` `74213-M401` `CHILLER BAY ENLARGED PLAN` - REPLACED SHEET
* `M-501` `74213-M501` `PIPING DETAILS` - REPLACED SHEET
* `M-502` `74213-M502` `EQUIPMENT ANCHORAGE DETAILS` - REPLACED SHEET
* `E-001` `74213-E001` `ELECTRICAL PANEL SCHEDULES` - REPLACED SHEET
* `E-101` `74213-E101` `CUP POWER PLAN` - REPLACED SHEET
* `E-501` `74213-E501` `ELECTRICAL DETAILS` - REPLACED SHEET

**On NAVFAC Drawing No. 74213-C101 (C-101)**

* View 1/C-101 Site Utility Plan: REVISE fire water main alignment and duct bank crossing vertical and horizontal separation callout to satisfy installation utility separation requirements (`EOR-2-009`).

**On NAVFAC Drawing No. 74213-S101 (S-101)**

* View 1/S-101 CUP Foundation Plan: REVISE anchor rod embedment callout and foundation plan note for assigned seismic design category (`EOR-2-001`); ADD elevation callout referencing newly added braced bay framing elevations sheet `S-201A` (`EOR-2-025`).

**On NAVFAC Drawing No. 74213-S102 (S-102)**

* View 1/S-102 CUP Roof Framing Plan: RE-ISSUE sheet coordinated with revised framing detail `A/S-502` and building cross-section view `1/S-301` (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-S201A (S-201A)**

* View 1/S-201A Braced Bay Framing Elevations: ADD new supplemental sheet showing braced bay framing elevations and brace work points called out from foundation plan `1/S-101` (`EOR-2-025`).

**On NAVFAC Drawing No. 74213-S301 (S-301)**

* View 1/S-301 CUP Building Sections: RE-ISSUE sheet coordinated with revised equipment anchorage and framing detail `A/S-502` (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-S502 (S-502)**

* Detail A/S-502 Framing Details: DELETE cast-in anchor from post-tensioned slab equipment anchorage detail and REPLACE with post-installed seismic anchor assembly (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-M101 (M-101)**

* View 1/M-101 CUP Chilled Water Plan: REVISE chilled water supply main pipe size callout to match design pump head calculation and equipment schedule (`EOR-2-006`); RE-ISSUE plan coordinated with enlarged plan `1/M-401`, piping detail `A/M-501`, and anchorage detail `A/M-502` (`EOR-2-004`, `EOR-2-023`).

**On NAVFAC Drawing No. 74213-M301 (M-301)**

* View 2/M-301 Condenser Water Header Section: REVISE chiller outline from solid line to phantom line for section clarity (`EOR-2-031`).

**On NAVFAC Drawing No. 74213-M401 (M-401)**

* View 1/M-401 Chiller Bay Enlarged Plan: ADD detail callout referencing new mechanical details sheet `M-502A` for added chiller housekeeping pad anchorage (`EOR-2-023`), and RE-ISSUE coordinated with `A/M-501` and `A/M-502` (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-M501 (M-501)**

* Detail A/M-501 Chiller Pipe Support Detail: RE-ISSUE detail coordinated with revised structural anchorage detail `A/S-502` (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-M502 (M-502)**

* Detail A/M-502 Chiller Frame Anchorage Detail: RE-ISSUE detail coordinated with revised structural anchorage detail `A/S-502` (`EOR-2-004`).

**On NAVFAC Drawing No. 74213-M502A (M-502A)**

* Detail A/M-502A Chiller Pad Anchorage Details: ADD new supplemental mechanical details sheet carrying anchorage details for the two added chiller housekeeping pads called out from `1/M-401` (`EOR-2-023`).

**On NAVFAC Drawing No. 74213-E001 (E-001)**

* View 1/E-001 Electrical Panel Schedules: REVISE panel schedule column sequence for consistency across electrical schedules (`EOR-2-013`).

**On NAVFAC Drawing No. 74213-E101 (E-101)**

* View 1/E-101 CUP Power Plan: RELOCATE feeder tag leaders to the load side of each disconnect (`EOR-2-029`) and RE-ISSUE plan coordinated with `1/M-401` and `A/E-501` (`EOR-2-004`, `EOR-2-023`).

**On NAVFAC Drawing No. 74213-E501 (E-501)**

* Detail A/E-501 Conduit and Equipment Pad Termination Detail: RE-ISSUE detail coordinated with revised structural anchorage detail `A/S-502` (`EOR-2-004`).

---

### SPECIFICATIONS:

#### DOCUMENT 00 01 15 LIST OF DRAWINGS (SECTION 00 01 15 LIST OF DRAWINGS)

**Contract Drawings List**

ADD the two newly inserted sheets listed below (delivered with Amendment 0003):

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
| :--- | :--- | :--- | :--- |
| `S-201A` | `-` | `74213-S201A` | `BRACED BAY FRAMING ELEVATIONS` |
| `M-502A` | `-` | `74213-M502A` | `CHILLER PAD ANCHORAGE DETAILS` |

DELETE and REPLACE the fourteen revised sheets listed below as of 14 September 2026 (`SEP 2026`, delivered with Amendment 0003):

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
| :--- | :--- | :--- | :--- |
| `GI-001` | `3` | `74213-GI001` | `DRAWING INDEX` |
| `C-101` | `3` | `74213-C101` | `SITE UTILITY PLAN` |
| `S-101` | `3` | `74213-S101` | `CUP FOUNDATION PLAN` |
| `S-102` | `3` | `74213-S102` | `CUP ROOF FRAMING PLAN` |
| `S-301` | `3` | `74213-S301` | `CUP BUILDING SECTIONS` |
| `S-502` | `3` | `74213-S502` | `FRAMING DETAILS` |
| `M-101` | `3` | `74213-M101` | `CUP CHILLED WATER PLAN` |
| `M-301` | `3` | `74213-M301` | `CHILLED WATER PLANT SECTIONS` |
| `M-401` | `3` | `74213-M401` | `CHILLER BAY ENLARGED PLAN` |
| `M-501` | `3` | `74213-M501` | `PIPING DETAILS` |
| `M-502` | `3` | `74213-M502` | `EQUIPMENT ANCHORAGE DETAILS` |
| `E-001` | `3` | `74213-E001` | `ELECTRICAL PANEL SCHEDULES` |
| `E-101` | `3` | `74213-E101` | `CUP POWER PLAN` |
| `E-501` | `3` | `74213-E501` | `ELECTRICAL DETAILS` |

--End of Amendment--

---

## PACKAGE BP-3: DATA HALL 210 SHELL AND INTERIORS (SOLICITATION N40085-26-R-3018)

**STATEMENT OF ISSUE STATE (NO SOLICITATION AMENDMENT CONTINUATION SHEET REQUIRED):**

Bid Package 3 (`BP-3`, Solicitation `N40085-26-R-3018`) has not yet been advertised; per the controlling Contracting Officer memorandum dated 26 August 2026 (`co_memo_change_numbers_and_issue.docx`, paragraph 3), `BP-3` is scheduled to advertise on 9 November 2026 (`2026-11-09`, superseding the earlier `2026-10-12` date in `solicitation_schedule.csv`), with bid opening scheduled for 12 November 2026 (`2026-11-12`). All accepted Engineer-of-Record review corrections for `BP-3` are incorporated directly into the final design drawing package prior to advertisement as a **Pre-Advertisement Re-Issue** (`PRE_ADVERTISEMENT_REISSUE`) finishing on 12 September 2026 (`2026-09-12`, 12 calendar days from the 31 August 2026 production start), well ahead of the 10 October 2026 (`2026-10-10`) controlling deadline set by the 30-calendar-day pre-advertisement review and backcheck window (`ER 415-1-11` paragraph `6.e.(2)` and `6.g`). Because `BP-3` corrections are incorporated before solicitation advertisement rather than issued as an Amendment to an advertised solicitation (`co_memo_change_numbers_and_issue.docx` paragraph 2 and `FC 1-300-09N` Section `18-1` and `18-5`), no change number is assigned and no Amendment Continuation Sheet is issued for `BP-3`.
