# DESIGN BASIS: WORK ORDER 74213 EOR REVIEW REVISIONS (BP-2 AND BP-3)

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 2,
      "revision_layers": [
        "Z-ANNO-REVC",
        "Z-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 1,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 19381.67,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 3360,
        "overflow_option_usd": 1760,
        "non_concurrence_usd": 2400,
        "delay_usd": 2740,
        "total_usd": 56841.67
      },
      "title_block_defects": [
        {
          "sheet": "E-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "S-301",
          "defect": "CHK_EQUALS_DRW"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [
        "Z-ANNO-REVC",
        "Z-ANNO-REVS"
      ],
      "n_bundles": 2,
      "production_days": 12,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 9600,
        "sheets_usd": 21253.2,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 46053.2
      },
      "title_block_defects": [
        {
          "sheet": "A-501",
          "defect": "CHK_EQUALS_DES"
        },
        {
          "sheet": "M-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N, Navy and Marine Corps Design Procedures (17 May 2024, Change 1, 17 April 2025)",
    "ERDC/ITL SR-24-3, A/E/C Computer-Aided Design (CAD) Standard: Release 6.2 (July 2024)",
    "ERDC/ITL SR-23-1, A/E/C Graphics Standard: Release 2.2 (August 2023)",
    "ERDC/ITL SR-21-6, Record Package Guidance: Best Practices (August 2021)",
    "ER 415-1-11, Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews (1 January 2013)",
    "ER 1165-2-217, Civil Works Review Policy (1 May 2021)",
    "ER 1110-1-8159, Engineering and Design: DrChecks (1 January 2015)",
    "48 CFR Part 36 (FAR 36.609-4) and 48 CFR 52.236-25 (FAR 52.236-25), Requirements for Registration of Designers"
  ],
  "rejected_standards": [
    "ERDC/ITL TR-12-6, A/E/C CAD Standard: Release 6.0 (August 2015) [aec_cad_standard_r6_0_tr_12_6_SUPERSEDED.pdf] - Superseded release; replaced by ERDC/ITL SR-24-3, A/E/C Computer-Aided Design (CAD) Standard, Release 6.2 (July 2024)",
    "UFC 1-300-09N, Unified Facilities Criteria: Design Procedures (25 May 2005, Change 7, 27 January 2010) [ufc_1_300_09n_2005_change7_CANCELLED.pdf] - Cancelled document; cancelled and replaced by FC 1-300-09N, Navy and Marine Corps Design Procedures (17 May 2024, Change 1, 17 April 2025)",
    "GSA PBS CAD Standards, Public Buildings Service CAD Standards (March 10, 2021) [gsa_pbs_cad_standard_2021_owner_legacy.pdf] - Another agency standard (General Services Administration legacy owner standard) not applicable to Department of the Navy / NAVFAC projects",
    "fire_protection_comment_log_BP-2.csv (Fire Protection Comment Log, BP-2) - Another discipline review record delivered under a separate A-E task order; filed for coordination only and excluded from BP-2 and BP-3 EOR revision scope",
    "sheet_index_export_BP-2_90pct_SUPERSEDED.xlsx and 60%/90% Superseded Submittal Prints (project/drawings/superseded/) - Superseded preliminary submittal files predating final design sheet renumbering; not the current contract issue",
    "55210_FY23CUP_M-501_RECORD.pdf and 55210_FY23CUP_S-501_RECORD.pdf (project/drawings/record_fy23/) - Record drawings from terminated prior FY23 contract N40085-23-R-2007 (work order 55210); reference material only"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-015",
      "reason": "Reviewer M. Delacroix is credentialed only for Fire Protection on the reviewer roster, not Mechanical."
    },
    {
      "comment_id": "EOR-2-017",
      "reason": "Author G. Halvorsen is not listed on the authorized Engineer-of-Record reviewer roster."
    },
    {
      "comment_id": "EOR-2-019",
      "reason": "The PDF markup annotation on S-501 lacks a creation or modification date and time stamp."
    },
    {
      "comment_id": "EOR-2-021",
      "reason": "The markup was placed on a superseded ninety-percent submittal print of S-102 rather than the current sheet."
    },
    {
      "comment_id": "EOR-2-027",
      "reason": "Reviewer K. Aoyama had an appointment expiration date of 2026-06-30 before the markup was created on 2026-08-17."
    },
    {
      "comment_id": "EOR-2-033",
      "reason": "This comment repeats an issue already elevated, resolved, and closed at the 60 percent review under CHK-2-07 without reopening."
    },
    {
      "comment_id": "EOR-3-012",
      "reason": "The markup was placed on a superseded sixty-percent submittal print of T-501 rather than the current sheet."
    },
    {
      "comment_id": "EOR-3-016",
      "reason": "Reviewer M. Delacroix is assigned to package BP-2 Fire Protection on the roster, not BP-3 Architectural."
    },
    {
      "comment_id": "EOR-3-018",
      "reason": "Reviewer P. Okonjo is assigned to package BP-2 Civil on the roster, not BP-3 Architectural."
    },
    {
      "comment_id": "EOR-3-020",
      "reason": "The PDF markup annotation on S-501 lacks a creation or modification date and time stamp."
    },
    {
      "comment_id": "EOR-3-022",
      "reason": "Author C. Ballantyne is not listed on the authorized Engineer-of-Record reviewer roster."
    },
    {
      "comment_id": "EOR-3-036",
      "reason": "This comment repeats an issue already elevated, resolved, and closed at the 60 percent review under CHK-3-07 without reopening."
    }
  ]
}
```

## (a) Resolution of the Revision-Graphics Layer Conflict

Two shipped standards specify different layer names for revision clouds and revision symbols/entries:

1. **`FC 1-300-09N` (`Navy and Marine Corps Design Procedures`, 17 May 2024, Change 1, 17 April 2025), paragraph `12-3.6.1` (`Record Drawing Preparation`, page 102 / PDF page 124)** directs AutoCAD users to place revision clouds on layer **`Z-ANNO-REVC`** and to place revision symbols, notes, and Revision (Issue) block entries on layer **`Z-ANNO-REVS`**.
2. **`ERDC/ITL SR-24-3` (`A/E/C Computer-Aided Design (CAD) Standard: Release 6.2`, July 2024), Section `4.2.1` (`General Levels/Layers`, page 34) and `Appendix` (`Model File Level/Layer Assignment Tables`, page A3)** — as well as **`ERDC/ITL SR-21-6` (`Record Package Guidance: Best Practices`, August 2021), Section `3` (page 12)** — assign revision clouds to general annotation layer **`G-ANNO-REVC`** and revision indicators and text to **`G-ANNO-REVS`**.

This conflict is settled by **`FC 1-300-09N` paragraph `12-3.3.4` (`CAD Standards`, page 95 / PDF page 117)**, which establishes the mandatory order of precedence for CAD requirements on Navy and Marine Corps projects: first, the requirements of `FC 1-300-09N` Chapter 12; second, the latest versions of the DoD A/E/C CAD Standard (`ERDC/ITL SR-24-3`) and A/E/C Graphics Standard (`ERDC/ITL SR-23-1`); and third, the United States National CAD Standard (NCS). Because `FC 1-300-09N` Chapter 12 holds first precedence under paragraph `12-3.3.4`, paragraph `12-3.6.1` governs over `ERDC/ITL SR-24-3` and `ERDC/ITL SR-21-6`, and the revision-graphics layers actually used are **`Z-ANNO-REVC`** and **`Z-ANNO-REVS`**.

---

## (b) Determination of BP-3 Issue State and Controlling Review Window

For Bid Package 3 (`BP-3: Data Hall 210 Shell and Interiors`, Solicitation `N40085-26-R-3018`), the earlier solicitation schedule export (`solicitation_schedule.csv`) listed a scheduled advertisement date of `2026-10-12` and a bid-opening date of `2026-11-12` (`12 November 2026`), whereas the later Contracting Officer memorandum dated 26 August 2026 (`co_memo_change_numbers_and_issue.docx`, paragraph 3) states that **`BP-3` is scheduled to advertise on 9 November 2026 (`2026-11-09`)**, with production starting on **31 August 2026 (`2026-08-31`)** (`co_memo_change_numbers_and_issue.docx` paragraph 5 and `production_rate_schedule.xlsx`). Where the scheduled advertisement date conflicts between the earlier schedule export and the later dated Contracting Officer memorandum, the memorandum controls (`2026-11-09`).

Under **`ER 415-1-11` (`Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews`, 1 January 2013), paragraph `6.e.(2)` and paragraph `6.g`**, final design review and backcheck incorporation into the solicitation documents before advertisement must be started and completed on a **30-calendar-day** window prior to the scheduled advertisement date; by contrast, **paragraph `6.e.(4)`** sets a **15-calendar-day** backcheck window prior to bid opening when corrections are issued after advertisement as a solicitation amendment (`FC 1-300-09N` Section `18-1`).

Because `BP-3` has not yet been advertised as of the `2026-08-31` production start, two issue states are lawfully available (`co_memo_change_numbers_and_issue.docx` paragraph 2):

1. **`PRE_ADVERTISEMENT_REISSUE`**: Incorporating the corrections into the certified design set before advertisement binds the **30-calendar-day** pre-advertisement window under `ER 415-1-11` paragraph `6.e.(2)` and `6.g`. Counting 30 calendar days before the controlling `2026-11-09` advertisement date establishes a controlling completion deadline of **10 October 2026 (`2026-10-10`)**, providing **40 available calendar days** from the `2026-08-31` production start. (Even against the superseded `2026-10-12` date in `solicitation_schedule.csv`, 30 calendar days prior is `2026-09-12`, or 12 available calendar days.) Our optimal `BP-3` plan re-issues `15` existing sheets and adds `2` new sheets (`17` sheets total -> `ceil(17 / 4) = 5` sheet-production days), packages them into `2` PDF bundles (`2 × 3 = 6` bundle days), and uses `1` documented non-concurrence (`EOR-3-030` -> `1` day), finishing in **`5 + 6 + 1 = 12` calendar days** on **12 September 2026 (`2026-09-12`)** with **`D = 0` delay days** (`$0` extension cost), `$0` revision-mark charges (`FC 1-300-09N` Section `18-5.1` and `ERDC/ITL SR-23-1` Section `7.1`), `$0` overflow charges, and a total cost of **`$46,053.20`**.
2. **`AMENDMENT`**: Advertising `BP-3` without the corrections and issuing them afterward as Amendment `0001` (`co_memo_change_numbers_and_issue.docx` paragraph 2) would bind the **15-calendar-day** pre-bid-opening window under `ER 415-1-11` paragraph `6.e.(4)` (deadline `2026-10-28` prior to `2026-11-12` bid opening, 58 available days, also `D = 0` delay days), but would add `$240` per revised sheet in amendment revision-mark charges (`15 × $240 = $3,600`) plus Revision (Issue) block overflow charges on the three 8-row Architectural sheets (`A-001`, `A-101`, `A-301`), increasing total cost by at least `$4,480`.

Therefore, **`PRE_ADVERTISEMENT_REISSUE`** is chosen for `BP-3`, and the **30-calendar-day** window (`ER 415-1-11` paragraph `6.e.(2)` and `6.g`) is applied rather than the 15-calendar-day window (`paragraph 6.e.(4)`) because `BP-3` corrections are incorporated into the solicitation documents before advertisement rather than issued by post-advertisement amendment. (For `BP-2`, which was already advertised on `2026-07-06` with bid opening on `2026-09-28`, **`AMENDMENT`** with change number `0003` is the only lawful issue state under `FC 1-300-09N` Section `18-1` and `18-3`, so the **15-calendar-day** window prior to bid opening under `ER 415-1-11` paragraph `6.e.(4)` binds, setting a controlling deadline of `2026-09-13`, 13 calendar days from `2026-08-31`; our 14-day production plan finishes on `2026-09-14` with `D = 1` day of delay costing `2,600 × 1 + 140 × 1² = $2,740`.)

---

## (c) Revision (Issue) Block Overflow Decision for BP-2

Under **`ERDC/ITL SR-23-1` (`A/E/C Graphics Standard: Release 2.2`, August 2023), Section `7.3` (`Revision (Issue) Block`, pages 77–79 / PDF pages 85–87)**, the standard Revision (Issue) block has a capacity of **8 rows** (`ROW_POSITION` `1` at the lowest line to `8` at the top line). In `BP-2`, six of the fourteen re-issued existing sheets — **`C-101`, `S-101`, `S-102`, `S-502`, `M-101`, and `M-501`** — already carry **8 revision entries** (`Modifications A through F` from the prior contract plus `Amendments 1 and 2`), so adding the Amendment `0003` entry (`MARK = 3`, `DATE = SEP 2026`) overflows the 8-row block on those six sheets.

`ERDC/ITL SR-23-1` Section `7.3` defines two overflow options and expressly requires (page 79 Note) that **the chosen option remain consistent across the entire drawing set (applied set-wide rather than sheet by sheet)**:

* **Option 1 (Replace Oldest, `Figure 7-3`)**: Displace the oldest revision from row 1, shift the remaining seven entries down, place the newest revision at row 8, and copy each displaced revision entry outside the plotted area for record purposes. Per the published rate schedule (`production_rate_schedule.xlsx`), Option 1 costs **`$520` per revised sheet whose Revision (Issue) block is already full**, regardless of how many drawing blocks sit on the sheet. Applied set-wide across all 6 overflowing sheets in `BP-2`, Option 1 costs **`6 × $520 = $3,120`**.
* **Option 2 (Spill Above Row 8 into Drawing Area, `Figure 7-4`)**: Leave rows 1 through 8 intact and add the ninth revision entry directly above the eighth revision row (`ROW_POSITION = 9`), spilling into the Drawing Area. Per `production_rate_schedule.xlsx`, Option 2 costs **`$880` per revised sheet whose Revision (Issue) block is already full AND which carries three or more drawing blocks (views)** — where the spilled row requires re-layout of occupied drawing space — and **`$0` on a sheet with fewer than three drawing blocks**, where the spill area above the Revision (Issue) block is unoccupied. Among the 6 overflowing sheets in `BP-2`, four sheets (`C-101`, `S-101`, `S-102`, and `M-101`) carry only **1 drawing block** each (`$0` spill charge), and only two sheets (`S-502` with views `A, B, C` and `M-501` with views `A, B, C`) carry **3 drawing blocks** (`2 × $880 = $1,760`).

Because the overflow option must be applied **set-wide** across the entire package under `ERDC/ITL SR-23-1` Section `7.3`, **Option 2** is taken for `BP-2` at a total overflow cost of **`$1,760`**, and **Option 1** (`$3,120`) is rejected because it would cost the Government an additional **`$1,360`**.
