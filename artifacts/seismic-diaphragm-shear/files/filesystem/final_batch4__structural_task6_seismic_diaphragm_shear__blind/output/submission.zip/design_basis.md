# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

## 1. Seismic basis

Building B at the Continental Divide Data Center (Lewis and Clark County, Montana) is designed in accordance with the **2024 International Building Code (IBC)** as adopted by the Montana Department of Labor and Industry under **ARM 24.301.131**, and its referenced standards **ASCE/SEI 7-22**, **ACI 318-19**, **ANSI/AISC 360-22**, and **ANSI/AISI S310-20** (`SDC-02 Rev 2 Section 1`). All strength checks across concrete, structural steel, cold-formed steel deck diaphragm, panel joint connectors, and anchorage are performed consistently in **Load and Resistance Factor Design (LRFD)** format.

* **Risk Category and Importance Factor ($I_e$)**: Per the Owner's Basis of Design `OBD-CDDC-B Rev 4 Section 1.4` and `SDC-02 Rev 2 Section 2`, the east half of Building B houses the consolidated **911 emergency communications dispatch center** for Lewis and Clark County. Under **ASCE/SEI 7-22 Table 1.5-1, Section 11.5.1, and Table 1.5-2** (and `UFC 3-301-01 Table 2-2`), Building B is classified as **Risk Category III** with a seismic importance factor **$I_e = 1.25$** (superseding the Risk Category II note on `A-101 Rev 3` and the Building A summary `SM-2019-04`).
* **Site Class and Ground Motion Parameters ($S_{DS}, S_{D1}, \text{SDC}$)**: Per the 2026 Geotechnical Addendum `GEO-2026-071` (`Boring B-204` drilled within the Building B footprint), the measured harmonic-mean shear-wave velocity in the upper $100\text{ ft}$ of glacial till and alluvial gravel is $V_{s,100} = 905\text{ ft/s}$, which classifies the site as **Site Class D** under **ASCE/SEI 7-22 Chapter 20** (superseding the 2019 Parcel 4B report `GEO-2019-118` Site Class C). From the governing USGS design spectrum `USGS_ASCE7-22_RiskCatIII_SiteClassD_46.6832_-111.9756.json`:
  * $S_S = 0.55g$, $S_1 = 0.18g$, $S_{MS} = 0.66g$, $S_{M1} = 0.36g$
  * **$S_{DS} = \frac{2}{3} S_{MS} = 0.44g$**, **$S_{D1} = \frac{2}{3} S_{M1} = 0.24g$**
  * Under **ASCE/SEI 7-22 Section 11.6**, Table 11.6-1 yields SDC C ($0.33g \le S_{DS} < 0.50g$) and Table 11.6-2 yields **SDC D** ($S_{D1} = 0.24g \ge 0.20g$ in Risk Category III); the more severe classification governs, establishing **Seismic Design Category D**.
* **Fundamental Period and Seismic Response Coefficient ($C_s$)**:
  * Mean roof diaphragm height $h_n = 28.0\text{ ft}$ (total panel height $H = 31.0\text{ ft}$ including a $3.0\text{ ft}$ parapet cantilever).
  * Approximate fundamental period (**ASCE/SEI 7-22 Section 12.8.2.1, Eq. 12.8-7, Table 12.8-2** with $C_t = 0.020, x = 0.75$):
    $$T_a = 0.020 \times (28.0)^{0.75} = \mathbf{0.2435\text{ sec}}$$
  * Since $T = 0.2435\text{ sec} \le 0.5\text{ sec}$, the vertical distribution exponent is $k = 1.0$ (**ASCE/SEI 7-22 Section 12.8.3**), and for a single-storey building $C_{vx} = 1.0$.
  * Seismic response coefficient (**ASCE/SEI 7-22 Section 12.8.1.1, Eq. 12.8-2**):
    $$C_s = \frac{S_{DS}}{R / I_e} = \frac{0.44}{4.0 / 1.25} = \mathbf{0.1375}$$
    which governs within the upper limit $C_{s,\max} = \frac{S_{D1}}{T (R / I_e)} = \frac{0.24}{0.243513 \times 3.2} = 0.3080$ (**Eq. 12.8-3**) and the lower limit $C_{s,\min} = \max(0.044 S_{DS} I_e, 0.01) = \max(0.0242, 0.01) = 0.0242$ (**Eq. 12.8-5**).

## 2. Seismic force-resisting system

* **Selected SFRS**: **Intermediate Precast Shear Walls** (`"sfrs": "intermediate_precast"`), Bearing Wall System, per **ASCE/SEI 7-22 Table 12.2-1 Line A.10** (and `UFC 3-301-01 Table 3-1`) and **ACI 318-19 Section 18.5**:
  * Response Modification Coefficient: **$R = 4.0$**
  * System Overstrength Factor: **$\Omega_0 = 2.5$** (reduced by $0.5$ to **$\Omega_{0,\text{collector}} = 2.0$** for structures with flexible bare-steel-deck diaphragms per **ASCE/SEI 7-22 Table 12.2-1 Footnote b** and `UFC 3-301-01 Table 3-1 Footnote b`)
  * Deflection Amplification Factor: **$C_d = 4.0$**
* **Permissibility Clause in SDC D**: Under **ASCE/SEI 7-22 Table 12.2-1 Line A.10** (and Footnote e / `UFC 3-301-01 Table 3-1`), Intermediate precast shear walls are **Permitted in SDC D up to a structural height limit of $h_n \le 40\text{ ft}$**. Building B is a single-storey building with roof diaphragm elevation $h_n = 28.0\text{ ft} \le 40\text{ ft}$ (and total panel height $31.0\text{ ft} \le 40\text{ ft}$), satisfying the SDC D height limit with $12.0\text{ ft}$ of margin.
* **Why Intermediate Precast is the Cost-Efficient Choice**:
  1. **Ordinary precast shear walls ($R = 3.0$, Line A.11)** are **Not Permitted (`NP`) in SDC D** under **ASCE/SEI 7-22 Table 12.2-1**.
  2. **Special precast shear walls ($R = 5.0$, Line A.9, ACI 318-19 Section 18.5.2 & ACI ITG-5.2)** are permitted up to $160\text{ ft}$ in SDC D, but per `PROC-114 Rev 2 Section 2` and `RPC-CAT-2026 Rev 3 Table 1 & Section 3`, Special precast requires a wall panel detailing premium of **$\$4,120/\text{panel}$** ($\$325,480$ across 79 panels) plus cyclic-qualified dogbone connectors **`JC3` at $\$1,240/\text{ea}$** ($\$71,920$ at 1/joint), totaling **$\$397,400$** for the walls and joint connectors alone—which already exceeds the entire **$\$395,000$** project budget allowance before adding the roof deck, chords/collectors, base anchors, or wall anchors!
  3. **Intermediate precast shear walls ($R = 4.0$, ACI 318-19 Section 18.5)** carry a panel premium of **$\$1,850/\text{panel}$** ($\$146,150$ across 79 panels) and permit **`JC1` (`RPC-24`) ductile welded plate-and-bar connectors at $\$385/\text{ea}$** ($\$22,330$ at 1/joint across 58 joints), saving **$\$179,330$** on panel fabrication and **$\$49,590$** on joint connectors (**$\$228,920$ total direct savings**) while delivering a complete lateral system at **$\$345,859.20$** ($\$49,140.80$ under budget).

## 3. As-built geometry

Every discrepancy across the project documents was cross-checked against the 2026-08-07 interior LiDAR point cloud (`ScanB_2026-08-07_interior.ply`), the Surveyor's As-Built Field Note (`CDDC-SV-2026-041`), the Precast Erection Log (`ERL-2026-08_Erection_Log.csv`), approved `RFI-041`, and the Precast Shop Tickets (`PCS-014 Rev B`), and resolved per the project record hierarchy (`SDC-02 Rev 2 Section 4`):

| Conflict / Parameter | Superseded / Conflicting Reading | Governing Resolved Reading Used in Design | Governing Authority & Basis |
|---|---|---|---|
| **1. Risk Category & Importance Factor $I_e$** | Risk Category II, $I_e = 1.0$ (`A-101 Rev 3` note; `SM-2019-04` Building A; `USGS_ASCE7-16_RiskCatII_SiteClassC`) | **Risk Category III, $I_e = 1.25$** | `OBD-CDDC-B Rev 4 Sec. 1.4` (consolidated 911 emergency dispatch center in east half of Building B); `SDC-02 Rev 2 Sec. 2`; `ASCE 7-22 Table 1.5-1 & 1.5-2` |
| **2. Site Class & Ground Motion ($S_{DS}, S_{D1}, \text{SDC}$)** | Site Class C ($V_{s30} = 1,420\text{ ft/s}$), $S_{DS} = 0.33g$, $S_{D1} = 0.13g$, SDC C (`GEO-2019-118` Parcel 4B; `SM-2019-04`) | **Site Class D ($V_{s,100} = 905\text{ ft/s}$), $S_{DS} = 0.44g$, $S_{D1} = 0.24g$, SDC D** | `GEO-2026-071` Boring B-204 at Building B; `USGS_ASCE7-22_RiskCatIII_SiteClassD_46.6832_-111.9756.json`; `ASCE 7-22 Sec. 11.6 & Ch. 20` |
| **3. Governing Code Edition & Design Format** | 2018 IBC, ASCE 7-16, ACI 318-14, mixed ASD/LRFD (`SM-2019-04` Building A) | **2024 IBC (ARM 24.301.131), ASCE 7-22, ACI 318-19, AISC 360-22, AISI S310-20; 100% LRFD** | `SDC-02 Rev 2 Sec. 1`; Montana ARM 24.301.131 |
| **4. Precast SFRS & Collector $\Omega_0$** | Ordinary precast ($R = 3.0$, isolated piers `JC0`) in `SM-2019-04`; or nominal $\Omega_0 = 2.5$ | **Intermediate precast ($R = 4.0, C_d = 4.0$), $\Omega_{0,\text{collector}} = 2.0$** | `ASCE 7-22 Table 12.2-1 Line A.10 & Footnote b` ($\Omega_0$ reduced by 0.5 for flexible diaphragm); `SDC-02 Rev 2 Sec. 4 & 5` |
| **5. Wall S Doors `D-3, D-4` & Piers `S4, S5`** | `D-3`: $78..92'$ ($14'$); `S4`: $92..108'$ ($16'$); `D-4`: $108..122'$ ($14'$); `S5`: $122..138'$ ($16'$) (`A-101`, `S-201`, `PC-101`) | **`D-3`: $78.0..93.5'$ ($15.5'$); `S4`: $93.5..109.5'$ ($16.0'$); `D-4`: $109.5..123.5'$ ($14.0'$); `S5`: $123.5..138.0'$ ($14.5'$)** | `ScanB_2026-08-07_interior.ply`; `CDDC-SV-2026-041 Sec. 2`; `ERL-2026-08`; `PCS-014 Rev B` (shifted 1.5 ft east in field) |
| **6. Wall N Louver `L-2` & Piers `N4, N6`** | `N4`: $72..156'$ ($84'$); `L-2`: $156..168'$ ($12'\times 10'$); `N6`: $168..240'$ ($72'$) (`A-101`, `S-201`, `PC-101`, unrevised `PCS-014` table) | **`N4`: $72.0..154.0'$ ($82.0'$ pier); `N5 (L-2)`: $154.0..170.0'$ ($16.0'\times 10.0'$ spandrel); `N6`: $170.0..240.0'$ ($70.0'$ pier)** | `RFI-041` (approved $16'\times 10'$ louver for UPS cooling); `ScanB_2026-08-07_interior.ply`; `CDDC-SV-2026-041 Sec. 3`; `ERL-2026-08` |
| **7. Wall W Yard Opening `EY-1` & Pier `W3`** | `EY-1`: $66..106'$ ($40'$); `W3`: $106..180'$ ($74'$) (`A-101`, `S-201`, `PC-101`, `PCS-014`) | **`EY-1`: $66.0..110.0'$ ($44.0'$); `W3`: $110.0..180.0'$ ($70.0'$ pier)** | `ScanB_2026-08-07_interior.ply`; `CDDC-SV-2026-041 Sec. 4`; `ERL-2026-08` ($4\text{ ft}$ panel `W3-a` omitted for transformer rigging) |
| **8. Panel & Vertical Joint Counts** | 81 panels and 60 vertical joints (`PCS-014 Rev B` pre-erection shop ticket summary) | **79 erected panels and 58 vertical joints** (`S`: 19p/12j; `N`: 27p/21j; `W`: 14p/11j; `E`: 19p/14j) | `DAP-2 Rev 1 Sec. 2.1` subdivision rule applied to verified as-built geometry; confirmed by `ERL-2026-08` and `CDDC-SV-2026-041` |
| **9. RTU Weights & Future Expansion Units** | $6 \times 6.0\text{ k} = 36.0\text{ kips}$ (`A-101 Rev 3` note) | **Base (Phase 1): $45.00\text{ kips}$ (`RTU-1..6`); Future (Phase 2): $61.00\text{ kips}$ (adds `RTU-7F` $8\text{ k}$ & `RTU-8F` $8\text{ k}$)** | `M-601 Rev 3` Mechanical Schedule (Trane Voyager units); `SDC-02 Rev 2 Sec. 3 & Sec. 8` (Cases `S07..S11`) |
| **10. Tributary Wall Height & Parapet Inertia** | $h_{\text{trib}} = 28/2 = 14.0\text{ ft}$ ($1,400\text{ plf}$), neglecting parapet cantilever (`SM-2019-04`) | **$h_{\text{trib}} = \frac{31(15.5)}{28} = 17.1607\text{ ft}$ ($1,716.07\text{ plf}$ total; $316.07\text{ plf}$ parapet transfer above deck)** | `SDC-02 Rev 2 Sec. 6`; `FEMA P-2192-V1 Sec. 7.6.1 Step 1`; `DAP-2 Rev 1 Sec. 5` (openings not deducted) |

### Summary of Verified As-Built Piers and Spandrels (`as_built_piers`)
* **Wall S ($Y = 0\text{ ft}, L = 240.0\text{ ft}$, 7 pier segments, 19 panels, 12 vertical joints)**:
  * `S1`: $0.0..18.0\text{ ft}$ ($18.0\text{ ft}$ pier, panels $10'+8'$, 1 joint)
  * `S2`: $32.0..48.0\text{ ft}$ ($16.0\text{ ft}$ pier, panels $10'+6'$, 1 joint)
  * `S3`: $62.0..78.0\text{ ft}$ ($16.0\text{ ft}$ pier, panels $10'+6'$, 1 joint)
  * `S4`: $93.5..109.5\text{ ft}$ ($16.0\text{ ft}$ pier, panels $10'+6'$, 1 joint)
  * `S5`: $123.5..138.0\text{ ft}$ ($14.5\text{ ft}$ pier, panels $10'+4.5'$, 1 joint)
  * `S6`: $152.0..196.0\text{ ft}$ ($44.0\text{ ft}$ pier, panels $10'+10'+10'+10'+4'$, 4 joints)
  * `S7`: $200.0..240.0\text{ ft}$ ($40.0\text{ ft}$ pier, panels $4\times 10'$, 3 joints)
* **Wall N ($Y = 180.0\text{ ft}, L = 240.0\text{ ft}$, 4 pier segments + 2 spandrels, 27 panels, 21 vertical joints)**:
  * `N1`: $0.0..24.0\text{ ft}$ ($24.0\text{ ft}$ pier, panels $10'+10'+4'$, 2 joints)
  * `N2`: $28.0..60.0\text{ ft}$ ($32.0\text{ ft}$ pier, panels $10'+10'+6'+6'$, 3 joints)
  * `N3`: $60.0..72.0\text{ ft}$ ($12.0\text{ ft}$ spandrel over $12'\times 10'$ louver `L-1`, solid height $18\text{ ft}$, panels $6'+6'$, 1 joint)
  * `N4`: $72.0..154.0\text{ ft}$ ($82.0\text{ ft}$ pier, panels $7\times 10'+6'+6'$, 8 joints)
  * `N5`: $154.0..170.0\text{ ft}$ ($16.0\text{ ft}$ spandrel over $16'\times 10'$ louver `L-2` per `RFI-041`, solid height $18\text{ ft}$, panels $10'+6'$, 1 joint)
  * `N6`: $170.0..240.0\text{ ft}$ ($70.0\text{ ft}$ pier, panels $7\times 10'$, 6 joints)
* **Wall W ($X = 0\text{ ft}, B = 180.0\text{ ft}$, 3 pier segments, 14 panels, 11 vertical joints)**:
  * `W1`: $0.0..12.0\text{ ft}$ ($12.0\text{ ft}$ pier, panels $6'+6'$, 1 joint)
  * `W2`: $16.0..66.0\text{ ft}$ ($50.0\text{ ft}$ pier, panels $5\times 10'$, 4 joints)
  * `W3`: $110.0..180.0\text{ ft}$ ($70.0\text{ ft}$ pier, panels $7\times 10'$, 6 joints)
* **Wall E ($X = 240.0\text{ ft}, B = 180.0\text{ ft}$, 4 pier segments + 1 spandrel, 19 panels, 14 vertical joints)**:
  * `E1`: $0.0..72.0\text{ ft}$ ($72.0\text{ ft}$ pier, panels $6\times 10'+6'+6'$, 7 joints)
  * `E2`: $86.0..108.0\text{ ft}$ ($22.0\text{ ft}$ pier, panels $10'+6'+6'$, 2 joints)
  * `E3`: $108.0..120.0\text{ ft}$ ($12.0\text{ ft}$ spandrel over $12'\times 10'$ louver `L-3`, solid height $18\text{ ft}$, panels $6'+6'$, 1 joint)
  * `E4`: $120.0..150.0\text{ ft}$ ($30.0\text{ ft}$ pier, panels $3\times 10'$, 2 joints)
  * `E5`: $154.0..180.0\text{ ft}$ ($26.0\text{ ft}$ pier, panels $10'+10'+6'$, 2 joints)

## 4. Analysis

The lateral load path is analyzed using the project's two-stage protocol (`DAP-2 Rev 1 Sections 2–6`) and checked across the **envelope of flexible, rigid, and semi-rigid idealizations** (`DAP-2 Rev 1 Section 6.3`, `SDC-02 Rev 2 Section 5`) and across all 32 design cases in the Cartesian product of direction ($X, Y$), accidental eccentricity ($\pm 0.05 L_{\perp}$), orthogonal loading ($100/0$ and $100/30$ per **ASCE/SEI 7-22 Section 12.5.4**), mass case (Base Phase 1 and Future Phase 2 RTUs), and construction stage (Final and Erection Case `S12`):

1. **Stage A — Coupled Precast Pier Stiffness and Internal Panel Demands (`DAP-2 Rev 1 Sections 2–3`)**:
   * Each $8\text{ in}$ normal-weight precast panel ($f'_c = 6{,}000\text{ psi}$, $E_c = 57\sqrt{6000} = 4{,}415.2\text{ ksi}$, $G_c = E_c / 2.4 = 1{,}839.7\text{ ksi}$ with $\nu = 0.20$) is modeled as a vertical cantilever of height $h = 28.0\text{ ft} = 336\text{ in}$ fixed against translation at the base with uncracked tip flexibility:
     $$f_i = \frac{h^3}{3 E_c I_i} + \frac{1.2 h}{G_c A_i}, \qquad I_i = \frac{t L_i^3}{12}, \qquad A_i = t L_i$$
   * For spandrel segments (`N3`, `N5`, `E3`) over $10\text{ ft}$ high louvers (`L-1`, `L-2`, `L-3`), the solid height is $H_{\text{solid}} = 28 - 10 = 18\text{ ft}$ and the flexibility is scaled by $H_{\text{total}}/H_{\text{solid}} = 28/18 = 1.5556$ (`DAP-2 Rev 1 Section 3`).
   * Adjacent panels $j$ and $j+1$ within a pier segment are coupled along their vertical joint by $n_c = 1$ `JC1` connector ($k_j = 210\text{ kip/in}$). Under a unit lateral displacement $\Delta = 1\text{ in}$ at roof level, compatibility of vertical slip $\delta_j = \frac{h}{2}(L_j \frac{V_j}{h E_c I_j/h^2} + L_{j+1} \dots)$ and panel equilibrium yield the coupled pier stiffness $k_{\text{seg}}$, the joint shear per unit segment force $V_{\text{joint}}/F_{\text{seg}}$, and the base tie-down tension per unit segment force:
     $$T_{i,\text{tiedown}} = \frac{M_{i,\text{base}}}{0.8 L_i} + N_{i,\text{base}}, \qquad M_{i,\text{base}} = V_i h - (N_{j} - N_{j-1})\frac{L_i}{2}$$
   * Resulting total in-plane wall stiffnesses with `1 x JC1` per joint: $k_S = 3{,}245.4\text{ kip/in}$, $k_N = 5{,}034.3\text{ kip/in}$, $k_W = 3{,}014.6\text{ kip/in}$, $k_E = 3{,}439.4\text{ kip/in}$.
2. **Stage B — 24 x 18 Bilinear Q4 Membrane Diaphragm FE Model (`DAP-2 Rev 1 Sections 4–6`)**:
   * The $240\text{ ft} \times 180\text{ ft}$ roof deck is discretized into a $24 \times 18$ mesh of $10\text{ ft} \times 10\text{ ft}$ four-node bilinear plane-stress membrane elements ($E_d t_d = 29{,}000 \times 0.060 = 1{,}740\text{ kip/in}$, Poisson ratio $0$, shear stiffness $G'$ from the assigned zone attachment pattern `P3/P4/P5`), with the $24$ elements in `RO-1` ($60'\times 40'$) and $16$ elements in `RO-2` ($80'\times 20'$) omitted ($392$ active elements $= 39{,}200\text{ ft}^2$ net deck area).
   * The 20 scheduled chord, collector, and roof-opening framing lines (`CH-S..OP-2E`) are modeled as two-node axial bar elements ($k_{\text{bar}} = E_s A / L$) attached to coincident membrane nodes, and the Stage A pier stiffnesses $k_{\text{seg}}$ are distributed to the perimeter nodes along each pier footprint.
   * All three diaphragm idealizations required by `DAP-2 Rev 1 Section 6.3` are solved and enveloped:
     1. **Flexible**: Simple-beam tributary shear distribution between perimeter wall lines (cantilevered from Wall W in Erection Case `S12`).
     2. **Rigid**: Stage B model with membrane stiffnesses multiplied by $10^7$, used both to obtain rigid-diaphragm wall/zone demands and to evaluate the torsional amplification factor $A_x = \min(\max[(\delta_{\max}/(1.2\delta_{\text{avg}}))^2, 1.0], 3.0)$ under **ASCE/SEI 7-22 Section 12.8.4.3 Eq. (12.8-14)** ($A_x = 1.0000$ across all cases `S01..S12`).
     3. **Semi-Rigid**: Stage B model with actual bare-deck shear stiffnesses $G'$ (`38.0`, `49.0`, `61.0 kip/in`), used for the envelope of member/wall/zone forces and for checking the design diaphragm deflection $\delta_{\text{design}} = C_d \delta_{\text{Stage B}} / I_e \le 4.00\text{ in}$ (`SDC-02 Rev 2 Section 7`).

## 5. Diaphragm and wall forces

### Diaphragm Seismic Weights and Distributed Forces (**ASCE/SEI 7-22 Section 12.10.1.1**)
* **E-W Loading ($X$-Direction, Span $L = 180.0\text{ ft}$ between Walls S and N)**:
  * **Base (Cases `S01, S02, S05`)**: $w_{px,X} = 784.00\text{ (roof)} + 45.00\text{ (Phase 1 RTUs)} + 617.79\text{ (Walls W \& E)} = \mathbf{1{,}446.79\text{ kips}}$; $F_{px,X} = 0.1375 \times 1{,}446.79 = \mathbf{198.93\text{ kips}}$ ($F_{px,\min} = 159.15\text{ k}$, $F_{px,\max} = 318.29\text{ k}$); average distributed force $w_{px,X} = 198{,}933 / 180 = \mathbf{1{,}105.18\text{ plf}}$.
  * **Future (Cases `S07, S09`)**: $w_{px,X} = 1{,}446.79 + 16.00 = \mathbf{1{,}462.79\text{ kips}}$; $F_{px,X} = \mathbf{201.13\text{ kips}}$; $w_{px,X} = \mathbf{1{,}117.41\text{ plf}}$.
* **N-S Loading ($Y$-Direction, Span $L = 240.0\text{ ft}$ between Walls W and E; $180.0\text{ ft}$ cantilever in `S12`)**:
  * **Base (Cases `S03, S04, S06`)**: $w_{px,Y} = 784.00\text{ (roof)} + 45.00\text{ (Phase 1 RTUs)} + 823.71\text{ (Walls S \& N)} = \mathbf{1{,}652.71\text{ kips}}$; $F_{px,Y} = 0.1375 \times 1{,}652.71 = \mathbf{227.25\text{ kips}}$ ($F_{px,\min} = 181.80\text{ k}$, $F_{px,\max} = 363.60\text{ k}$); average distributed force $w_{px,Y} = 227{,}248 / 240 = \mathbf{946.87\text{ plf}}$.
  * **Future (Cases `S08, S10, S11`)**: $w_{px,Y} = 1{,}652.71 + 16.00 = \mathbf{1{,}668.71\text{ kips}}$; $F_{px,Y} = \mathbf{229.45\text{ kips}}$; $w_{px,Y} = \mathbf{956.03\text{ plf}}$.
  * **Erection Stage (Case `S12`, $X \in [0, 180\text{ ft}]$, $0.5 C_s = 0.06875$)**: $w_{px,Y,\text{erect}} = 568.00 + 39.00 + 617.79 = \mathbf{1{,}224.79\text{ kips}}$; $F_{px,Y,\text{erect}} = \mathbf{84.20\text{ kips}}$; $w_{px,Y,\text{erect}} = \mathbf{467.80\text{ plf}}$.

### Design Wall Forces and Maximum Diaphragm Unit Shears Across All Design Cases (`S01..S12` & 32-Case Envelope)

| Case | Direction & Stage | Eccentricity & Mass | Wall S ($F_x$, kips) | Wall N ($F_x$, kips) | Wall W ($F_x$, kips) | Wall E ($F_x$, kips) | $A_x$ | Max Zone Unit Shear $v_{u,\max}$ (plf) |
|---|---|---|---:|---:|---:|---:|---:|---:|
| **S01** | $X$ (Final) | $+0.05$, Base | 98.41 | 116.38 | 4.68 | 4.68 | 1.0000 | 500.7 |
| **S02** | $X$ (Final) | $-0.05$, Base | 109.93 | 108.32 | 13.49 | 13.49 | 1.0000 | 477.0 |
| **S03** | $Y$ (Final) | $+0.05$, Base | 2.34 | 2.34 | 113.17 | 126.39 | 1.0000 | 783.0 |
| **S04** | $Y$ (Final) | $-0.05$, Base | 10.03 | 10.03 | 124.93 | 114.08 | 1.0000 | 786.6 |
| **S05** | $X + 0.3Y$ (Final) | $+0.05$, Base | 99.11 | 117.09 | 38.63 | 42.59 | 1.0000 | 720.4 |
| **S06** | $Y + 0.3X$ (Final) | $-0.05$, Base | 43.01 | 42.53 | 128.98 | 118.13 | 1.0000 | 921.0 |
| **S07** | $X$ (Final) | $+0.05$, Future | 99.14 | 117.82 | 4.57 | 4.57 | 1.0000 | 507.7 |
| **S08** | $Y$ (Final) | $+0.05$, Future | 2.81 | 2.81 | 113.44 | 128.49 | 1.0000 | 788.3 |
| **S09** | $X + 0.3Y$ (Final) | $-0.05$, Future | 113.71 | 112.57 | 51.06 | 48.29 | 1.0000 | 688.4 |
| **S10** | $Y + 0.3X$ (Final) | $-0.05$, Future | 42.93 | 42.58 | 129.31 | 120.05 | 1.0000 | 925.0 |
| **S11** | $X$ (Erection $X\le 180'$) | $+0.05$, Erection ($0.5 C_s$) | 30.89 | 35.40 | 0.00 | 0.00 | 1.1050 | 212.2 |
| **S12** | $Y$ (Erection $X\le 180'$) | $-0.05$, Erection ($0.5 C_s$) | 37.43 | 37.43 | 84.20 | 0.00 | 1.0000 | 631.8 |
| **ENVELOPE** | **32-Case Full Envelope** | **All Combinations** | **113.71** | **118.66** | **129.31** | **129.86** | **1.0000** | **936.3** |

### Deck Attachment Zone Design (`BDS-2026 Rev 6 Table 4`, LRFD $\phi_d = 0.60$ per **ANSI/AISI S310-20**)
* **`Z1, Z5, Z12` $\rightarrow$ Pattern `P5`** ($36/7$ weld + teks @ $4\text{ in}$, $\phi S_n = 1{,}101.0\text{ plf}$, $G' = 61.0\text{ kip/in}$, $\$2.47/\text{ft}^2$): Max 32-case envelope unit shears are $v_{u,Z1} = 936.3\text{ plf}$ ($\text{util} = 0.850$), $v_{u,Z5} = 720.2\text{ plf}$ ($\text{util} = 0.654$, upgraded to `P5` to limit erection cantilever deflection in `S12`), and $v_{u,Z12} = 872.0\text{ plf}$ ($\text{util} = 0.792$).
* **`Z2, Z3, Z4, Z6, Z8, Z9, Z10` $\rightarrow$ Pattern `P4`** ($36/7$ weld + teks @ $6\text{ in}$, $\phi S_n = 852.0\text{ plf}$, $G' = 49.0\text{ kip/in}$, $\$1.93/\text{ft}^2$): Max 32-case envelope unit shears are $v_{u,Z2} = 528.8\text{ plf}$, $v_{u,Z3} = 469.1\text{ plf}$, $v_{u,Z4} = 805.5\text{ plf}$ ($\text{util} = 0.945$), $v_{u,Z6} = 450.7\text{ plf}$, $v_{u,Z8} = 722.9\text{ plf}$ ($\text{util} = 0.848$), $v_{u,Z9} = 777.5\text{ plf}$ ($\text{util} = 0.913$), and $v_{u,Z10} = 626.8\text{ plf}$.
* **`Z7, Z11` $\rightarrow$ Pattern `P3`** ($36/4$ weld + teks @ $6\text{ in}$, $\phi S_n = 663.0\text{ plf}$, $G' = 38.0\text{ kip/in}$, $\$1.52/\text{ft}^2$): Max 32-case envelope unit shears are $v_{u,Z7} = 525.8\text{ plf}$ ($\text{util} = 0.793$) and $v_{u,Z11} = 593.0\text{ plf}$ ($\text{util} = 0.894$).
* **Diaphragm Deflection Check (`SDC-02 Rev 2 Section 7`)**: Maximum amplified diaphragm deflection across all final-stage cases is $C_d \delta / I_e = \mathbf{2.94\text{ in}} \le 4.00\text{ in}$ ($\text{util} = 0.735$), and across the temporary erection stage (`S12` and 32-case erection envelope) is $C_d \delta / I_e = \mathbf{3.88\text{ in}} \le 4.00\text{ in}$ ($\text{util} = 0.969$).

### Chords, Collectors, and Opening Drag Struts (`PROC-114 Rev 2 Table 1`, **ASCE/SEI 7-22 Section 12.10.2.1**)
All 20 scheduled lines in `S-201 Rev 2` (`CH-S, CH-N, CH-W, CH-E, DR-S1, DR-S2, DR-N1, DR-N2, DR-W1, DR-W2, DR-E1, DR-E2, OP-1S, OP-1N, OP-1W, OP-1E, OP-2S, OP-2N, OP-2W, OP-2E`, total length $2{,}080\text{ lf}$) are assigned **`C1` (`L4x4x3/8`, $A = 2.86\text{ in}^2$, $F_y = 36\text{ ksi}$, LRFD $\phi P_n = 0.90 \times 36 \times 2.86 = 92.66\text{ kips}$)**:
* Maximum perimeter chord axial demand (unamplified): $T_{u,\max} = \mathbf{42.82\text{ kips}}$ on `CH-S` ($42.81\text{ kips}$ on `CH-N`, $20.61\text{ kips}$ on `CH-W`, $19.83\text{ kips}$ on `CH-E`) $\le 92.66\text{ kips}$ ($\text{util} = 0.462$).
* Maximum $\Omega_{0,\text{collector}} = 2.0$ amplified collector/drag-strut axial demand: $\Omega_0 P_{u,\max} = 2.0 \times 24.05 = \mathbf{48.10\text{ kips}}$ on `DR-W1/W2` ($45.81\text{ kips}$ on `DR-E1/E2`, $33.10\text{ kips}$ on `DR-N1/N2`, $30.04\text{ kips}$ on `DR-S1/S2`, $30.90\text{ kips}$ on `OP-1S/1N`, $20.60\text{ kips}$ on `OP-1W/1E`, $44.00\text{ kips}$ on `OP-2S/2N`, $11.00\text{ kips}$ on `OP-2W/2E`) $\le 92.66\text{ kips}$ ($\text{util} = 0.519$).

## 6. Wall anchorage and the parapet cantilever

* **Parapet Cantilever Transfer (`SDC-02 Rev 2 Section 6`, `FEMA P-2192-V1 Section 7.6.1 Step 1`)**:
  Each $8\text{ in}$ precast panel ($w = 100.0\text{ psf}$) has total height $H = 31.0\text{ ft}$, spans $h = 28.0\text{ ft}$ from foundation to roof deck, and cantilevers $3.0\text{ ft}$ above the roof deck to the top of the parapet. Taking moments of the uniform panel mass about the base hinge ($z = 0$) gives the effective tributary wall height delivered to the roof diaphragm:
  $$h_{\text{trib}} = \frac{H (H / 2)}{h} = \frac{31.0 \times 15.5}{28.0} = \frac{961}{56} = \mathbf{17.160714\text{ ft}} \implies w_p = 100.0 \times 17.160714 = \mathbf{1{,}716.07\text{ plf}}$$
  Compared to the $14.0\text{ ft}$ ($1{,}400.00\text{ plf}$) simple-span tributary height below the top of the roof deck, the portion of the wall weight delivered to the roof by the wall cantilevering above the top of deck is:
  $$w_{\text{parapet transfer}} = (17.160714 - 14.000000)\text{ ft} \times 100.0\text{ psf} = \mathbf{316.07\text{ plf}}$$
  (consisting of $300.00\text{ plf}$ direct parapet mass above $z = 28\text{ ft}$ plus $300 \times 1.5 / 28 = 16.07\text{ plf}$ overturning moment reaction at the roof line).
* **Out-of-Plane Wall Anchorage Force (**ASCE/SEI 7-22 Section 12.11.2.1, Eq. 12.11-1 & 12.11-2**, `UFC 3-301-01 Figure 3-1`)**:
  * Flexible diaphragm span between lateral walls is $L_f = 180\text{ ft}$ (E-W) and $L_f = 240\text{ ft}$ (N-S), giving the diaphragm amplification factor:
    $$k_a = 1.0 + \frac{L_f}{100} \le 2.0 \implies \mathbf{k_a = 2.0}\quad (\text{in both } X \text{ and } Y)$$
  * Out-of-plane wall anchorage design force per linear foot of wall on `S, N, W, E`:
    $$F_p = 0.4 S_{DS} k_a I_e w_p = 0.4 \times 0.44 \times 2.0 \times 1.25 \times 1{,}716.0714 = 0.440 \, w_p = \mathbf{755.07\text{ plf}}$$
    which exceeds the minimum $0.2 S_{DS} I_e w_p = 188.77\text{ plf}$.
* **Wall-to-Diaphragm Anchor Selection (`RPC-CAT-2026 Rev 3 Section 7 Table 3`)**:
  * **`WA1` (`3/4 in` threaded rod welded to joist seat + headed stud group, $T_n = 9.4\text{ kips}$, LRFD $\phi T_n = 0.75 \times 9.4 = 7.05\text{ kips}$, $\$96/\text{ea}$)** is installed at every open-web joist seat at **$s = 6.0\text{ ft}$ o.c.** around the $840\text{ ft}$ perimeter (`S-201 Rev 2 Note 1 & Note 4`, 140 anchors total):
    $$T_u = 6.0\text{ ft} \times 0.75507\text{ klf} = \mathbf{4.53\text{ kips}} \le \phi T_n = \mathbf{7.05\text{ kips}}\quad (\text{utilization} = 0.643)$$
* **Subdiaphragm Proportions and Unit Shear (**ASCE/SEI 7-22 Section 12.11.2.2.1**, `SDC-02 Rev 2 Section 6`)**:
  * Perimeter subdiaphragms along `S, N, W, E` are proportioned with **$\text{span } l_{\text{sub}} = 30.0\text{ ft}$** (matching the $30\text{ ft}$ main column grid lines `1..9` and `A..G` where continuous collector/tie members cross the building) and **$\text{depth } d_{\text{sub}} = 24.0\text{ ft}$** ($4 \times 6\text{ ft}$ joist spaces, clearing `RO-1` at $32\text{ ft}$ from Wall N and `RO-2` at $36\text{ ft}$ from Walls S and W):
    $$\text{Aspect Ratio} = \frac{l_{\text{sub}}}{d_{\text{sub}}} = \frac{30.0\text{ ft}}{24.0\text{ ft}} = \mathbf{1.25} \le 2.5\text{ maximum permitted}$$
  * Subdiaphragm unit shear demand:
    $$v_{\text{sub}} = \frac{F_p \, l_{\text{sub}}}{2 \, d_{\text{sub}}} = \frac{755.07 \times 30.0}{2 \times 24.0} = \mathbf{471.92\text{ plf}} \le \phi S_n \in [663.0, 1{,}101.0]\text{ plf}\quad (\text{max utilization} = 0.712 \text{ in } Z11)$$

## 7. Governing constraint per wall line

On all four exterior wall lines (`S`, `N`, `W`, `E`), the governing capacity check with the highest demand-to-capacity utilization ratio is **panel base tie-down overturning tension (`base_anchor`, `RPC-CAT-2026 Rev 3 Section 5 Table 2` / `ACI 318-19 Section 18.5 & Chapter 17` / `DAP-2 Rev 1 Section 2.3`)**, evaluated from the 32-case envelope of coupled Stage A + Stage B pier forces:

| Wall Line | Envelope Wall Load $F_x$ (kips) | Joint Connector (`1 x JC1`, $\phi V_n = 18.00\text{ k}$) | Base Tie-Down Anchor ($\phi T_n$) | Out-of-Plane Wall Anchor (`WA1 @ 6'`, $\phi T_n = 7.05\text{ k}$) | Concrete Panel In-Plane Shear (`ACI 318-19 11.5.4`) | Governing Constraint Family & Utilization |
|---|---:|---|---|---|---:|---|
| **Wall S** ($19$ panels, $12$ joints) | 113.71 | $V_u = 4.81\text{ k}$ ($\text{util} = 0.267$) | **`BA2` ($\phi T_n = 66.00\text{ k}$): $T_u = 48.71\text{ k}$ ($\text{util} = 0.738$)** | $T_u = 4.53\text{ k}$ ($\text{util} = 0.643$) | $\text{util} = 0.16$ | **`base_anchor` (`0.738` on Pier `S5` / `S2` $10\text{ ft}$ panel)** (`BA1` at $33.0\text{ k}$ fails!) |
| **Wall N** ($27$ panels, $21$ joints) | 118.66 | $V_u = 3.00\text{ k}$ ($\text{util} = 0.166$) | **`BA1` ($\phi T_n = 33.00\text{ k}$): $T_u = 29.17\text{ k}$ ($\text{util} = 0.884$)** | $T_u = 4.53\text{ k}$ ($\text{util} = 0.643$) | $\text{util} = 0.11$ | **`base_anchor` (`0.884` on Pier `N1` $10\text{ ft}$ panel)** |
| **Wall W** ($14$ panels, $11$ joints) | 129.31 | $V_u = 4.86\text{ k}$ ($\text{util} = 0.270$) | **`BA2` ($\phi T_n = 66.00\text{ k}$): $T_u = 48.22\text{ k}$ ($\text{util} = 0.731$)** | $T_u = 4.53\text{ k}$ ($\text{util} = 0.643$) | $\text{util} = 0.18$ | **`base_anchor` (`0.731` on Pier `W1` / `W2` $10\text{ ft}$ panel)** (`BA1` at $33.0\text{ k}$ fails!) |
| **Wall E** ($19$ panels, $14$ joints) | 129.86 | $V_u = 4.51\text{ k}$ ($\text{util} = 0.250$) | **`BA2` ($\phi T_n = 66.00\text{ k}$): $T_u = 44.19\text{ k}$ ($\text{util} = 0.670$)** | $T_u = 4.53\text{ k}$ ($\text{util} = 0.643$) | $\text{util} = 0.15$ | **`base_anchor` (`0.670` on Pier `E5` $10\text{ ft}$ panel)** (`BA1` at $33.0\text{ k}$ fails!) |

## 8. Cost

The total installed cost of the delegated lateral scope is computed directly from the unit price schedule in `PROC-114 Rev 2 Section 2`, `BDS-2026 Rev 6 Table 4`, and `RPC-CAT-2026 Rev 3 Tables 1–3`:

| Cost Category | Quantity & Basis | Unit Rate | Subtotal (USD) |
|---|---|---|---|
| **1. Precast Shear Wall System (`intermediate_precast`)** | $79\text{ as-built panels}$ (`S`: 19, `N`: 27, `W`: 14, `E`: 19) per `PROC-114 Rev 2 Sec. 2` | $\$1,850.00 / \text{panel}$ | **$\$146,150.00$** |
| **2. Roof Deck Attachment (`Z1..Z12`, $39,200\text{ ft}^2$ net)** | `P5` in `Z1, Z5, Z12` ($10,320\text{ ft}^2 \times \$2.47 = \$25,490.40$)<br>`P4` in `Z2, Z3, Z4, Z6, Z8, Z9, Z10` ($23,120\text{ ft}^2 \times \$1.93 = \$44,621.60$)<br>`P3` in `Z7, Z11` ($5,760\text{ ft}^2 \times \$1.52 = \$8,755.20$) | $\$2.47 / \text{ft}^2$ (`P5`)<br>$\$1.93 / \text{ft}^2$ (`P4`)<br>$\$1.52 / \text{ft}^2$ (`P3`) | **$\$78,867.20$** |
| **3. Chords, Collectors & Opening Framing (`C1`)** | All $20\text{ scheduled lines}$ (`CH-S..OP-2E` $= 840' + 840' + 400' = 2,080\text{ lf}$) of `C1` (`L4x4x3/8`) | $\$11.40 / \text{lf}$ | **$\$23,712.00$** |
| **4. Panel Vertical Joint Connectors (`JC1`, $1/\text{joint}$)** | $58\text{ as-built vertical joints}$ (`S`: 12, `N`: 21, `W`: 11, `E`: 14) $\times 1\text{ connector/joint}$ | $\$385.00 / \text{ea}$ | **$\$22,330.00$** |
| **5. Panel Base Tie-Downs (`BA2` on `S,W,E`; `BA1` on `N`)** | $52\text{ panels}$ on `S, W, E` $\times \$910.00$ (`BA2` $= \$47,320.00$)<br>$27\text{ panels}$ on `N` $\times \$520.00$ (`BA1` $= \$14,040.00$) | $\$910.00 / \text{panel}$ (`BA2`)<br>$\$520.00 / \text{panel}$ (`BA1`) | **$\$61,360.00$** |
| **6. Wall-to-Diaphragm Anchors (`WA1 @ 6.0 ft o.c.`)** | $840\text{ ft perimeter} / 6.0\text{ ft spacing} = 140\text{ joist-seat anchors}$ | $\$96.00 / \text{ea}$ | **$\$13,440.00$** |
| **Total Installed Cost (`installed_cost_usd`)** | **Complete Delegated Lateral Load Path Scope** | — | **$\$345,859.20$** |
| **Subcontract Budget Allowance (`PROC-114 Rev 2 Sec. 1`)** | **Commercial Allowance** | — | **$\$395,000.00$** |
| **Net Savings Against Budget** | **$12.44\%$ Under Budget** | — | **$+\$49,140.80$** |

## 9. Alternatives rejected

1. **Ordinary Precast Shear Walls ($R = 3.0$, isolated panel piers `JC0`, `SM-2019-04` Building A scheme)**:
   * *Why Rejected*: Although Ordinary precast costs $\$920/\text{panel}$ and omits vertical joint connectors, it is **Not Permitted (`NP`) in Seismic Design Category D** under **ASCE/SEI 7-22 Table 12.2-1 Line A.11** (and `UFC 3-301-01 Table 3-1`). Building B is in SDC D ($S_{DS} = 0.44g, S_{D1} = 0.24g$, Risk Category III, Site Class D), making Ordinary precast a code violation.
2. **Special Precast Shear Walls ($R = 5.0$, `JC3` dogbone connectors, `ACI 318-19 Section 18.5.2 & ACI ITG-5.2`)**:
   * *Why Rejected*: Special precast reduces $C_s$ by only $20\%$ (from $0.1375$ to $0.1100$), but increases the wall panel detailing premium from $\$1,850/\text{panel}$ to $\$4,120/\text{panel}$ ($+\$179,330$ across 79 panels) and requires `JC3` (`RPC-60D`) connectors at $\$1,240/\text{ea}$ instead of `JC1` at $\$385/\text{ea}$ (`RPC-CAT-2026 Rev 3 Section 3`, $+\$49,590$ at 1/joint). The wall and connector cost alone ($\$397,400$) exceeds the $\$395,000$ project budget allowance.
3. **More Than 1 Vertical Joint Connector per Joint ($2\text{ to }4 \times \text{JC1}$ or $\text{JC2}$)**:
   * *Why Rejected*: With $1\times \text{JC1}$ per joint ($\phi V_n = 18.00\text{ kips}$ LRFD), the maximum joint shear demand across all 58 joints and all 32 load cases is only $4.86\text{ kips}$ ($\text{utilization} = 0.270$). Increasing to $2\times \text{JC1}$ per joint adds $\$22,330$ in connector cost AND increases the coupling axial force $N_{i,\text{base}}$ transferred into the outer panels of each pier, which pushes Wall N's base tie-down tension above $33.0\text{ kips}$ (`BA1`) and forces an upgrade to `BA2` on Wall N ($+\$10,530$), wasting $\$32,860$ with zero structural benefit.
4. **Uniform `BA1` Base Tie-Downs on All Four Walls (or Uniform `BA2` on All Four Walls)**:
   * *Why Rejected*: Using `BA1` ($\phi T_n = 33.00\text{ kips}$) on Walls `S`, `W`, or `E` fails the overturning tie-down check ($T_u = 48.71\text{ kips}$ on `S`, $48.22\text{ kips}$ on `W`, and $44.19\text{ kips}$ on `E`). Conversely, using `BA2` ($\$910/\text{panel}$) on Wall `N` where the maximum tie-down demand is only $29.17\text{ kips} \le 33.00\text{ kips}$ (`BA1` at $\$520/\text{panel}$) would waste $27 \times (\$910 - \$520) = \$10,530$. Tailoring `BA1` to Wall `N` and `BA2` to Walls `S, W, E` satisfies all strength checks while saving $\$10,530$.
5. **Lighter Deck Attachment Patterns (`P1/P2/P3` in Perimeter/West Zones `Z1, Z5, Z12` or `Z2..Z10`)**:
   * *Why Rejected*: Using `P4` ($\phi S_n = 852.0\text{ plf}$) in `Z1` fails the 32-case envelope zone unit shear demand ($v_{u,Z1} = 936.3\text{ plf} > 852.0\text{ plf}$) caused by shear flow bypassing the skylight band `RO-2`, and using `P4` in `Z12` leaves insufficient margin when `Z11` is `P3` ($v_{u,Z12} = 872.0\text{ plf} > 852.0\text{ plf}$). Furthermore, downgrading the west/interior zones (`Z5` from `P5` to `P4` or `Z2, Z3, Z6, Z10` from `P4` to `P3`) reduces the diaphragm shear rigidity $G'$ in the western $180\text{ ft}$ of the roof and causes the temporary erection-stage cantilever deflection in Case `S12` ($C_d \delta / I_e$) to exceed the $4.00\text{ in}$ out-of-plane wall drift limit (`SDC-02 Rev 2 Section 7`).
6. **Heavier Chord/Collector Sections (`C2, C3, C4`) or Omitting Any of the 20 Scheduled Collector/Opening Lines (`C0`)**:
   * *Why Rejected*: Omitting any perimeter collector (`DR-*`) or opening drag strut (`OP-*`) violates `SDC-02 Rev 2 Section 5` and Peer Review Log `PR-07 Item 3`. Upgrading any line from `C1` (`L4x4x3/8`, $\phi P_n = 92.66\text{ kips}$, $\$11.40/\text{lf}$) to `C2` (`L6x4x1/2`, $\phi P_n = 153.90\text{ kips}$, $\$18.90/\text{lf}$) or `C3/C4` is unnecessary because the maximum chord demand ($42.82\text{ kips}$) and maximum $\Omega_0 = 2.0$ amplified collector demand ($48.10\text{ kips}$) are both well below `C1`'s $92.66\text{ kip}$ LRFD capacity ($\text{max utilization} = 0.519$).
7. **Heavier Wall-to-Diaphragm Anchors (`WA2` or `WA3`) or Wider Anchor Spacing ($> 6.0\text{ ft}$)**:
   * *Why Rejected*: Open-web joists bear on the precast walls at $6.0\text{ ft}$ o.c. (`S-201 Rev 2 Note 1 & Note 4`). At $s = 6.0\text{ ft}$, the out-of-plane wall anchor demand is $T_u = 6.0 \times 0.75507 = 4.53\text{ kips} \le \phi T_n = 7.05\text{ kips}$ for `WA1` ($\$96/\text{ea}$). Using `WA2` ($\$155/\text{ea}$) at $12\text{ ft}$ spacing ($T_u = 9.06\text{ kips} \le 12.15\text{ kips}$) would leave every second joist seat unanchored (`S-201 Note 4` requires anchorage at joist seats) and increase local subdiaphragm collection spans.
