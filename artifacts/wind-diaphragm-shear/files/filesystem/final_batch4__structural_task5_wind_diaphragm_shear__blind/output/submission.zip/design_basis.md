# Design Basis Narrative — Building A2 Roof Diaphragm and Perimeter Shear Walls

**Project:** Northern Divide Data Campus — Building A2, Lewis and Clark County, Montana  
**Package:** Delegated Lateral Design — Roof Deck Diaphragm, Chords, Collectors, Precast Shear Wall Piers, and Connections  
**Governing Criteria:** `EOR-NDDC-A2-S01` Revision 2 (14 August 2026) and `Spec 01 33 00` (14 August 2026)  
**Load Basis:** Allowable Stress Design (`ASD`, `0.6W` for wind effects; `0.6D + 0.6W` for precast panel overturning stability)

---

## 1. Design Basis Parameters (`Spec 01 33 00` Section 1.6 Table 1)

| item | value | source |
| --- | --- | --- |
| Kzt | 1.19 | TS-2026-02 Section 4; EOR-NDDC-A2-S01 Rev 2 Section 4.3 |
| Ke | 0.8671 | ALTA-2025-77 Section 1 (zg = 3940.0 ft); EOR-NDDC-A2-S01 Rev 2 Section 4.4 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 Rev 2 Section 4.2 (V = 115 mph, h = 28.00 ft, Kz = 0.9685, Kzt = 1.19, Kd = 0.85, Ke = 0.8671 -> 28.7458 psf) |
| screen_wall_top_ft | 36.00 | SR-2026-118 Section 5.2 (x = 96 ft to 168 ft on N1); NDDC-A2_Federated_Model_2026.ifc; A-101 Rev C |
| asbuilt_opening_panel | S14 | NDDC-A2_Federated_Model_2026.ifc (opening S14-O1 at station 194.50 to 202.50 ft); EOR-NDDC-A2-S01 Rev 2 Section 5.3 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Rev 2 Section 3.3 (0.6D + 0.6W for panel stability per Section 5.8) |
| omega_d | 2.35 | CDS-B36 Diaphragm Design Manual Note 2; EOR-NDDC-A2-S01 Rev 2 Section 7.2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid finite element analysis | EOR-NDDC-A2-S01 Rev 2 Section 9; NDDC-AHJ-014 Section 3 |
| mesh_level | L2 | EOR-NDDC-A2-S01 Rev 2 Sections 9.1 and 9.7 (H = 5.0 ft structured square mesh, 1584 elements) |

---

## 2. Governing Wind Scenario per Wall Line (`Spec 01 33 00` Section 1.6 Table 2)

| line | governing scenario |
| --- | --- |
| S | W05 |
| N1 | W01 |
| N2 | W01 |
| W | W07 |
| E | W03 |
| E2 | W07 |

*Note on Wall Line Governing Scenarios:* The table above identifies the governing wind scenario producing the maximum roof-level wind line load (`line_load_plf`) on each wall line (`S`: `W05` at `253.06 plf`; `N1`: `W01` at `321.78 plf`; `N2`: `W01` at `265.68 plf`; `W`: `W07` at `252.34 plf`; `E`: `W03` at `253.42 plf`; `E2`: `W07` at `263.98 plf`). For in-plane shear wall reactions (`reaction_kips`) and quarter-point diaphragm unit shears (`unit_shear_plf`), where walls resist loads parallel to their plane, the governing scenarios for the submitted design are summarized below:

| wall_line | governing_line_load_scenario | max_line_load_plf | governing_reaction_scenario | max_reaction_kips | governing_station_shear_scenario | max_station_shear_plf |
| --- | --- | --- | --- | --- | --- | --- |
| S | W05 | 253.06 | W07 | 34.225 | W06 | 216.28 |
| N1 | W01 | 321.78 | W06 | 12.154 | W08 | 192.24 |
| N2 | W01 | 265.68 | W04 | 19.263 | W04 | 184.68 |
| W | W07 | 252.34 | W01 | 47.204 | W09 | 319.99 |
| E | W03 | 253.42 | W10 | 23.622 | W02 | 248.94 |
| E2 | W07 | 263.98 | W01 | 44.190 | W01 | 589.36 |

---

## 3. Document Precedence and Governing Corpus (`T-204` & `EOR-NDDC-A2-S01` Rev 2 Section 12)

| role | document_id | status | notes |
| --- | --- | --- | --- |
| criteria | EOR-NDDC-A2-S01 (Rev 2, 2026-08-14) | governing | Supersedes Rev 0 (2024-05-03); mandates DIAPH-MT 1.0 semi-rigid FEA, 0.6W ASD reporting, f'c = 5000 psi |
| ahj | NDDC-AHJ-014 (2026-06-11) | governing | Sets Risk Category III, V = 115 mph, Exposure C, Kd = 0.85, semi-rigid analysis; supersedes 2024 pre-application memo |
| wind_study | WT-2026-07 (2026-07-22) & WT-2026-07_Cp_by_azimuth.csv | governing | Boundary-layer wind tunnel study for Building A2 as-built massing (512 taps, 8 azimuths, wall Cp and parapet GCpn) |
| topo_study | TS-2026-02 (2026-04-30) | governing | Site-specific topographic wind study establishing Kzt = 1.19 across the entire Building A2 footprint |
| survey | ALTA-2025-77 (2025-11-18) | governing | Establishes Building A2 finished floor elevation zg = 3940.0 ft NAVD 88 (BM-2 = 3941.02 ft) and Exposure C fetch |
| bim | NDDC-A2_Federated_Model_2026.ifc (2026-08-09) | governing | As-built federated BIM model governing panel extents, thicknesses, top elevations, and field-cut opening S14-O1 |
| scan | SR-2026-118 (2026-08-18) & Roof_Line_Scan_2026-08-14.ply | governing | Laser scan verifying roof deck at +28.00 ft, typical parapet at +31.00 ft, and north screen wall at +36.00 ft (x = 96 to 168 ft) |
| arch_plan | A-101 Rev C & A-301 Rev C (2026-06-05) | governing | As-built architectural roof plan and elevations including the 60 ft x 40 ft NE generator yard notch and north screen wall |
| framing_plan | S-201 Rev C (2026-06-19) | governing | Defines deck zones Z11..Z43, perimeter chords C-S..C-W, notch collectors K-N2/K-E2, and opening collectors O-S..O-E |
| joist_sched | SJ-201 (2026-06-19) | governing | 26K9 joists (A = 2.4 in2 @ 5 ft o.c., 4 ft o.c. in Z22) and W24x62 girders (A = 4.0 in2 @ 40 ft o.c.) |
| panel_elev | PC-S02 Rev 2 (2026-05-12) | governing | Reissued precast elevations showing fabrication openings (notes field-cut openings must be taken from 2026 IFC model) |
| panel_sched | PC-S01 (2024-11-08) | informational / superseded by BIM | 2024 fabrication schedule; superseded by 2026 IFC model and SR-2026-118 where top elevations or field openings differ |
| deck_manual | CDS-B36 (2026) | governing | Diaphragm design manual for 1-1/2 in wide-rib deck (omega_d = 2.35, 1.15 G' factor for 4 ft span in Z22) |
| chord_sched | KRS-CH (2026) | governing | ASTM A572 Gr 50 chord/collector plate catalog and ASD capacities ($2.85/lb installed) |
| conn_data | KRS-CN (2026-07-30) | governing | E1 embeds (4.20 kips ASD, $185/ea), B1 base connections (1.40 kip/ft ASD), T1 base tie-downs (88 kips ASD, $2,450/ea) |
| obd | OBD-NDDC-A2 Rev 3 (2026-07-02) | governing | Sets 0.55 in relative diaphragm deflection limit, max 4 distinct deck types, and $310,000 package cost cap |
| submittal_spec | Spec 01 33 00 (2026-08-14) & T-204 (2026-08-20) | governing | Submittal deliverables, units, coordinate convention, layer names, and transmittal status |
| ufc | UFC 3-301-01 (Change 6, 2026-01-30) | governing | Adopted by OBD/Criteria for Table 2-1 drift limits (h/400) and Table 2-2 Risk Category III classification |
| osha | 29 CFR 1926.704 & 29 CFR 1926.757 | governing | Precast concrete handling/bracing requirements and open-web steel joist erection/bridging rules |
| archive_criteria | EOR-NDDC-A2-S01 Rev 0 (2024-05-03) | superseded | Preliminary criteria (V = 105 mph, Kzt = 1.0, Ke = 1.0, flexible diaphragm, f'c = 4000 psi); not used |
| archive_arch | A-101 Rev A (2024-03-19) | superseded | Preliminary 240 ft x 180 ft rectangular roof plan prior to NE generator yard notch; not used |
| archive_precast | PC-S02 Rev 1 (2024-10-02) | superseded | Preliminary precast elevation showing unapproved shop opening in S14 at station 196 to 202 ft; not used |
| archive_bldg_a1 | HallB_Lateral_Study_2023.pdf (2023-09-14) | not_applicable | Lateral study for Building A1 (200 ft x 160 ft x 24 ft rectangle, V = 105 mph); not applicable to Building A2 |

---

## 4. Resolution of Conflicts Between Issued Documents

Every discrepancy between the 2023–2024 preliminary/fabrication documents and the 2026 as-built and governing documents was identified and resolved in accordance with Document Transmittal `T-204` and `EOR-NDDC-A2-S01` Rev 2:

1. **Structural Design Criteria Revision 2 (`2026-08-14`) vs. Revision 0 (`2024-05-03`, Superseded) and AHJ Pre-Application Memorandum:**
   - *Conflict:* `EOR-NDDC-A2-S01` Rev 0 (and the 2024 pre-application memorandum noted in `NDDC-AHJ-014` Section 4) specified Risk Category II, a basic wind speed of $V = 105\text{ mph}$, $K_{zt} = 1.00$, $K_e = 1.00$, precast concrete strength $f'_c = 4,000\text{ psi}$ ($E_c = 3,605\text{ ksi}$), pure flexural cantilever pier stiffness neglecting shear deformation, no parapet cantilever lever action above the roof deck, and a simple flexible-diaphragm tributary analysis.
   - *Resolution:* Per `T-204` Item 12 and `NDDC-AHJ-014` Sections 2–4, Rev 0 is superseded and archived. The design is governed by `EOR-NDDC-A2-S01` Rev 2 and `NDDC-AHJ-014`, which establish Risk Category III, $V = 115\text{ mph}$ (3-second gust), Exposure C, $K_d = 0.85$, $f'_c = 5,000\text{ psi}$ ($E_c = 4,030\text{ ksi}$, $G = 0.40 E_c = 1,612\text{ ksi}$), Timoshenko flexural-plus-shear cantilever pier stiffness, full parapet lever action ($z/h > 1$), and the `DIAPH-MT 1.0` 2D semi-rigid finite element procedure.

2. **Building A1 Lateral Study (`HallB_Lateral_Study_2023.pdf`) vs. Building A2 Wind Tunnel Study (`WT-2026-07`):**
   - *Conflict:* The project archive contains `HallB_Lateral_Study_2023.pdf` (14 September 2023), which evaluated a $200\text{ ft} \times 160\text{ ft} \times 24\text{ ft}$ rectangular building with a $2\text{ ft}$ parapet at $V = 105\text{ mph}$, $q_h = 18.9\text{ psf}$, and uniform `D22-36/4-2` deck.
   - *Resolution:* As stated on the face of `HallB_Lateral_Study_2023.pdf` and `T-204` Item 15, that study is for Building A1 and is not applicable to Building A2. Building A2 is designed using the site-specific boundary-layer wind tunnel study `WT-2026-07` and pressure coefficient dataset `WT-2026-07_Cp_by_azimuth.csv`.

3. **Topographic Factor $K_{zt}$ and Ground Elevation Factor $K_e$ (`TS-2026-02` and `ALTA-2025-77` vs. 2024 Assumptions):**
   - *Conflict:* Earlier 2024 work assumed flat-terrain sea-level defaults $K_{zt} = 1.00$ and $K_e = 1.00$.
   - *Resolution:* Per `TS-2026-02` Section 4 and `EOR-NDDC-A2-S01` Rev 2 Section 4.3, the governing escarpment speed-up factor $K_{zt} = 1.19$ is applied over the entire Building A2 footprint at all elevations and azimuths. Per `ALTA-2025-77` Section 1 and `EOR-NDDC-A2-S01` Rev 2 Section 4.4, Building A2 finished floor is at $z_g = 3,940.0\text{ ft}$ NAVD 88 (referenced to benchmark `BM-2` at $3,941.02\text{ ft}$), giving $K_e = \exp(-0.0000362 \times 3940.0) = 0.8671$. Combined with $V = 115\text{ mph}$ and $K_d = 0.85$, this yields velocity pressures $q_h = q(28.0\text{ ft}) = 28.75\text{ psf}$ ($28.7458\text{ psf}$), $q_p(31.0\text{ ft}) = 29.37\text{ psf}$ ($29.3684\text{ psf}$), and $q_p(36.0\text{ ft}) = 30.31\text{ psf}$ ($30.3076\text{ psf}$).

4. **As-Built Roof Plan Extents (`A-101` Rev C, `S-201` Rev C, and `2026 IFC Model` vs. `A-101` Rev A Superseded):**
   - *Conflict:* `A-101_Roof_Plan_RevA_SUPERSEDED.dxf` showed a simple $240\text{ ft} \times 180\text{ ft}$ ($43,200\text{ sf}$) rectangle without a northeast generator yard notch.
   - *Resolution:* `A-101` Rev A is superseded per `T-204` Item 13. The governing as-built geometry from `NDDC-A2_Federated_Model_2026.ifc`, `A-101` Rev C, and `S-201` Rev C incorporates the $60\text{ ft} \times 40\text{ ft}$ re-entrant generator yard notch at the northeast corner ($x \in [180, 240]\text{ ft}, y \in [140, 180]\text{ ft}$), bounded by shear wall lines `N2` ($y = 140\text{ ft}, x \in [180, 240]\text{ ft}$) and `E2` ($x = 180\text{ ft}, y \in [140, 180]\text{ ft}$), and the $40\text{ ft} \times 30\text{ ft}$ interior mechanical well opening ($x \in [100, 140]\text{ ft}, y \in [100, 130]\text{ ft}$), resulting in a net roof deck diaphragm area of $39,600\text{ sf}$ (and reducing Zone `Z43` to $60\text{ ft} \times 20\text{ ft} = 1,200\text{ sf}$).

5. **North Mechanical Screen Wall Parapet Elevation (`SR-2026-118` and `2026 IFC Model` vs. `PC-S01` 2024 Schedule):**
   - *Conflict:* The 2024 precast panel schedule (`PC-S01_Precast_Panel_Schedule_2024.xlsx`) lists all 63 perimeter panels with a uniform top-of-panel elevation of $+31.0\text{ ft}$ ($3.0\text{ ft}$ parapet above the $+28.0\text{ ft}$ roof deck).
   - *Resolution:* Per `SR-2026-118` Section 5.2, `NDDC-A2_Federated_Model_2026.ifc`, `A-101` Rev C, and `EOR-NDDC-A2-S01` Rev 2 Section 5.3, the four north panels between $x = 96.0\text{ ft}$ and $x = 168.0\text{ ft}$ on wall line `N1` (`N108`, `N109`, `N110`, and `N111`) extend to $+36.00\text{ ft}$ above finished floor ($8.00\text{ ft}$ solid precast mechanical screen wall above the $+28.00\text{ ft}$ roof deck). This $+36.00\text{ ft}$ top elevation governs both the wind cantilever lever transfer to the roof diaphragm ($h_p = 8.0\text{ ft}$, centroid $z_p = 32.0\text{ ft}$, lever ratio $z_p/h = 32.0/28.0 = 1.1429$, velocity pressure $q_p(36.0\text{ ft}) = 30.31\text{ psf}$) and the gross panel self-weight in the Section 5.8 overturning stability check.

6. **As-Built Field-Cut Opening in Panel `S14` (`2026 IFC Model` vs. `PC-S01` and `PC-S02` Rev 1 / Rev 2):**
   - *Conflict:* `PC-S02_Precast_Panel_Elevations_Rev1_SUPERSEDED.dxf` showed a preliminary $6.0\text{ ft} \times 8.0\text{ ft}$ shop opening in panel `S14` ($x = 192.0$ to $204.0\text{ ft}$) from $x = 196.0$ to $202.0\text{ ft}$ that was deleted prior to fabrication in `PC-S01` (`openings_shown = none`) and `PC-S02` Rev 2. However, `PC-S01` Note 4 and `PC-S02` Rev 2 Note 4 explicitly warn that field openings cut after erection are not shown on the precast shop drawings and must be verified against the 2026 federated model.
   - *Resolution:* Inspection of `NDDC-A2_Federated_Model_2026.ifc` reveals an as-built field-cut $8.0\text{ ft}\text{ wide} \times 12.0\text{ ft}\text{ high}$ opening (`S14-O1`) in panel `S14` extending from station $s_0 = 194.50\text{ ft}$ to $s_1 = 202.50\text{ ft}$ ($59,283.6\text{ mm}$ to $61,722.0\text{ mm}$). Per `EOR-NDDC-A2-S01` Rev 2 Sections 5.3 and 5.4, this opening divides panel `S14` ($192.00$ to $204.00\text{ ft}$) into two vertical legs:
     - Left leg ($192.00$ to $194.50\text{ ft}$): width $L = 2.50\text{ ft} \ge 2.0\text{ ft}$, retained as structural pier `S14` with thickness $t = 8.0\text{ in}$ and Timoshenko stiffness $k = 6.32\text{ kip/in}$ ($6.3186\text{ kip/in}$).
     - Right leg ($202.50$ to $204.00\text{ ft}$): width $L = 1.50\text{ ft} < 2.0\text{ ft}$, neglected per Section 5.4 (assigned zero stiffness and carries no in-plane shear).
     Thus, the 63 perimeter panels produce exactly 73 active structural shear wall piers across the six wall lines (`S`: 19 piers, `E`: 12 piers, `E2`: 4 piers, `N2`: 5 piers, `N1`: 15 piers, `W`: 18 piers; 73 total).

7. **Joist Spacing and Deck Span Stiffness Adjustment in Zone `Z22` (`SJ-201` Note 1 & Note 2 and `CDS-B36` Note 4):**
   - *Conflict:* `SJ-201` Note 1 states that joists run north-south at $5\text{ ft } 0\text{ in}$ o.c. typically while referring to the $6\text{ ft } 0\text{ in}$ standard deck span tabulated in `CDS-B36`, whereas `SJ-201` Note 2 specifies that in mechanical bay Zone `Z22` the joists are doubled to $4\text{ ft } 0\text{ in}$ o.c. (`deck span there is 4 ft 0 in`).
   - *Resolution:* Per `EOR-NDDC-A2-S01` Rev 2 Sections 7.3 and 9.2 and `CDS-B36` Note 4, the smeared framing axial rigidities are taken from the `SJ-201` schedule values ($EA_x = 29,000 \times 4.0 / 40.0 = 2,900\text{ kip/ft}$ and $EA_y = 29,000 \times 2.4 / 5.0 = 13,920\text{ kip/ft}$, matching Verification Example `VE-1`), while in Zone `Z22` the $4\text{ ft } 0\text{ in}$ deck span requires multiplying the catalogue shear stiffness $G'$ by `1.15` (so `D22-36/4-2` in `Z22` uses $G'_{\text{used}} = 17.80 \times 1.15 = 20.47\text{ kip/in}$) with no change to its ASD shear capacity ($980 / 2.35 = 417.02\text{ plf}$).

---

## 5. Summary of Engineered Lateral Package and Installed Cost

- **Roof Deck Diaphragm (`39,600.0 sf`, 4 distinct deck types <= 4 max per `OBD-NDDC-A2` Section 4.6):**
  - `D22-36/4-2` ($G\x27 = 17.80\text{ kip/in}$, $20.47\text{ kip/in}$ in `Z22`; $V_{\text{ASD}} = 417.02\text{ plf}$; `$3.05/sf`): Zones `Z13, Z22, Z23, Z32, Z43` ($14,600.0\text{ sf}$, `$44,530.00`).
  - `D22-36/4-4` ($G\x27 = 22.90\text{ kip/in}$; $V_{\text{ASD}} = 527.66\text{ plf}$; `$3.34/sf`): Zones `Z11, Z21, Z31` ($10,800.0\text{ sf}$, `$36,072.00`).
  - `D22-36/7-4` ($G\x27 = 32.60\text{ kip/in}$; $V_{\text{ASD}} = 842.55\text{ plf}$; `$3.95/sf`): Zone `Z41` ($3,600.0\text{ sf}$, `$14,220.00`).
  - `D20-36/7-4` ($G\x27 = 39.70\text{ kip/in}$; $V_{\text{ASD}} = 1076.60\text{ plf}$; `$4.43/sf`): Zones `Z12, Z33, Z42` ($10,600.0\text{ sf}$, `$46,958.00`).
  - **Subtotal Roof Deck:** `$141,780.00`.
- **Chords and Collectors (`1,300.0 lf`, `5,675.80 lb` @ `$2.85/lb` = `$16,176.03`):**
  - `C-E2` ($40.0\text{ ft}$): `PL10x5/8` ($A = 6.25\text{ in}^2$, $21.25\text{ plf}$, $T_{\text{allow}} = 187.5\text{ kips}$, $C_{\text{allow}} = 112.5\text{ kips}$, peak force $19.733\text{ kips}$, `$2,422.50`).
  - `C-S, C-N1, C-N2, C-E, C-W, K-N2, K-E2, O-S, O-N, O-W, O-E` ($1,260.0\text{ ft}$ total): `PL3x3/8` ($A = 1.125\text{ in}^2$, $3.83\text{ plf}$, $T_{\text{allow}} = 33.8\text{ kips}$, $C_{\text{allow}} = 20.3\text{ kips}$, peak force $8.420\text{ kips}$, `$13,753.53`).
- **Precast Panel Connections (`$47,950.00`):**
  - **140 Type E1 Roof-to-Panel Shear Embeds** (`EP-6x12-4S`, $4.20\text{ kips}$ ASD shear, `$185.00/ea` = `$25,900.00`): 4 embeds on `E201` (peak panel shear $13.896\text{ kips} \le 14.00\text{ kips}$ Type B1 base shear capacity and $\le 16.80\text{ kips}$ embed capacity), 3 embeds each on `E202, E203, E204` and the eight $20\text{ ft}$ panels (`S06, S08, S10, E06, N203, N107, N108, N109`), and 2 embeds each on the remaining 51 panels.
  - **9 Type T1 Panel Base Tie-Downs** (`TD-HD12`, $88.0\text{ kips}$ ASD uplift, `$2,450.00/panel` = `$22,050.00`): installed on panels `E201, E202, E203, E204, N112, N201, N204, S01, W01` where $M_{\text{OT}} > 0.6 M_D$.
- **Acceptance & Convergence Summary:**
  - Peak relative diaphragm deflection (`Criteria Section 8.2`): `0.5378 in <= 0.5500 in` (`W01` Y-direction; peak total displacement `0.5459 in <= 0.5500 in`).
  - Peak shear wall pier roof-level drift (`Criteria Section 8.3`): `0.0411 in <= 0.8400 in` ($h/400$).
  - Mesh convergence (`Criteria Section 9.7`): Level `L2` ($H = 5.0\text{ ft}$, 1,584 elements, $R_{W,\text{W01}} = 47.2043\text{ kips}$) vs. Level `L3` ($H = 2.5\text{ ft}$, 6,336 elements, $R_{W,\text{W01}} = 47.3193\text{ kips}$) differs by `0.24% <= 5.0%`.
  - **Total Installed Package Cost:** **`$205,906.03`** ($\le \$310,000.00$ ceiling per `OBD-NDDC-A2` Section 4.7 and `Criteria` Section 10.2).
