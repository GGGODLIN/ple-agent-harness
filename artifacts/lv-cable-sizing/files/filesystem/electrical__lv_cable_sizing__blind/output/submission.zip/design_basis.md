```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01",
    "precedence": "Where two governing documents set different limits on the same quantity, the more restrictive limit governs (EDS-26 Rev 4 Section 1.2; G-001 General Note 2; UFC 3-501-01 Paragraph 1-3)."
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "encasement_thermal_resistivity_k_m_w": 0.55,
    "solar_irradiance_w_m2": 1030,
    "load_factor": 1.0,
    "termination_allowance_ft": 8
  },
  "sources": {
    "codes_of_record": "UFC_1-200-01_DoD_Building_Code_2024-12-17.pdf (Change 4, Section 1-6.2 & Table 1-1); UFC_3-501-01_Electrical_Engineering_2024-11-27.pdf (Section 1-4); G-001_title_sheet_and_index.dxf (General Note 2); NSA-WR_EDS-26_electrical_design_standard_rev4.pdf (Sections 1.1 & 1.2)",
    "outdoor_design_dry_bulb_c": "NOAA_daily_normals_1991-2020_USW00003145.csv (max DLY-TMAX-NORMAL 106.8 F = 41.56 C, rounded up to 42 C per NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.4)",
    "roof_ambient_c": "NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.4 (outdoor design dry-bulb 42 C + 4 K = 46 C); M-501-C_ambient_temperature_coordination_memo.pdf Section 4 & Table 1",
    "earth_ambient_c": "NOAA_daily_normals_1991-2020_USW00003145.csv (annual mean of DLY-TAVG-NORMAL 76.0036 F = 24.4464 C + 3 K = 27.45 C per NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.3.2)",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T_thermal_resistivity_report.pdf Section 4 & Table 1 (0.60 K*m/W engineered thermal backfill full trench width; 0.95 K*m/W native soil rejected); NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.3.1",
    "solar_irradiance_w_m2": "NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.4 (S = 1030 W/m^2, alpha = 0.6, h = 14.0 W/(m^2*K))"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs",
    "transformer_reset": false,
    "feeder_chain_pct": 2.7774,
    "feeder_chains_by_path_pct": {
      "SE-1_to_MSB-1": 1.0434,
      "SE-1_F-01_to_MCC-1": 2.5752,
      "SE-1_F-02_to_DP-2": 1.4066,
      "SE-1_F-02_F-06_to_K-13": 1.5682,
      "SE-1_F-02_F-06_F-07_to_LP-1": 2.7703,
      "SE-1_F-05_to_DP-3": 2.5811,
      "SE-1_F-10_to_ATS-1": 2.7774
    },
    "branch_limit_pct": 3.0,
    "feeder_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 92850.05,
    "raw_conductor_usd": 98776.65,
    "discount_usd": -5926.6,
    "termination_usd": 9601.7,
    "raceway_usd": 47589.6,
    "material_usd": 96560.59,
    "labor_usd": 53480.76,
    "total_usd": 150041.35
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "D1",
      "D2",
      "D3"
    ]
  },
  "mutual_heating_rise_k": 23.53,
  "mutual_heating_rise_by_circuit_k": {
    "SE-1": 31.09,
    "F-10": 23.53,
    "F-05": 1.54
  }
}
```

# Basis of Design — Low-Voltage Wire Schedule (Building 4210, Project P-4210)

## 1. Codes of Record, Adoption Authority, and Criteria Precedence

The low-voltage conductor package for Building 4210 (Consolidated Support Facility, Naval Support Activity Whitmore Ridge, Project P-4210) is engineered under the project's governing federal and installation criteria as of the **12 June 2026** Issued-for-Construction (IFC) milestone (`G-001_title_sheet_and_index.dxf`, General Note 2):

1. **Adopting Document**: **UFC 1-200-01**, *DoD Building Code* (1 October 2022, with Change 4 of 17 December 2024), adopts the model building code and through **UFC 3-501-01**, *Electrical Engineering* (3 November 2015, Change 4 of 27 November 2024), establishes the electrical code of record.
2. **Codes of Record**:
   - **NFPA 70 (National Electrical Code), 2023 Edition** — adopted by **UFC 3-501-01** Section 1-4 and **EDS-26 Rev 4** Section 1.1.
   - **International Building Code (IBC), 2024 Edition** — adopted by **UFC 1-200-01** Change 4 (17 December 2024), Section 1-6.2 and Table 1-1.
3. **Rule of Precedence**: Per **NSA-WR EDS-26 Rev 4** (14 January 2026) Section 1.2, **UFC 3-501-01** Paragraph 1-3, and Drawing **G-001** General Note 2, where two governing documents set different limits on the same quantity, **the more restrictive limit governs**.
4. **Superseded and Non-Governing Documents Explicitly Excluded**:
   - **NSA-WR EDS-26 Rev 2 (19 August 2019)** (`NSA-WR_EDS-26_electrical_design_standard_rev2_SUPERSEDED.pdf`) was withdrawn and superseded in full by **EDS-26 Rev 4** Section 1.3 (which tightened total cumulative voltage drop from 6% to 5%, replaced step-function duct-bank derating with the Neher-McGrath thermal network, retired the 0.80 duct-bank load factor in favor of 1.0, and permitted AA-8000 aluminium on #4 AWG and larger feeders and motor feeders).
   - **E-601 Rev A (30% design issue, 18 November 2025)** (`E-601_one_line_REV_A_SUPERSEDED.pdf`, which showed `SE-1` as 1600 A, `F-01` as 400 A, `F-02` as 250 A, and `F-10` as 400 A) was superseded by the IFC one-line diagram **E-601 Rev 0 (12 June 2026)** (`E-601_one_line_diagram.dxf`).
   - **Meridian Cable THHN/THWN-2 datasheet** (`Meridian_Cable_building_wire_datasheet.pdf`) does not govern; **Specification Section 26 05 19** Part 2, Paragraph 2.1 requires cross-linked polyethylene **XHHW-2** insulation and designates **Cascadia Wire and Cable, Engineering Data Section 4 (2026 edition)** as the Basis of Design.

---

## 2. Environmental Parameters and Provenance

All environmental and thermal parameters are derived directly from the site climate record (`NOAA_daily_normals_1991-2020_USW00003145.csv`, Station USW00003145, Desert Center, CA), the geotechnical thermal resistivity investigation (`GEO-4210-T_thermal_resistivity_report.pdf`), the mechanical coordination memorandum (`M-501-C_ambient_temperature_coordination_memo.pdf`), and **EDS-26 Rev 4** Section 5:

- **Outdoor Design Dry-Bulb (`42 °C`)**: Per **EDS-26 Rev 4** Section 5.4, the outdoor design dry-bulb temperature is the highest daily maximum normal (`DLY-TMAX-NORMAL`) in the 30-year NOAA record (`106.8 °F = 41.556 °C` on July 19–22), converted to Celsius and rounded up to the next whole degree: **`42 °C`**.
- **Roof Cable Tray Ambient (`46 °C`) and Solar Heating (`1030 W/m²`)**: Per **EDS-26 Rev 4** Section 5.4 and **M-501-C** Section 4 / Table 1, the roof cable tray (`CT-R1`, exposed 18 in. ladder tray 18 in. above roof membrane) operates at an ambient air temperature of `42 °C + 4 K = 46 °C`, under direct solar irradiance `S = 1030 W/m²`, surface absorptivity `α = 0.6`, and convective heat-transfer coefficient `h = 14.0 W/(m²·K)`. This produces a steady-state solar surface temperature rise `ΔT_s = (0.6 × 1030 × D) / (π × D × 14.0) = 14.0511 K`.
- **Undisturbed Earth Ambient (`27.45 °C`)**: Per **EDS-26 Rev 4** Section 5.3.2, the undisturbed earth temperature at duct-bank burial depth is the annual mean of the 365 daily average temperature normals (`DLY-TAVG-NORMAL` mean = `76.0036 °F = 24.4464 °C`) plus `3 K` = **`27.4464 °C`** (`27.45 °C`).
- **Soil and Encasement Thermal Resistivity (`0.60 K·m/W` and `0.55 K·m/W`)**: Per **GEO-4210-T** Section 4 / Table 1 and **EDS-26 Rev 4** Section 5.3.1, both underground duct banks (`DB-1` and `DB-2`) are encased in 3,000 psi red-dyed concrete (`ρ_c = 0.55 K·m/W`) and backfilled full trench width to grade with controlled, compacted thermal sand-cement backfill (`ρ_s = 0.60 K·m/W` at design dry moisture content). Per **EDS-26 Rev 4** Section 5.3.1, where engineered thermal backfill is placed full trench width, the backfill resistivity (**`0.60 K·m/W`**) is used as the effective earth thermal resistivity `ρ_e` in both the self-heating earth resistance `R_e` and the mutual-heating resistance `R_ij`. The native desert sandy-silt resistivity (`0.95 K·m/W`, **GEO-4210-T** Section 2) was considered and rejected as non-governing (and is logged separately on the calculation front sheet and constraint register).
- **Interior Space Ambients (`40 °C` and `45 °C`)**: Per **M-501-C** Sections 1–3 and Table 1, Mechanical Room 121 and Fire Pump Room 105 operate at a **`45 °C`** design ambient (`F-01, F-03, B-11, B-12, B-13, B-14, B-15`); all other interior spaces (Electrical Rooms 109 and 112, High-Bay Maintenance Shop 130, Communications Room 204, Galley 118, Administrative Wing 201–215, and Corridors) operate at **`40 °C`** (`B-01..B-10, B-16..B-18, F-02, F-06, F-07, F-09, F-11`).

---

## 3. Voltage-Drop Budget Allocation, Starting Point, and Inheritance

- **Starting Point (`T-1 secondary lugs`)**: Per utility service letter **WRPU-2026-0412** Paragraph 2 and **UFC 3-501-01** Paragraph 3-2.7.4.2, the utility owns and regulates up to the 480Y/277 V secondary bushings of pad-mounted service transformer `T-1`. All facility voltage-drop calculations start at **`T-1 secondary lugs`**.
- **No Transformer Reset (`transformer_reset = false`)**: Per **UFC 3-501-01** Paragraph 3-2.7.4.5.3 and **EDS-26 Rev 4** Section 5.6, dry-type step-down transformer `K-13` (225 kVA, 480 V–208Y/120 V) is an uncompensated interior dry-type distribution transformer with no load-tap changer or automatic voltage regulator; therefore, **the cumulative voltage-drop count does NOT reset at `K-13`**. Downstream feeder `F-07` and all `LP-1` branch circuits inherit the cumulative voltage drop of the upstream feeder chain (`SE-1 -> F-02 -> F-06 -> F-07`).
- **Branch circuits inheriting upstream feeder drop**: Of the 18 branch circuits (`B-01..B-18`), **all 18 branch circuits** inherit the cumulative voltage drop spent upstream of their serving panelboard or motor control center (`B-01..B-10` inherit `2.7703%` from `LP-1` via `SE-1 + F-02 + F-06 + F-07`; `B-11..B-15` inherit `2.5752%` from `MCC-1` via `SE-1 + F-01`; `B-16` inherits `1.4066%` from `DP-2` via `SE-1 + F-02`; `B-17..B-18` inherit `2.5811%` from `DP-3` via `SE-1 + F-05`). In addition, the 7 dedicated equipment/motor circuits designated as branch circuits or fire pump circuits (`F-03, F-04, F-08, F-09, F-11, F-12, F-13`) inherit their upstream panel/switchboard drop (`1.0434%` at `MSB-1` or `1.4066%` at `DP-2`).
- **Feeder Chain Voltage Drops (Limit `≤ 3.0%`)**:
  - `T-1 -> MSB-1` (`SE-1`): **`1.0434%`**
  - `T-1 -> MSB-1 -> MCC-1` (`SE-1 + F-01`): `1.0434% + 1.5318%` = **`2.5752%`** (`≤ 3.0%`)
  - `T-1 -> MSB-1 -> DP-2` (`SE-1 + F-02`): `1.0434% + 0.3632%` = **`1.4066%`** (`≤ 3.0%`)
  - `T-1 -> MSB-1 -> DP-2 -> K-13` (`SE-1 + F-02 + F-06`): `1.4066% + 0.1616%` = **`1.5682%`** (`≤ 3.0%`)
  - `T-1 -> MSB-1 -> DP-2 -> K-13 -> LP-1` (`SE-1 + F-02 + F-06 + F-07`): `1.5682% + 1.2021%` = **`2.7703%`** (`≤ 3.0%`)
  - `T-1 -> MSB-1 -> DP-3` (`SE-1 + F-05`): `1.0434% + 1.5377%` = **`2.5811%`** (`≤ 3.0%`)
  - `T-1 -> MSB-1 -> ATS-1` (`SE-1 + F-10`): `1.0434% + 1.7340%` = **`2.7774%`** (`≤ 3.0%`, maximum feeder chain drop)
- **Tightest Branch-Circuit Voltage-Drop Couplings**:
  - At Workshop Panel `DP-3`, branch circuit `B-17` (Air Compressor `CMP-1`, 190 ft, 34.6 A FLA) is restricted by `CMP-1`'s maximum terminal conductor size of **`#6 AWG`** (`P-4210_equipment_and_panel_schedule.xlsx` and **EDS-26 Rev 4** Section 3.3), fixing `B-17`'s own voltage drop at **`2.3469%`**. To hold `B-17`'s cumulative drop below `5.0%`, `SE-1 + F-05` cannot exceed `2.6531%`. Selecting `3 × 600 kcmil AL` on `F-05` (`1.5377%` drop) yields a cumulative drop at `CMP-1` of `1.0434% + 1.5377% + 2.3469%` = **`4.9280% ≤ 5.0%`**.
  - At Lighting Panel `LP-1` (cumulative feeder drop `2.7703%`), the remaining branch budget is `2.2297%`. Branch circuits `B-01, B-03, B-04, B-05, B-08` are upsized to `#8 AWG CU` and `B-02, B-06, B-07` to `#6 AWG CU`, keeping every `LP-1` branch circuit's cumulative drop between `4.3895%` and `4.8643% ≤ 5.0%`.
  - Fire pump feeder `F-03` (`1 × #1 AWG CU`, 56 ft) has a normal running drop of `0.2952%` (`1.3386%` cumulative `≤ 5.0%`) and a locked-rotor starting drop at `543 A` (`PF = 0.35`) of `1.0120%` (`2.0554%` cumulative `≤ 15.0%` per **EDS-26 Rev 4** Section 4.6.3 and **NFPA 70** Article 695).

---

## 4. Service-Entrance (`SE-1`) Sizing Decision

Per **UFC 3-501-01** Paragraph 3-2.3.3 and **EDS-26 Rev 4** Section 2.1.2, the service-entrance conductors (`SE-1`, 320 ft in underground duct bank `DB-1` from `T-1` to `MSB-1`) must have a corrected ampacity at **100% load factor (`LF = 1.0`)** at least equal to the **`2,000 A` main bus rating of `MSB-1`** (not merely the `1,600 A` demand load used for voltage drop). Both `T-1` and `MSB-1` provide a maximum of **6 parallel lug barrels per phase** and a maximum lug conductor size of **`600 kcmil`** (`P-4210_equipment_and_panel_schedule.xlsx`).

In `DB-1`, `SE-1` is sized as **6 parallel sets of `500 kcmil CU` with a `4/0 AWG CU` EGC per conduit** (`6 × 500 kcmil CU`). Under the Neher-McGrath mutual-heating model with `F-10` operating simultaneously in `DB-1`, the worst-case conduit of `SE-1` (`D5`/`D6`) experiences a mutual heating rise of `ΔT_m = 31.09 K`, yielding a corrected per-set ampacity of **`348.12 A/set`** (`6 × 348.12 A = 2,088.72 A ≥ 2,000 A`). Copper is required because 6 sets of `600 kcmil AL` in `DB-1` achieve only `6 × 302.1 A = 1,812.6 A < 2,000 A`.

---

## 5. Underground Duct-Bank Assignment (`DB-1` and `DB-2`) and Thermal Consequences

Per Drawing **E-615** (`E-615_underground_duct_bank_plan_and_sections.dxf`), Section A-A:
- **Service Duct Bank `DB-1`** is a **3-row × 4-column (12-duct)** concrete-encased bank (`D1..D4` top row at `y = 33.5 in.`, `D5..D8` middle row at `y = 41.0 in.`, `D9..D12` bottom row at `y = 48.5 in.`, column centers at `x = ±3.75 in., ±11.25 in.`).
- **Available Power Ducts in `DB-1`**: General Note 3 on Drawing **E-615** reserves the rightmost column **`D11` and `D12`** (bottom-right two conduits) exclusively for communications cables (`COMM — NO POWER`), leaving **10 ducts (`D1` through `D10`) available for power circuits**.
- **Optimal `DB-1` Duct Assignment**:
  - **`SE-1` (6 sets of `500 kcmil CU`)** is assigned to the left two columns: **`D1, D2, D5, D6, D9, D10`**.
  - **`F-10` (2 sets of `500 kcmil AL`)** is assigned to the right column above the communications ducts: **`D4, D8`**.
  - Ducts **`D3` and `D7`** (column 3) are intentionally left as an unoccupied **7.5 in. thermal separation buffer** between `SE-1` and `F-10`.
- **Thermal Consequence in `DB-1`**: Placing `F-10` in `D4` and `D8` (separated from `SE-1` by empty column `D3, D7`) limits the mutual-heating temperature rise on `F-10` to **`ΔT_m = 23.53 K`** (at `D8`), enabling `F-10` to use **`2 × 500 kcmil AL`** with a corrected ampacity of **`302.23 A/set`** (`604.46 A ≥ 600 A`). If `F-10` were placed adjacent to `SE-1` without the buffer column, mutual heating from `SE-1` would depress `2 × 500 kcmil AL` below `600 A` (`572.7 A`) and force a much costlier copper or larger-kcmil selection.
- **Secondary Duct Bank `DB-2`**: Per Drawing **E-615** Section B-B, `DB-2` is a 1-row × 4-column bank (`D1..D4` at `y = 33.5 in.`). Circuit **`F-05` (3 sets of `600 kcmil AL`)** occupies **`D1, D2, D3`** (leaving `D4` spare). Because `F-05`'s continuous operating load is `320 A` (`106.67 A/set`), its actual mutual heating rise at `D2` is only `1.54 K` (`7.72 K` at full ampacity), and its per-set ampacity is capped by the `75 °C` terminal limit at **`336.00 A/set`** (`1,008 A ≥ 400 A`).

---

## 6. Material and Standardisation Decisions

- **Conductor Material (`CU` vs. `AL`)**: Per **EDS-26 Rev 4** Section 3.1 and **Specification Section 26 05 19** Paragraph 2.2, **copper (`CU`)** is used for:
  1. Service-entrance conductors `SE-1` (mandatory copper per Section 3.1(a) and required for 2,000 A ampacity in 6 ducts),
  2. Fire pump feeder `F-03` (mandatory copper per Section 3.1(b)),
  3. All equipment grounding conductors (mandatory copper per Section 3.1(c)), and
  4. All 18 branch circuits (`B-01` through `B-18`), plus feeders `F-02`, `F-06`, and `F-11`.
  **AA-8000 series aluminum (`AL`)** is permitted on feeders and motor feeders `#4 AWG` and larger where terminations are dual-rated `AL9CU` (verified on all equipment in `P-4210_equipment_and_panel_schedule.xlsx`), and is selected on **`F-01` (`2 × 500 kcmil AL`), `F-04` (`2 × 4/0 AL`), `F-05` (`3 × 600 kcmil AL`), `F-07` (`3 × 500 kcmil AL`), `F-08` (`1 × 4/0 AL`), `F-09` (`1 × 300 kcmil AL`), `F-10` (`2 × 500 kcmil AL`), `F-12` (`2 × 4/0 AL`), and `F-13` (`1 × 4/0 AL`)**.
- **Large-Conductor Standardisation (`≤ 5` Distinct Sizes `≥ 1/0 AWG`)**: Per **EDS-26 Rev 4** Section 3.4.2, the entire package uses exactly **5 distinct phase conductor trade sizes `≥ 1/0 AWG`**:
  1. **`4/0 AWG`** (`F-04, F-08, F-12, F-13`)
  2. **`300 kcmil`** (`F-09`)
  3. **`400 kcmil`** (`F-06`)
  4. **`500 kcmil`** (`SE-1, F-01, F-02, F-07, F-10`)
  5. **`600 kcmil`** (`F-05`)

---

## 7. Cost Ledger Summary (Material, Labour, and Campus Quantity Break)

Costs are computed from `Cascadia_Wire_price_list_2026.csv` and `P-4210_unit_price_book_2026.xlsx`:
- **Total Installed Conductor Length**: **`40,254 ft`** (phase conductors + EGCs across all 32 circuits, including 1 EGC per circuit in roof cable tray `CT-R1` per **EDS-26 Rev 4** Section 5.7). Because `40,254 ft ≥ 38,000 ft`, the **6% campus quantity break** (`P-4210_unit_price_book_2026.xlsx`, `project_rules`) applies to all conductor material and labour.
- **Cost Breakdown**:
  - **Conductor (Gross before discount)**: Material `$74,525.10` + Labour `$24,251.55` = **`$98,776.65`**
  - **Campus Quantity Break (-6% on conductor)**: Material `-$4,471.51` + Labour `-$1,455.09` = **`-$5,926.60`**
  - **Conductor (Net after 6% discount)**: Material `$70,053.59` + Labour `$22,796.46` = **`$92,850.05`**
  - **Terminations (AL9CU compression lugs)**: Material `$5,100.92` + Labour `$4,500.78` = **`$9,601.70`**
  - **Interior Raceway (RGS conduit)**: Material `$21,406.08` + Labour `$26,183.52` = **`$47,589.60`**
  - **Total Installed Package Cost**: Material **`$96,560.59`** + Labour **`$53,480.76`** = **`$150,041.35`**
