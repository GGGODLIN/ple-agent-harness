# Design Basis Memorandum — Condenser Water Heat Rejection Replacement
**Project:** Papago Federal Center, Phoenix, Arizona (95% Construction Documents)  
**Engineer of Record Plant Designer:** Sandoval Klee Mechanical Engineers, PC for GSA  

---

## 1. Executive Summary & Optimal Plant Selections

Each of the three rooftop condenser water heat rejection plants — Courthouse Central Utility Plant (`CUP`), Data Annex (`ANNEX`), and Laboratory Wing (`LAB`) — has been designed to maximize federal life-cycle **Net Savings (`NS`)** relative to the basic design defined in `EC-01`, in strict compliance with `10 CFR Part 436 Subpart A` and every physical, hydraulic, thermal, chemical, structural, electrical, acoustic, and siting requirement in the adopted project criteria (`DC-02 Rev 3`).

| Parameter | `CUP` | `ANNEX` | `LAB` |
|---|---|---|---|
| **Selected Cell Model (`VD-01`)** | `CTX-0600-S` | `CTX-0600-S` | `CTX-0900-H` |
| **Installed Cells (`CELLS`)** | `4` | `4` | `3` |
| **Total Design Flow (`GPMTOTAL`)** | `1,800 gpm` (`450 gpm/cell`) | `1,800 gpm` (`450 gpm/cell`) | `2,025 gpm` (`675 gpm/cell`) |
| **Design Wet-Bulb (`WBDESIGN`)** | `80.0 °F` | `80.0 °F` | `80.0 °F` |
| **Scheduled / Achieved `CWS_F`** | `85.37 °F` / `85.36 °F` | `85.70 °F` / `85.69 °F` | `86.00 °F` / `85.99 °F` |
| **Scheduled / Achieved `Range_F`** | `12.66 °F` / `12.66 °F` | `13.69 °F` / `13.69 °F` | `14.59 °F` / `14.59 °F` |
| **Scheduled / Achieved `Approach_F`** | `5.37 °F` / `5.36 °F` | `5.70 °F` / `5.69 °F` | `6.00 °F` / `5.99 °F` |
| **Reset Floor / Offset (`CWSMIN` / `CWSOFFSET`)** | `65.0 °F` / `11.5 °F` | `79.5 °F` / `11.5 °F` | `57.5 °F` / `8.5 °F` |
| **Controlled / Max Allowable `COC`** | `4.14` / `4.142` (`PSI = 5.601`) | `4.00` / `4.001` (`PSI = 5.600`) | `3.87` / `3.879` (`PSI = 5.601`) |
| **Casing Material / Eliminator / Motor** | `SS-304` / `DE-2` (`0.002%`) / `20 hp` (`91.7%`) | `SS-304` / `DE-2` (`0.002%`) / `20 hp` (`91.7%`) | `SS-304` / `DE-2` (`0.002%`) / `20 hp` (`91.7%`) |
| **Evaporation Method (`EVAPMETHOD`)** | `SATURATED-EXIT` | `SATURATED-EXIT` | `SATURATED-EXIT` |
| **Annual Plant Energy (`kWh/yr`)** | `2,126,665 kWh` | `3,893,886 kWh` | `3,551,638 kWh` |
| **Peak Coincident Demand / MCC Limit** | `515.03 kW` / `528.00 kW` | `570.69 kW` / `590.00 kW` | `633.01 kW` / `641.14 kW` |
| **Annual Makeup / Allocation Limit** | `9,581.6 kgal` / `10,300.0 kgal` | `12,575.9 kgal` / `12,600.0 kgal` | `16,980.0 kgal` / `17,400.0 kgal` |
| **Initial Investment (`Investment_USD`)** | `$782,208.00` | `$782,208.00` | `$778,848.00` |
| **Proposed Design `LCC_USD`** | `$5,645,200.16` | `$7,847,771.93` | `$8,532,284.42` |
| **Basic Design `BasicDesignLCC_USD`** | `$5,890,940.15` | `$8,108,828.23` | `$8,820,663.84` |
| **Life-Cycle Net Savings (`NetSavings_USD`)** | **`$245,739.99`** | **`$261,056.30`** | **`$288,379.42`** |

---

## 2. Governing Documents & Resolution of Library Conflicts

In accordance with `DC-02` Section 3 (Tables 1 and 2) and Section 9.1 (Table 5), only the adopted current project documents are applied as governing authorities. Superseded, cancelled, or inapplicable documents in the library (`UFC 3-400-02`, the Tucson station climatic dataset `72274023160`, the cancelled 2023 `UFC 3-230-13`, superseded drawing `M-401 Rev B`, superseded memorandum `DC-02 Rev 2`, the 2024 LCC supplement `NIST IR 85-3273-39` as a factor source, the incomplete `2024-06-18` and older `2021-04-05` water quality samples, the closed-loop specification excerpt `23 25 00`, and the unamended `ANNEX` allocation figure in `PW-LTR-014` without `PW-LTR-019`) are excluded from governing authority.

The three documented conflicts in `DC-02` Section 9.1 (Table 5) are resolved as follows:

CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE GSA PBS-P100 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 1-2 | SET ASIDE UFC 3-230-13 Chapter 5
CONFLICT 3: ADOPTED M-401 Rev C | SET ASIDE M-401 Rev B

### Detailed Basis for Conflict Resolutions and Engineering Determinations
1. **Conflict 1 — Outdoor Wet-Bulb Basis (`UFC 3-410-01` `2-4.2.4` vs. `GSA PBS-P100` `5.3.1` & `5.1.3`):**
   - For the **design point** sizing of open cooling towers, `DC-02` Section 5.2 adopts `UFC 3-410-01` paragraph `2-4.2.4` (and `2-4.2.1`), which prescribes the **1.0% annual occurrence outdoor wet-bulb temperature** from the Phoenix Sky Harbor POR (`77.0 °F`) plus a **`+3.0 °F`** open cooling tower margin, yielding **`DesignWetBulb_F = 80.0 °F`** (`WBDESIGN = 80.0`). The `0.4%` dew-point cooling tower sizing bullet in `GSA PBS-P100` `5.3.1` is set aside for design-point sizing.
   - For the **single-cell failure redundancy check**, `DC-02` Sections 5.2 and 6.3 adopt the `GSA PBS-P100` (`5.1.3` / `5.3.1`) **0.4% annual evaporation wet-bulb temperature** (`78.0 °F` from the Phoenix Sky Harbor POR) adjusted by the same **`+3.0 °F`** margin from `UFC 3-410-01` `2-4.2.4`, yielding **`RedundancyWetBulb_F = 81.0 °F`**.
   - From the same 3-year Phoenix Sky Harbor FM-15 station record (`LCD_72278023183_PHOENIX_SKY_HARBOR_INTL_AP_AZ_2022_2024.csv`, `26,513` valid `FM-15` hourly observations per `RFI-017` and `LCD_Dataset_Documentation_2025.pdf`), the **99.6% annual dry-bulb temperature** is **`DryBulb996_F = 38.0 °F`**. Because `38.0 °F > 32.0 °F`, freeze protection is not required (`DC-02` Section 5.4), so **`BASINHEATER = NO`** on all three roofs.

2. **Conflict 2 — Water Treatment Manual Edition & Evaporation Formulation (`UFM 3-230-13` vs. `UFC 3-230-13`):**
   - `UFM 3-230-13` (`16 January 2026`), paragraph `1-2`, explicitly supersedes and cancels `UFC 3-230-13` (`15 May 2023`). Therefore, `UFM 3-230-13` governs water balance relationships (`5-2.1.3`) and the Practical Scaling Index (`PSI`) calculation (`Appendix A`, `A-2.2`, `Table A-4`).
   - Between the two evaporation formulations permitted by `DC-02` Section 7, this package declares and consistently applies **`SATURATED-EXIT`** (`EvaporationMethod = saturated-exit` in `CT_CALC_P.xlsx` and `EVAPMETHOD = SATURATED-EXIT` in `CT_SCHEDULE_P.dxf`). As `EC-01` Section 5 states, the life-cycle cost analysis always prices the water quantities of the `SATURATED-EXIT` formulation (the moist-air psychrometric enthalpy balance of the adopted reference implementation `EnergyPlus_src_CondenserLoopTowers.cc`). Declaring `SATURATED-EXIT` aligns the water balance sheet and allocation compliance check with the exact physical simulation and economic pricing basis, and allows the 4-cell `CTX-0600-S` plant on `ANNEX` to satisfy the amended `12,600 kgal/yr` reclaimed water allocation of `PW-LTR-019` (`12,575.9 kgal/yr <= 12,600.0 kgal/yr`).

3. **Conflict 3 — Roof Mechanical Plan Revision (`M-401 Rev C` vs. `M-401 Rev B`):**
   - Per `DC-02` Table 1/Table 2 and `RFI-022`, `M-401_ROOF_MECHANICAL_PLAN_RevC.dxf` (`Revision C`, `2026-07-31`) supersedes `Revision B`. All equipment zones (`M-EQPM-ZONE`), outdoor air intake coordinates (`M-EQPM-INTK`), and cell support frame outlines (`M-CTWR-PLAN`) are placed in the plan coordinates of `M-401 Rev C`.

---

## 3. Calculation Methodology

1. **Climatic Binning & Psychrometrics (`DC-02` Sections 5.1, 5.3, 6.6, 7):**
   - The 2022–2024 Phoenix Sky Harbor Airport (`72278023183`) dataset is filtered for `REPORT_TYPE == "FM-15"` with valid numeric dry-bulb and wet-bulb temperatures and no `'s'` suspect quality flag (`26,513` observations), then binned into `2 °F` wet-bulb by `5 °F` dry-bulb joint frequency bins (`180` non-empty bins) with bin midpoints `(WetBulb_F, DryBulb_F)` and bin hours scaled by `8760 / 26513` to sum to exactly `8,760.0 hours/year`.
   - Standard barometric pressure at station elevation `1,135 ft` (`345.948 m`) is `P_atm = 97,264.07 Pa` (`28.72206 inHg`). Moist-air properties (`PsyWFnTdbTwbPb`, `PsyRhoAirFnPbTdbW`, `PsyHFnTdbRhPb`, `PsyTsatFnHPb`, `PsyWFnTdbH`, `RhoH2O`) follow `EnergyPlus_src_Psychrometrics.cc` (`NASA TN D-8401` / `NASA TP-1466`).

2. **Chiller, Pump, and Tower Simulation (`DC-02` Sections 5.5, 6.1–6.8):**
   - **Redundancy & Cell Count Proof (`DC-02` Sections 5.5, 6.1, 6.3, Appendix A.2):** Each cell model in `VD-01` has a distribution basin maximum flow of `1.20 * Q_nom` and a YorkCalc minimum water flow rate ratio of `WFR >= 0.75`. Under `DC-02` Section 6.3, when the largest single cell is out of service (`CELLS - 1` remaining), all chillers remain online on their dedicated constant-speed condenser water pumps (`GPMTOTAL` unchanged), so each remaining cell carries `GPMTOTAL / (CELLS - 1) <= 1.20 * Q_nom`, while normal full-plant operation requires `GPMTOTAL / CELLS >= 0.75 * Q_nom`. Together these require `CELLS / (CELLS - 1) <= 1.20 / 0.75 = 1.60`, which mathematically requires `CELLS >= 3`. Because `CELLS` must be an integer multiple of `N_chillers` (`DC-02` Section 6.1), `CUP` (`2` chillers) and `ANNEX` (`2` chillers) require `CELLS = 4` (`CTX-0600-S x 4`), and `LAB` (`3` chillers) requires `CELLS = 3` (`CTX-0900-H x 3`).
   - **Coupled Thermal Balance:** In each scenario bin, building cooling load `Load_tons` is linearly interpolated from `M-603` at `DryBulb_F`. The minimum number of chillers `ChillersOn` needed to carry `Load_tons` without exceeding `MaxPLR` is staged on, determining `CWFlow_gpm = GPMTOTAL * (ChillersOn / N_ch)` and `CellsOn = CELLS * (ChillersOn / N_ch)`. The coupled chiller (`ElectricEIRChiller`) and variable-speed tower (`VariableSpeedTower` / `YorkCalc`) equations are solved simultaneously for `CWS_F`, `CWR_F`, `Range_F`, `AirFlowRatio`, and `FanPLR` under the wet-bulb reset law `CWS_set = max(CWSMIN, WetBulb_F + CWSOFFSET)`.
   - **Component Power:** Chiller electric input `ChillerkW` follows `CAPFT`, `EIRFT`, and `EIRFPLR` from `EnergyPlus_datasets_Chillers.idf`. Condenser pump power follows the cubic affinity law `PumpkW = ChillersOn * P_pump,rated * (Q_ch / Q_ref)^3`. Tower fan power follows the cubic shaft power law `FankW = CellsOn * FanPLR * BHP_design * 0.7457 / (eta_motor * 0.97)` with `eta_motor = 0.917` (`20 hp` 6-pole TEFC Premium motor per `VD-02` and `10 CFR 431.25(h) Table 5`) and `eta_VFD = 0.97`.

3. **Water Chemistry & Water Balance (`WT-01`, `UFM 3-230-13`, `PW-LTR-014`, `PW-LTR-019`):**
   - Using the `2022-07-26` complete reclaimed water sample (`TDS = 610 mg/L`, `Ca = 168 mg/L as CaCO3`, `M-Alk = 150 mg/L as CaCO3`, `SiO2 = 24.6 mg/L`, `Cl = 142 mg/L` per `WT-01` and `RFI-031`), `PSI = 2*pHeq - pHs >= 5.60` at the design point return water temperature `CWR_F` governs `MaxAllowableCOC` on all three plants (`4.142` on `CUP` at `CWR_F = 98.02 °F`; `4.001` on `ANNEX` at `CWR_F = 99.38 °F`; `3.879` on `LAB` at `CWR_F = 100.58 °F`).
   - Evaporation is computed in every bin via the `SATURATED-EXIT` moist-air enthalpy balance (`EnergyPlus_src_CondenserLoopTowers.cc`), drift is `D = 0.00002 * GPM_design_active * AirFlowRatio` (`DE-2`), blowdown is `B = max(0, (E - (COC - 1)*D) / (COC - 1))`, and makeup is `M = E + D + B`.

4. **Life-Cycle Cost Analysis (`EC-01`, `10 CFR Part 436 Subpart A`, `NIST IR 85-3273-40`):**
   - Evaluated over a `1-year` construction period plus `25-year` service period (`StudyPeriod_yr = 26`, `ConstructionPeriod_yr = 1`) at the 2025 DOE FEMP real discount rate `DiscountRate = 0.03` (`3.0%`), with `UPVStarElectricity = 15.335223`, `UPVStarWater = 20.999938`, and `UPVNonFuel = 16.905969`. Because `SS-304` has a `25-year` service life (`VD-05`), `PVReplacement_USD = $0.00` and `PVSalvage_USD = $0.00`.

---

## 4. Governing Constraints & Relative Margins per Plant

Per `DC-02` Section 8 (Table 4), the six relative margins for each plant are:

| Constraint Name (`DC-02` Table 4) | `CUP` Relative Margin | `ANNEX` Relative Margin | `LAB` Relative Margin |
|---|---|---|---|
| `water allocation` | `0.0698` | **`0.0019`** | `0.0241` |
| `electrical capacity` | **`0.0246`** | `0.0327` | **`0.0127`** |
| `roof area` | `0.1351` | `0.1351` | `0.0693` |
| `structural capacity` | `0.0250` | `0.0565` | `0.0162` |
| `condenser flow limit` | `0.2000` | `0.2000` | `0.2688` |
| `tower capability` | `0.1015` | `0.0980` | `0.0949` |

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0246)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0019)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0127)
