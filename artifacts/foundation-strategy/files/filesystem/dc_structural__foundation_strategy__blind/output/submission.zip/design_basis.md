```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 134903.44,
      "improved_cost_usd": 72282.07
    },
    "CR-P2": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 136322.13,
      "improved_cost_usd": 77075.36
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 30061.33,
      "improved_cost_usd": 48531.58
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 58913.93,
      "improved_cost_usd": 40576.95
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 14992.23,
      "improved_cost_usd": 34612.14
    },
    "CR-P6": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 113106.63,
      "improved_cost_usd": 75045.38
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 390033.32,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC_3-220-01N_Foundation_Design_2005_CANCELLED.pdf",
    "UFC_3-220-10N_Soil_Mechanics_2005_CANCELLED.pdf",
    "FHWA_GEC6_Shallow_Foundations_bridges.pdf",
    "AV-CR-2604_Basis_of_Design_Structural_Rev1_SUPERSEDED.docx",
    "AV-CR-2604_Geotechnical_Addendum_1_SUPERSEDED.pdf",
    "Adjacent_Parcel_Report_Broadview_Commons_2023.pdf",
    "NOAA_NCEI_AFI_return_periods_1951-1980.xls",
    "NOAA_NCEI_Air_Freezing_Index_return_periods.pdf",
    "NRCS_SSURGO_VA107_Loudoun_engineering_properties.json"
  ]
}
```

# Cattail Run Data Campus — Phase 1 Foundation Package: Structural & Geotechnical Design Basis

## 1. Governing Criteria vs. Cancelled, Superseded, and Inapplicable Documents Set Aside

### 1.1 Governing Criteria and Project Authority Documents
The Phase 1 foundation design for Building Pads `CR-P1` through `CR-P6` at the Cattail Run Data Campus in Loudoun County, Virginia is governed by the following live criteria, specifications, analysis manuals, and project records:
1. **Geotechnical Criteria:** `UFC 3-220-01` (*Geotechnical Engineering*, 1 November 2012, Change 3, 21 September 2022) — governs minimum factors of safety on bearing capacity by building occupancy (Section `2-4.5.1` / `1806.1`, Table `2-3`), prohibition on presumptive bearing capacities (Sections `2-4.5.2` / `1806.2` and `2-4.6.4` / `1807.3.2.3`), sliding factor of safety $\text{FS}_{\text{sliding}} \ge 2.0$ (Section `2-4.6.3` / `1807.2.3`), minimum three bearing-capacity and settlement analysis methods, total settlement limit of `1.0 in` (`25.4 mm`), angular distortion limit of `1/500` (`0.002`), and minimum footing widths of `24 in` for isolated columns and `18 in` or `wall thickness + 8 in` (`20 in`) for continuous wall footings (Section `2-4.7.1` / `1808.2`), thick-footing bar size and `12 in` maximum bar spacing (Section `2-4.7.7` / `1808.8.7`), and frost protection depth per the local municipality/AHJ (Sections `2-4.8.1` / `1809.4` and `2-4.8.4` / `1809.5`).
2. **Structural & Concrete Criteria:** `UFC 3-301-01` (*Structural Engineering*, 2023 Change 4, Sections `2-4.3` and `2-7`), `EM 1110-2-2000` (*Standard Practice for Concrete for Civil Works Structures*, Section `2-2c(3)(b)`, Table `2-2` for water-soluble sulfate exposure classification in soil), `UFGS 03 30 00` (*Cast-in-Place Concrete*, Section `2.5.2` for maximum water-cementitious materials ratio `w/cm` and minimum specified compressive strength $f'_c$ by exposure class), and `UFGS 31 00 00` (*Earthwork*, Sections `3.5` and `3.6`).
3. **Governing Analysis Manuals:** `UFC 3-220-20` (*Foundations and Earth Structures*, `DM 7.2`, 2025, Sections `4-5.1.2`, `5-2.2`, `5-3.2`, `5-3.3`, `5-5`, Equations `5-16` to `5-25`, `5-35`, Tables `5-4` to `5-6`, and Figure `5-6`), `EM 1110-1-1905` (*Bearing Capacity of Soils*, Sections `1-4d(4)`, `4-1`, `4-2`, Equations `1-6`, `4-1`, `4-2`, Tables `4-1` to `4-5`), `EM 1110-2-2502` (*Retaining and Flood Walls*, Sections `4-4`, `4-5`, `4-7`, Table `4-1`, Figure `4-4`), `EM 1110-2-2104` (*Strength Design for Reinforced Concrete Hydraulic Structures*, Sections `2.7`, `3.4`, Appendix D `D.6` for ACI 318 strength design equations, excluding Table `3-1` hydraulic load factors), and `FHWA GEC 13` (*Ground Modification Methods — Reference Manual, Volume I*, `FHWA-NHI-16-027`, Chapter 5 / Sections `4.1.2.1`, `4.2.1`, `4.2.3.1`, `4.2.3.2`, `5.2.2`, Equations `5-1`, `5-11` to `5-14`).
4. **Owner, AHJ, Geotechnical, Civil, Structural, and Cost Records:** `AV-CR-2604_Basis_of_Design_Structural_Rev3.docx` (Rev. 3), `Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf` (Amendments 3 and 4), `AV-CR-2604_RFI_log.xlsx` (`RFI-004`, `RFI-007`, `RFI-009`, `RFI-011`, `RFI-013`, `RFI-015`, `RFI-017`, `RFI-019`, `RFI-021`), `AV-CR-2604_BIM_parameter_standard.md` (Rev. 2), `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` (Rev. 2) with boring logs `B-101A` through `B-106B` and `AV-CR-2604_laboratory_test_summary.xlsx`, `NOAA_NCEI_AFI_1981-2010_rtp_tavg_afzndx.txt` (with `NOAA_NCEI_AFI_station_inventory.txt`), `AV-CR-2604_grading_and_groundwater_record.pdf` (Sheet C-301), `AV-CR-2604_base_reactions.csv`, `AV-CR-2604_column_grid.dxf`, `AV-CR-2604_load_combination_memo.docx`, `AV-CR-2604_bid_schedule_Rev1.xlsx`, and `Kettleridge_Ground_Systems_budget_proposal.pdf` (`KGS-26-0917`).

### 1.2 Documents Reviewed and Set Aside (Cancelled, Superseded, or Inapplicable)
Every predecessor, superseded, or off-site document in the data room was reviewed and explicitly set aside:
1. **`UFC_3-220-01N_Foundation_Design_2005_CANCELLED.pdf` (`UFC 3-220-01N`, 2005):** Cancelled predecessor NAVFAC `DM 7.02` manual. Set aside in favor of `UFC 3-220-01` (2012 c3) and `UFC 3-220-20` (`DM 7.2`, 2025).
2. **`UFC_3-220-10N_Soil_Mechanics_2005_CANCELLED.pdf` (`UFC 3-220-10N`, 2005):** Cancelled predecessor NAVFAC `DM 7.01` soil mechanics manual. Set aside per `RFI-019` in favor of the layered elastic compression procedure (`FHWA GEC 13` Equation `5-14`).
3. **`FHWA_GEC6_Shallow_Foundations_bridges.pdf` (`FHWA-SA-02-054`, *Evaluation of Soil and Rock Properties / Shallow Foundations for Highway Bridges*, Section `5.3.1`):** Written for highway bridge structures rather than building frames. Its Moulton et al. (1985) highway bridge angular distortion limits of `0.004` (continuous-span bridges) and `0.005` (simple-span bridges) are rejected in favor of the building angular distortion limit of `1/500` (`0.002`) in `UFC 3-220-01` Section `2-4.7.1`.
4. **`AV-CR-2604_Basis_of_Design_Structural_Rev1_SUPERSEDED.docx` (Basis of Design Rev. 1):** Superseded in its entirety by `AV-CR-2604_Basis_of_Design_Structural_Rev3.docx`. Revision 1 erroneously classified all six buildings as `Warehouse` ($\text{FS} = 2.5$), assigned freeze-thaw class `F0` to all concrete, and permitted `1-in` dimension increments and `20-ft` bearing depths.
5. **`AV-CR-2604_Geotechnical_Addendum_1_SUPERSEDED.pdf` (Geotechnical Addendum 1):** Withdrawn and superseded in its entirety by `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` following the second consolidation test series. Its uniform elastic moduli ($E_s = 320, 900, 2400\text{ ksf}$ across all pads) and `4,000 psf` presumptive bearing value are rejected.
6. **`Adjacent_Parcel_Report_Broadview_Commons_2023.pdf` (Broadview Commons Subsurface Report):** Off-site report for a different commercial parcel north of Cattail Run with different stratigraphy ($E_s = 55, 420, 2600\text{ ksf}$) and a `5,500 psf` recommended bearing pressure. Rejected per `RFI-013` and `LC-BD-26-0774` Amendment 4.
7. **`NOAA_NCEI_AFI_return_periods_1951-1980.xls` and `NOAA_NCEI_Air_Freezing_Index_return_periods.pdf` (`1951-1980` AFI Product):** Superseded NCEI return-period tables over the `1951-1980` normals period giving a 100-year AFI of `416 °F-days` at station `USC00444909` (which would falsely permit a `30-in` frost depth). Rejected per `LC-BD-26-0774` Amendment 3 and `RFI-007` in favor of the current `1981-2010` product (`556 °F-days` $\rightarrow$ `42-in` frost depth).
8. **`NRCS_SSURGO_VA107_Loudoun_engineering_properties.json` (NRCS SSURGO Regional Soil Survey):** Regional planning-level chorizon distributions retained only for qualitative index consistency (`AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 5); site-specific boring logs and laboratory tests govern all design calculations.

---

## 2. Frost Protection Depth and Climate Product Resolution

Per `UFC 3-220-01` Sections `2-4.8.1` (`1809.4`) and `2-4.8.4` (`1809.5`), shallow foundations must bear below the frost line established by the local government municipality (and at least `18 in` below grade). Loudoun County Department of Building and Development letter `LC-BD-26-0774` **Amendment 3** (and `RFI-007`) establishes:
- **County Station of Record:** NOAA NCEI cooperative station `USC00444909` (`LINCOLN`, VA; latitude `39.0878° N`, longitude `77.6928° W` in `NOAA_NCEI_AFI_station_inventory.txt`).
- **Governing Climate Product (`1981-2010` normals period):** In `NOAA_NCEI_AFI_1981-2010_rtp_tavg_afzndx.txt`, for station `USC00444909 LINCOLN`, the `.990` exceedance probability column (100-year return period) gives **`afi_100yr_F_days = 556` °F-days** (`afi_product_period = "1981-2010"`).
- **Superseded Climate Product (`1951-1980` normals period):** In `NOAA_NCEI_AFI_return_periods_1951-1980.xls` and `NOAA_NCEI_Air_Freezing_Index_return_periods.pdf`, station `USC00444909` had **`superseded_afi_100yr_F_days = 416` °F-days** (`superseded_product_period = "1951-1980"`).
- **Governing Frost Depth (`frost_depth_in = 42`):** Because $556\text{ °F-days} > 500\text{ °F-days}$, `LC-BD-26-0774` Amendment 3 mandates a minimum foundation bearing depth of **`42 in`** (`3.50 ft`) below finished grade across all six building pads. All selected foundations on `CR-P1` through `CR-P6` are founded at $D_f = 42\text{ in}$ (`3.50 ft`).

---

## 3. Bearing-Capacity Methods, Groundwater Correction, and Factor of Safety Basis

### 3.1 Three Bearing-Capacity Methods and One-Sided Reporting Basis (`RFI-021`)
In accordance with `UFC 3-220-01` Section `2-4.7.1` (`1808.2`), `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 7, `LC-BD-26-0774` Amendment 4, and `RFI-009`, the preliminary presumptive bearing pressure of `3,000 psf` (as well as the withdrawn `4,000 psf` in Addendum 1 and `5,500 psf` in the Broadview Commons report) is rejected. Ultimate and net allowable bearing capacities at every foundation are derived from site-specific drained shear strength parameters (Stratum I `CL-ML`: $\gamma = 118\text{ pcf}, \phi' = 26.0^\circ, c' = 0.25\text{ ksf}$; Stratum II `SM`: $\gamma = 126\text{ pcf}, \phi' = 33.0^\circ, c' = 0.00\text{ ksf}$; Stratum III: $\gamma = 132\text{ pcf}, \phi' = 38.0^\circ, c' = 0.00\text{ ksf}$) using three widely accepted methods under `SERVICE_D_PLUS_L`:
1. **Vesic / General Bearing-Capacity Equation (`UFC 3-220-20` / `DM 7.2` Section `5-3.2`, Equations `5-16` to `5-25`, Tables `5-4` to `5-6`; `EM 1110-1-1905` Table `4-1` & `4-5`):**
   $$q_{\text{ult}} = c' N_c s_c d_c + \sigma'_D N_q s_q d_q + 0.5 \gamma_e B N_\gamma s_\gamma d_\gamma$$
   where $N_q = e^{\pi \tan\phi'} \tan^2(45^\circ + \phi'/2)$, $N_c = (N_q - 1)\cot\phi'$, and $N_\gamma = 2(N_q + 1)\tan\phi'$ (`11.854`, `22.254`, and `12.539` for Stratum I $\phi' = 26^\circ$), with shape factors $s_c = 1 + (B/L)(N_q/N_c)$, $s_q = 1 + (B/L)\tan\phi'$, $s_\gamma = 1 - 0.4(B/L)$ and depth factors $d_c = 1 + 0.4 k$, $d_q = 1 + 2\tan\phi'(1 - \sin\phi')^2 k$, $d_\gamma = 1.0$ ($k = D_f/B$ for $D_f/B \le 1$, else $\tan^{-1}(D_f/B)$).
2. **Meyerhof Method (`EM 1110-1-1905` Section `4-1`, Table `4-1` & `4-3`):** $N_\gamma = (N_q - 1)\tan(1.4\phi') = 8.002$ (for $\phi' = 26^\circ$), with Meyerhof shape and depth factors $s_c = 1 + 0.2 K_p (B/L)$, $s_q = s_\gamma = 1 + 0.1 K_p (B/L)$, $d_c = 1 + 0.2\sqrt{K_p}(D_f/B)$, $d_q = d_\gamma = 1 + 0.1\sqrt{K_p}(D_f/B)$ where $K_p = \tan^2(45^\circ + \phi'/2)$.
3. **Hansen Method (`EM 1110-1-1905` Section `4-1`, Table `4-1` & `4-4`):** $N_\gamma = 1.5(N_q - 1)\tan\phi' = 7.941$ (for $\phi' = 26^\circ$), with Hansen/Vesic shape and depth factors.

Per `RFI-021`, the net allowable bearing pressure is $q_{\text{allow,net}} = (q_{\text{ult}} - \sigma'_D) / \text{FS}_{\text{bearing}}$, and the reported design allowable value (`q_allow_net_ksf`) is evaluated using the general bearing-capacity equation of `UFC 3-220-20` with the conservative envelope of the `UFC 3-220-20` Figure `5-6` and `EM 1110-1-1905` Equation `1-6` groundwater submergence corrections (so that it is never more permissive than `UFC 3-220-20` under either groundwater interpolation formula).

### 3.2 Groundwater Correction (`UFC 3-220-20` Figure 5-6 & `EM 1110-1-1905` Equation 1-6)
Stabilised design groundwater depths from `AV-CR-2604_grading_and_groundwater_record.pdf` Section 2 (`CR-P1`: `8.0 ft`, `CR-P2`: `9.0 ft`, `CR-P3`: `19.0 ft`, `CR-P4`: `8.0 ft`, `CR-P5`: `21.0 ft`, `CR-P6`: `8.5 ft`) govern over transient drilling water levels on the boring logs. Where the depth from the bearing elevation to the water table $d_w = D_{\text{GWT}} - D_f$ is less than the footing width $B$, the effective unit weight $\gamma_e$ in the $0.5 \gamma_e B N_\gamma$ term is reduced using $\gamma' = \gamma - 62.4\text{ pcf}$ (`55.6 pcf` in Stratum I):
- `UFC 3-220-20` Figure `5-6`: $\gamma_e = [2(d_w/B) - (d_w/B)^2]\gamma + [1 - (d_w/B)]^2 \gamma'$
- `EM 1110-1-1905` Equation `1-6`: $\gamma_e = \gamma' + (d_w/B)(\gamma - \gamma')$
Taking $\min(\gamma_{e,\text{UFC}}, \gamma_{e,\text{EM}})$ ensures strict compliance under both formulations.

### 3.3 Basis of Factor of Safety by Pad (`UFC 3-220-01` Table 2-3 & `BOD Rev. 3` Section 2)
Per `AV-CR-2604_Basis_of_Design_Structural_Rev3.docx` Section 2 and `UFC 3-220-01` Section `2-4.5.1` (`1806.1`) Table `2-3`:
- **`CR-P1` (Data Hall 1), `CR-P2` (Data Hall 2), `CR-P3` (Electrical Yard Building), and `CR-P6` (Data Hall 3):** Structure category = `"Light Industrial, Public"` $\rightarrow \mathbf{\text{FS}_{\text{bearing}} = 3.5}$.
- **`CR-P4` (Administration and Operations Building):** Structure category = `"Apartments, Office"` $\rightarrow \mathbf{\text{FS}_{\text{bearing}} = 3.0}$.
- **`CR-P5` (Logistics and Spares Warehouse):** Structure category = `"Warehouse"` $\rightarrow \mathbf{\text{FS}_{\text{bearing}} = 2.5}$.

---

## 4. Settlement Methods and Tolerable-Movement Criteria Adopted vs. Rejected

### 4.1 Layered Elastic Settlement Procedure (`RFI-019` & `FHWA GEC 13` Equation 5-14)
Because `UFC 3-220-10N` (2005) is cancelled and `EM 1110-1-1904` is not in the data room, `RFI-019` specifies the exact project settlement procedure under `SERVICE_D_PLUS_L` (rejecting the combined-footing/mat subgrade-reaction estimator of `UFC 3-220-20` Chapter 6):
- **Unimproved Spread Footings (`SPREAD`):** Subdivide the soil profile from the bearing surface ($z' = 0$) to a depth $Z_{\max} = \max(4B, 40.0\text{ ft})$ below the bearing surface into uniform layers of thickness $\Delta z = 0.25\text{ ft}$. At the mid-height $z'_k = (k + 0.5)\Delta z$ of each layer, compute the net vertical stress increment using the 2V:1H rectangular stress distribution $\Delta\sigma_k = P / [(B + z'_k)(L + z'_k)]$ and sum the layer compressions using the pad-specific secant elastic moduli $E_s(D_f + z'_k)$ from `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 2:
  $$s = 12 \sum_{k=1}^{N} \frac{\Delta\sigma_k \, \Delta z}{E_s(D_f + z'_k)} \quad (\text{in})$$
  where the base of Stratum I at each foundation station along Column Line A (`F1`=0.0, `F2`=24.0, `F3`=44.0, `F4`=60.0, `F5`=72.0, `W1`=77.0 ft) is linearly interpolated between STA 0.0 ft and STA 77.0 ft and rounded to `0.1 ft`.
- **Aggregate-Pier Improved Spread Footings (`IMPROVED_SPREAD`):** Apply the two-layer method of `FHWA GEC 13` Section `4.2.3` (`Equations 5-11` to `5-14`), $s_{\text{tot}} = s_{\text{uz}} + s_{\text{lz}}$, where the upper-zone compression over the pier treatment depth $0 \le z' \le H_{\text{uz}}$ is $s_{\text{uz}} = q_g / k_g$ (`Equation 5-13`) and the lower-zone compression below the pier tips ($H_{\text{uz}} < z' \le \max(4B, 40.0\text{ ft})$) is evaluated by the identical `0.25-ft` layered 2V:1H elastic sum (`Equation 5-14`). Per `RFI-017`, each foundation is analysed as an individual unit with no group reduction factor for overlapping zones of influence.

### 4.2 Tolerable-Movement Criteria Adopted and Competing Bridge Criteria Rejected
- **Adopted Building Limits (`UFC 3-220-01` Section `2-4.7.1` / `1808.2`):**
  1. **Maximum Total Settlement:** $s_{\text{tot}} \le \mathbf{1.000\text{ in}}$ (`25.4 mm`).
  2. **Maximum Angular Distortion Between Adjacent Foundations:** $\beta_{ij} = |s_i - s_j| / L_{ij} \le \mathbf{1/500 = 0.00200\text{ rad}}$ across all five bays along Column Line A (`F1-F2` = 288 in, `F2-F3` = 240 in, `F3-F4` = 192 in, `F4-F5` = 144 in, `F5-W1` = 60 in).
- **Rejected Competing Criteria (`FHWA GEC 6` Section `5.3.1`):** The Moulton et al. (1985) highway bridge angular distortion limits in `FHWA_GEC6_Shallow_Foundations_bridges.pdf` Section `5.3.1` (`0.004` for continuous-span bridges and `0.005` for simple-span bridges) apply to highway bridge superstructures and are explicitly rejected for data-campus building structures.

---

## 5. Ground-Improvement Design Parameters and Authorities

For all foundations supported on rammed aggregate piers (`IMPROVED_SPREAD` on `CR-P1`, `CR-P2`, `CR-P4`, and `CR-P6`), the design parameters and their governing authorities are:
1. **Pier Diameter (`pier_diameter_in = 30`):** Installed diameter $d_p = 30\text{ in} = 2.50\text{ ft}$ ($A_p = \pi d_p^2 / 4 = 4.90874\text{ ft}^2$) per `Kettleridge_Ground_Systems_budget_proposal.pdf` (`KGS-26-0917`) Section 2.
2. **Stress Concentration Ratio (`stress_concentration_ratio_ns = 10.0`):** $n_s = 10.0$ for structure foundation support under rigid footings per `FHWA GEC 13` Section `4.2.1` (page `5-43`) and `RFI-011`. Proprietary Geopier vendor manual values of `20` or higher mentioned in `FHWA GEC 13` Section `4.2.1` are explicitly rejected per `RFI-011`.
3. **Area Replacement Ratio Bounds ($0.33 \le R_a \le 0.4007$):**
   - **Minimum Bound:** $R_{a,\min} = 0.33$ per `FHWA GEC 13` Section `4.2.1` (citing the HITEC Evaluation Report, Collin 2007).
   - **Maximum Geometric Bound:** Minimum clear spacing between adjacent 30-in piers is `1.0 ft` (`Kettleridge` Section 2), giving minimum center-to-center spacing $s_{\min} = 2.5 + 1.0 = 3.5\text{ ft}$. On a square grid, the maximum achievable replacement ratio is $R_{a,\max,\text{sq}} = A_p / s_{\min}^2 = 4.90874 / 12.25 = \mathbf{0.4007}$ (and on a staggered triangular grid, $A_p / [(\sqrt{3}/2)s_{\min}^2] = 0.4627$). Every improved footing is designed with $0.334 \le R_a \le 0.381$, satisfying both square and staggered grid limits with margin.
4. **Top-of-Pier Stress Limit ($q_g \le 18,000\text{ psf}$):** Computed via `FHWA GEC 13` Section `4.2.3.1` Equation `5-12`, $q_g = q [n_s / (n_s R_a - R_a + 1)]$, and capped at $q_{g,\max} = 18,000\text{ psf}$ (`Kettleridge` Section 2). Maximum design $q_g$ across all improved footings is `16,884 psf` (on `CR-P4` `F3`).
5. **Pad-Specific As-Tested Pier Stiffness Modulus (`stiffness_modulus_pci`):** Taken from the June 2026 pre-production sacrificial pier modulus load tests in `Kettleridge` Section 3 (`CR-P1`: `165 pci` [MT-01], `CR-P2`: `140 pci` [MT-02], `CR-P3`: `210 pci` [MT-03], `CR-P4`: `195 pci` [MT-04], `CR-P5`: `230 pci` [MT-05], `CR-P6`: `155 pci` [MT-06]).
6. **Treatment Depth Bounds ($8\text{ ft} \le \text{pier\_depth\_ft} \le 25\text{ ft}$):** Installed in whole feet below the footing soffit (`Kettleridge` Section 2). At each improved foundation `ft`, `pier_depth_ft` is selected as $\max(8, \lceil z_1(ft) - D_f \rceil)$ so that every pier penetrates completely through the compressible Stratum I (`CL-ML`) into dense Stratum II (`SM`), while at the pad level `treatment_depth_ft` is the deepest treatment depth used on that pad (`AV-CR-2604_BIM_parameter_standard.md` Rev. 2): `CR-P1` = `9 ft` (`669.0 LF`), `CR-P2` = `10 ft` (`687.0 LF`), `CR-P4` = `8 ft` (`360.0 LF`), and `CR-P6` = `11 ft` (`678.0 LF`).
7. **Verification Testing Programme (`modulus_tests = 1` per improved pad):** One production modulus load test per improved pad loaded to `150%` of maximum design top-of-pier stress (`FHWA GEC 13` Section `5.2.2`, `Kettleridge` Sections 2 and 5) at `$9,500 / EA`.

---

## 6. Reinforced-Concrete Footing Design, Stability, and Durability Resolution

1. **Sulfate Exposure and Concrete Mix Selection (`EM 1110-2-2000` Table 2-2, `UFGS 03 30 00` §2.5.2, `BOD Rev. 3` §2–3):**
   - From `AV-CR-2604_laboratory_test_summary.xlsx`, the governing (more severe) water-soluble sulfate concentration in dry Stratum I soil is:
     - `CR-P1`: $\max(0.14\%, 0.135\%) = \mathbf{0.14\%} \in [0.10\%, 0.20\%] \rightarrow$ Moderate Sulfate (`S1`), classes `["F1", "S1", "W1", "C1"]` $\rightarrow \text{w/cm} \le 0.50, f'_c = \mathbf{4,000\text{ psi}}$ (`$196/CY`).
     - `CR-P2`: $\max(0.23\%, 0.225\%) = \mathbf{0.23\%} \in [0.20\%, 2.00\%] \rightarrow$ Severe Sulfate (`S2`), classes `["F1", "S2", "W1", "C1"]` $\rightarrow \text{w/cm} \le 0.45, f'_c = \mathbf{4,500\text{ psi}}$ (`$211/CY`).
     - `CR-P3`: $\max(0.07\%, 0.065\%) = \mathbf{0.07\%} < 0.10\% \rightarrow$ Negligible Sulfate (`S0`), classes `["F1", "S0", "W1", "C1"]` (`W1` governs over `F1`/`S0`/`C1`) $\rightarrow \text{w/cm} \le 0.50, f'_c = \mathbf{4,000\text{ psi}}$ (`$196/CY`).
     - `CR-P4`: $\max(0.11\%, 0.105\%) = \mathbf{0.11\%} \in [0.10\%, 0.20\%] \rightarrow$ Moderate Sulfate (`S1`), classes `["F1", "S1", "W1", "C1"]` $\rightarrow \text{w/cm} \le 0.50, f'_c = \mathbf{4,000\text{ psi}}$ (`$196/CY`).
     - `CR-P5`: $\max(0.05\%, 0.045\%) = \mathbf{0.05\%} < 0.10\% \rightarrow$ Negligible Sulfate (`S0`), classes `["F3", "S0", "W1", "C1"]` (`F3` de-icing chemical exposure governs) $\rightarrow \text{w/cm} \le 0.40, f'_c = \mathbf{5,000\text{ psi}}$ (`$228/CY`).
     - `CR-P6`: $\max(0.26\%, 0.255\%) = \mathbf{0.26\%} \in [0.20\%, 2.00\%] \rightarrow$ Severe Sulfate (`S2`), classes `["F1", "S2", "W1", "C1"]` $\rightarrow \text{w/cm} \le 0.45, f'_c = \mathbf{4,500\text{ psi}}$ (`$211/CY`).
2. **Footing Shear and Flexure (`UFC 3-301-01` §2-4.3 & §2-7, `EM 1110-2-2104` §2.7, §3.4, Appendix D `D.6`, `BOD Rev. 3` §3):**
   - Designed under `STRENGTH_1.2D_1.6L` (excluding the hydraulic load factors of `EM 1110-2-2104` Table `3-1` per `AV-CR-2604_load_combination_memo.docx` Section 3) with $\phi_v = 0.75$ for one-way beam shear ($\phi V_{c1} = \phi 2\sqrt{f'_c} b d$ at distance $d$ from column/wall face) and two-way punching shear ($\phi V_{c2} = \phi 4\sqrt{f'_c} b_0 d$ at perimeter $d/2$ from column face), and $\phi_f = 0.90$ for flexure at the column/wall face with $d = T - 4\text{ in}$ and $f_y = 60,000\text{ psi}$.
   - The project minimum reinforcement ratio $\rho_{\min} = 0.0018$ of gross area in each direction (`BOD Rev. 3` Section 3) governs over the `0.0015` thick-footing minimum of `UFC 3-220-01` Section `2-4.7.7` (`1808.8.7`). All bars are `#5` to `#9` ($\ge \text{#4}$) at `4 in` to `12 in` spacing ($\le 12\text{ in}$).
3. **Continuous Shear-Wall Footing (`W1`) Stability (`UFC 3-220-01` §2-4.6.3, `EM 1110-2-2502` §4-4 to §4-7, `UFC 3-220-20` §5-5, `load_combination_memo.docx` §2–3):**
   - **Sliding (`0.6D_PLUS_W`):** $\text{FS}_{\text{sliding}} = [P_{0.6D+W} + 0.6(W_{\text{conc}} + W_{\text{soil}})] \tan(\frac{2}{3}\phi') / |H_x| = 2.48\text{ to }2.55 \ge 2.00$ (`UFC 3-220-01` Section `2-4.6.3` governs over the `1.5` factor in `EM 1110-2-2502` Table `4-1`).
   - **Overturning Resultant Location (`SERVICE_D_PLUS_L_PLUS_W`):** $e = 6.53\text{ to }6.66\text{ in} \le B/6$ (`11.00 to 26.50 in`), keeping the service resultant well inside the middle third (`EM 1110-2-2502` Section `4-5a`).
   - **Uplift (`UPLIFT_W` with `DEAD_ONLY`):** $\text{FS}_{\text{uplift}} = 0.6(W_{\text{conc}} + W_{\text{soil}} + P_{\text{DEAD\_ONLY}}) / |P_{\text{UPLIFT\_W}}| = 2.83\text{ to }3.01 \ge 1.50$ (`UFC 3-220-20` Section `5-5` Equation `5-35`).

---

## 7. Summary of Document Conflict Resolutions

| Conflict Topic | Competing Sources | Governing Authority & Resolution | Governing Value Adopted |
| :--- | :--- | :--- | :--- |
| **100-yr Air Freezing Index & Frost Depth** | `1981-2010` NCEI product (`556 °F-days`) vs. `1951-1980` NCEI product (`416 °F-days`) | `LC-BD-26-0774` Amendment 3 & `RFI-007`: current `1981-2010` normals period at `USC00444909` (`LINCOLN`, VA) governs (`> 500 °F-days` $\rightarrow 42\text{ in}$). | **`556 °F-days`** (`1981-2010`) $\rightarrow$ **`42 in`** (`3.5 ft`) |
| **Building Occupancy & Bearing `FS`** | `BOD Rev. 3` Section 2 vs. `BOD Rev. 1` Section 2 (all `Warehouse`) | `BOD Rev. 3` supersedes Rev. 1; mapped to `UFC 3-220-01` Table `2-3`. | `CR-P1/P2/P3/P6`: **`3.5`**; `CR-P4`: **`3.0`**; `CR-P5`: **`2.5`** |
| **Soil Elastic Moduli $E_s$** | `Geotechnical Data Report Rev. 2` Section 2 vs. `Addendum 1` (`320/900/2400 ksf`) vs. `Broadview Commons` (`55/420/2600 ksf`) | `Geotechnical Data Report Rev. 2` supersedes Addendum 1; `RFI-013` rejects off-site Broadview Commons report. | Pad-specific $E_{s,I} = 85\text{–}250\text{ ksf}$, $E_{s,II} = 1400\text{–}1800\text{ ksf}$, $E_{s,III} = 3400\text{–}3800\text{ ksf}$ |
| **Presumptive vs. Analytical Bearing Capacity** | `3,000 psf` (GDR Rev. 2 §7), `4,000 psf` (Addendum 1), `5,500 psf` (Broadview Commons) vs. 3-method analysis | `UFC 3-220-01` §2-4.5.2, `LC-BD-26-0774` Amendment 4, `RFI-009`, `RFI-021`: presumptive values prohibited; site-specific analysis required. | Site-specific `UFC 3-220-20` general bearing-capacity equation (`5.45 to 8.68 ksf`) |
| **Tolerable Angular Distortion** | `UFC 3-220-01` §2-4.7.1 (`1/500 = 0.002`) vs. `FHWA GEC 6` §5.3.1 (`0.004` / `0.005` for highway bridges) | `UFC 3-220-01` §2-4.7.1 governs buildings; `FHWA GEC 6` is for highway bridges and is rejected. | **`0.00200 rad`** (`1/500`) |
| **Settlement Calculation Procedure** | `RFI-019` layered elastic compression (`FHWA GEC 13` Eq. 5-14) vs. cancelled `UFC 3-220-10N` (2005) vs. `DM 7.2` mat subgrade modulus | `RFI-019` mandates 2V:1H layered elastic compression over `0.25-ft` layers to $\max(4B, 40\text{ ft})$. | `0.25-ft` layered 2V:1H elastic compression to $\max(4B, 40\text{ ft})$ |
| **Aggregate-Pier Stress Ratio $n_s$** | `FHWA GEC 13` §4.2.1 rigid footing value (`10`) vs. proprietary Geopier manual values (`20+`) | `RFI-011` mandates the `FHWA GEC 13` §4.2.1 value for structure foundation support under rigid footings. | **`10.0`** |
| **Sliding Factor of Safety** | `UFC 3-220-01` §2-4.6.3 (`FS >= 2.0`) vs. `EM 1110-2-2502` Table 4-1 / `UFC 3-220-20` Table 4-7 (`FS >= 1.5`) | Governing geotechnical criteria `UFC 3-220-01` §2-4.6.3 (`1807.2.3`) requires $\text{FS}_{\text{sliding}} \ge 2.0$. | **`2.00`** |
| **Concrete Strength & Reinforcement** | `EM 1110-2-2104` Table 3-1 hydraulic load factors vs. `UFC 3-301-01` `1.2D+1.6L`; `BOD Rev. 3` $\rho_{\min} = 0.0018$ vs. `UFC 3-220-01` `0.0015` | `load_combination_memo.docx` §3 excludes hydraulic load factors; higher $\rho_{\min} = 0.0018$ in `BOD Rev. 3` §3 governs. | `1.2D + 1.6L` ($\phi_v = 0.75, \phi_f = 0.90$); $\rho_{\min} = \mathbf{0.0018}$ each way |
| **Groundwater Depth** | Piezometer record `C-301` 30-day stabilised depths vs. boring log drilling water levels | `Geotechnical Data Report Rev. 2` §6 and `grading_and_groundwater_record.pdf` §2: 30-day stabilised piezometer depths govern. | `CR-P1`: `8.0'`, `CR-P2`: `9.0'`, `CR-P3`: `19.0'`, `CR-P4`: `8.0'`, `CR-P5`: `21.0'`, `CR-P6`: `8.5'` |

---

## 8. Campus Programme Optimisation Reasoning (Which Pads Are Improved and Why 2 Rigs Are Mobilised)

Under `Kettleridge_Ground_Systems_budget_proposal.pdf` (`KGS-26-0917`) Section 4, ground improvement mobilisation is purchased as a lump sum of **`$40,000 per rig`**, and each mobilised rig can serve **at most 2 building pads** within the Phase 1 milestone window ($N_{\text{rigs}} = \lceil N_{\text{improved pads}} / 2 \rceil$). Comparing the minimum compliant `SPREAD` cost against the minimum compliant `IMPROVED_SPREAD` cost (including the `$9,500` production modulus test per improved pad) across all six pads reveals a decisive physical and economic split:

1. **Pads Where `IMPROVED_SPREAD` Saves Massive Excavation, Dewatering, and Concrete Costs (`CR-P1`, `CR-P2`, `CR-P6`, and `CR-P4`):**
   - On the three heavy Data Hall pads **`CR-P1`** ($E_{s,I} = 110\text{ ksf}$), **`CR-P2`** ($E_{s,I} = 85\text{ ksf}$), and **`CR-P6`** ($E_{s,I} = 95\text{ ksf}$), unimproved spread footings founded at the `42-in` (`3.5-ft`) frost depth cannot satisfy the `1.0-in` total settlement limit regardless of plan width. To make `SPREAD` work on `CR-P1`, `CR-P2`, and `CR-P6`, the bearing elevation must be lowered to $D_f = 102\text{ to }132\text{ in}$ (`8.5 to 11.0 ft`) to remove most or all of the soft Stratum I layer, incurring deep sloped open-cut excavation below `4.0 ft` (`1.5H:1V` side slopes), structural backfill, and construction dewatering below the `8.0 to 9.0 ft` water table (`$4,200/day` at `3.0 days/ft`). Supporting these three pads on rammed aggregate piers at $D_f = 42\text{ in}$ eliminates dewatering and deep sloped excavation, saving:
     - **`CR-P1`:** `$134,903.44` (`SPREAD`) vs. `$72,282.07` (`IMPROVED_SPREAD`) $\rightarrow$ **saves `$62,621.37`**
     - **`CR-P2`:** `$136,322.13` (`SPREAD`) vs. `$77,075.36` (`IMPROVED_SPREAD`) $\rightarrow$ **saves `$59,246.77`**
     - **`CR-P6`:** `$113,106.63` (`SPREAD`) vs. `$75,045.38` (`IMPROVED_SPREAD`) $\rightarrow$ **saves `$38,061.25`**
   - Improving the three Data Hall pads (`CR-P1`, `CR-P2`, `CR-P6`) requires $\lceil 3 / 2 \rceil = \mathbf{2\text{ rigs}}$ (`$80,000` mobilisation), leaving **one spare pad slot on the second mobilised rig at zero marginal rig mobilisation cost**!
   - On **`CR-P4`** (Administration and Operations Building, $E_{s,I} = 130\text{ ksf}, \text{FS} = 3.0$), an unimproved `SPREAD` design at $D_f = 42\text{ in}$ is feasible only by substantially oversizing the footings (`B = 111 to 267 in`) to keep total settlement within `1.000 in`, costing **`$58,913.93`**. Using the spare fourth capacity slot on the second already-mobilised rig to install `8-ft` aggregate piers under `CR-P4` allows the footings to be sized purely to bearing capacity (`B = 87 to 138 in`), reducing `CR-P4`'s pad cost to **`$40,576.95`** (including its `$9,500` production modulus test) and **saving an additional `$18,336.98`** with zero additional rig mobilisation!

2. **Pads Where Shallow `SPREAD` Footings Are Optimal (`CR-P3` and `CR-P5`):**
   - On **`CR-P3`** (Electrical Yard Building, $E_{s,I} = 210\text{ ksf}$, shallow Stratum I base at `5.5 to 7.0 ft`, deep groundwater at `19.0 ft`), unimproved `SPREAD` footings at $D_f = 42\text{ in}$ satisfy both bearing capacity ($\text{FS} = 3.5$) and total settlement ($s_{\max} = 0.995\text{ in} \le 1.000\text{ in}$) for **`$30,061.33`**, whereas `IMPROVED_SPREAD` would cost **`$48,531.58`** (plus an extra `$40,000` third rig mobilisation if more than 4 pads were improved).
   - On **`CR-P5`** (Logistics and Spares Warehouse, $E_{s,I} = 250\text{ ksf}$, shallow Stratum I base at `4.5 to 5.5 ft`, $\text{FS} = 2.5$, deep groundwater at `21.0 ft`), unimproved `SPREAD` footings at $D_f = 42\text{ in}$ achieve $s_{\max} = 0.867\text{ in} \le 1.000\text{ in}$ for **`$14,992.23`**, whereas `IMPROVED_SPREAD` would cost **`$34,612.14`**.

3. **Global Campus Cost Comparison across Rig Counts:**
   - **0 Rigs (All 6 Pads `SPREAD`):** `$488,299.69`
   - **1 Rig (2 Best Pads Improved: `CR-P1`, `CR-P2` + $40,000 mob):** `$406,431.55`
   - **2 Rigs (3 Pads Improved: `CR-P1`, `CR-P2`, `CR-P6` + $80,000 mob):** `$408,370.30`
   - **2 Rigs (4 Pads Improved: `CR-P1`, `CR-P2`, `CR-P4`, `CR-P6` + $80,000 mob):** **`$390,033.32`** (**Global Minimum**)
   - **3 Rigs (5 or 6 Pads Improved + $120,000 mob):** `$448,503.57` (5 pads) / `$468,123.48` (6 pads)

Accordingly, improving exactly four pads (**`CR-P1`, `CR-P2`, `CR-P4`, `CR-P6`**) with **2 mobilised rigs** (`RIG-1` serving `CR-P1` and `CR-P2`; `RIG-2` serving `CR-P4` and `CR-P6`, mobilisation cost = **`$80,000.00`**) while founding **`CR-P3`** and **`CR-P5`** on unimproved shallow **`SPREAD`** footings at $D_f = 42\text{ in}$ achieves the minimum compliant total campus cost of **`$390,033.32`**.
