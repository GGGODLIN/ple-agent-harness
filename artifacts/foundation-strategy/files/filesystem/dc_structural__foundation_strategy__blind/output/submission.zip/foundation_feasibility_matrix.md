# Cattail Run Data Campus — Phase 1 Foundation Feasibility and Optimisation Matrix

## 1. Campus Programme Summary

| Pad ID | Building | Occupancy Category (`UFC 3-220-01` Table 2-3) | Bearing `FS` | Exposure Classes | Concrete `f'c` (psi) / `w/cm` | Governing Constraint | Spread-Only Cost (USD) | Improved-Spread Cost (USD) | Selected System | Selected Pad Cost (USD) |
| :--- | :--- | :--- | :---: | :---: | :---: | :--- | ---: | ---: | :--- | ---: |
| `CR-P1` | Data Hall 1 | Light Industrial, Public | 3.5 | `F1,S1,W1,C1` | 4000 / 0.50 | `BEARING` | $134,903.44 | $72,282.07 | `IMPROVED_SPREAD` | $72,282.07 |
| `CR-P2` | Data Hall 2 | Light Industrial, Public | 3.5 | `F1,S2,W1,C1` | 4500 / 0.45 | `BEARING` | $136,322.13 | $77,075.36 | `IMPROVED_SPREAD` | $77,075.36 |
| `CR-P3` | Electrical Yard Building | Light Industrial, Public | 3.5 | `F1,S0,W1,C1` | 4000 / 0.50 | `SETTLEMENT` | $30,061.33 | $48,531.58 | `SPREAD` | $30,061.33 |
| `CR-P4` | Administration and Operations Building | Apartments, Office | 3.0 | `F1,S1,W1,C1` | 4000 / 0.50 | `BEARING` | $58,913.93 | $40,576.95 | `IMPROVED_SPREAD` | $40,576.95 |
| `CR-P5` | Logistics and Spares Warehouse | Warehouse | 2.5 | `F3,S0,W1,C1` | 5000 / 0.40 | `BEARING` | $14,992.23 | $34,612.14 | `SPREAD` | $14,992.23 |
| `CR-P6` | Data Hall 3 | Light Industrial, Public | 3.5 | `F1,S2,W1,C1` | 4500 / 0.45 | `BEARING` | $113,106.63 | $75,045.38 | `IMPROVED_SPREAD` | $75,045.38 |
| **Sub-Total (Pads)** | — | — | — | — | — | — | **$488,299.69** | **$348,123.48** | **4 Improved / 2 Spread** | **$310,033.32** |
| **Rig Mobilisation** | 2 rigs (`RIG-1`: `CR-P1`, `CR-P2`; `RIG-2`: `CR-P4`, `CR-P6`) at $40,000/rig (max 2 pads/rig) | — | — | — | — | — | $0.00 | $120,000.00 (3 rigs if all 6) | **2 Rigs Mobilised** | **$80,000.00** |
| **Campus Total** | — | — | — | — | — | — | **$488,299.69** | **$468,123.48** | **Optimal Programme** | **$390,033.32** |

## CR-P1 — Data Hall 1

- **Occupancy & Bearing Factor of Safety:** `Light Industrial, Public` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 3.5$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 110\text{ ksf}$) linearly interpolated from `6.0 ft` at STA `0.0 ft` (`F1`) to `12.5 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1500\text{ ksf}$) thickness = `14.0 ft`; Stratum III ($E_{s,III} = 3500\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 8.0\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.14%` $\rightarrow$ Exposure `S1` (`EM 1110-2-2000` Table 2-2); combined classes `['F1', 'S1', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 4000\text{ psi}$ ($196.00/CY) and $\text{w/cm} \le 0.50$.
- **Pad-Level Governing Constraint:** `BEARING`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$134,903.44` (bearing depth $D_f = 120\text{ in} = 10.00\text{ ft}$, dewatering = `6` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$72,282.07` excluding rig mobilisation (`$92,282.07` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 165\text{ pci}$, deepest treatment depth = `9 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`IMPROVED_SPREAD`** at **`$72,282.07`** (saves **`$62,621.38`** in pad construction cost before rig mobilisation).

### CR-P1 Selected Foundation Schedule and Engineering Checks (`IMPROVED_SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 6.0 | 610.0 | 838.0 | `123 × 123 × 27` | `0.002068` (`#7 @ 10"`) | 5.806 | **5.865** [6.03 / 5.69 / 5.53] | 99.0% | 0.682 | 0.00043 | 8 × 30" × 8' (Ra=0.374, qg=13304) | `BEARING` | $5,447.60 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 8.0 | 1180.0 | 1622.0 | `171 × 171 × 39` | `0.002018` (`#8 @ 10"`) | 5.811 | **5.949** [6.16 / 5.90 / 5.53] | 97.7% | 0.807 | 0.00043 | 14 × 30" × 8' (Ra=0.338, qg=14363) | `BEARING` | $11,585.22 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 9.7 | 1420.0 | 1953.0 | `186 × 186 × 42` | `0.002087` (`#8 @ 9"`) | 5.911 | **5.992** [6.21 / 5.98 / 5.54] | 98.6% | 0.842 | 0.00031 | 17 × 30" × 8' (Ra=0.347, qg=14325) | `BEARING` | $14,320.44 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 11.1 | 980.0 | 1348.0 | `156 × 156 × 33` | `0.002319` (`#5 @ 4"`) | 5.799 | **5.913** [6.11 / 5.83 / 5.52] | 98.1% | 0.782 | 0.00083 | 12 × 30" × 8' (Ra=0.349, qg=14017) | `BEARING` | $9,264.82 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 12.1 | 520.0 | 715.0 | `114 × 114 × 24` | `0.002302` (`#7 @ 10"`) | 5.762 | **5.864** [6.02 / 5.66 / 5.54] | 98.3% | 0.662 | 0.00175 | 7 × 30" × 9' (Ra=0.381, qg=13016) | `BEARING` | $4,809.13 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 12.5 | 1650.0 | 2244.0 | `153 × 288 × 30` | `0.003103` (`#8 @ 8"`) | 5.392 | **5.451** [5.71 / 5.08 / 4.94] | 98.9% | 0.767 | 0.00175 | 22 × 30" × 9' (Ra=0.353, qg=12912) | `BEARING` | $17,354.86 |

### CR-P1 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 708.0\text{ kips}, H_x = 96.0\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.59} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 1650.0\text{ kips}, H_x = 96.0\text{ kips}, M_y = 880.0\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{7.47\text{ in}} \le B/6 = 25.50\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 1180.0\text{ kips}, P_{\text{uplift}} = -260.0\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{3.06} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P1 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 120 | 6 | `[69, 96, 108, 150, 132, 279]` | `[24, 33, 36, 33, 27, 36]` | 0.998 | 0.00069 | 0 / 0 LF | $0.00 | $134,903.44 |
| `IMPROVED_SPREAD` | 42 | 0 | `[123, 171, 186, 156, 114, 153]` | `[27, 39, 42, 33, 24, 30]` | 0.842 | 0.00175 | 80 / 669 LF | $9,500.00 | $72,282.07 |

## CR-P2 — Data Hall 2

- **Occupancy & Bearing Factor of Safety:** `Light Industrial, Public` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 3.5$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 85\text{ ksf}$) linearly interpolated from `13.5 ft` at STA `0.0 ft` (`F1`) to `9.0 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1400\text{ ksf}$) thickness = `12.0 ft`; Stratum III ($E_{s,III} = 3400\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 9.0\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.23%` $\rightarrow$ Exposure `S2` (`EM 1110-2-2000` Table 2-2); combined classes `['F1', 'S2', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 4500\text{ psi}$ ($211.00/CY) and $\text{w/cm} \le 0.45$.
- **Pad-Level Governing Constraint:** `BEARING`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$136,322.13` (bearing depth $D_f = 132\text{ in} = 11.00\text{ ft}$, dewatering = `6` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$77,075.36` excluding rig mobilisation (`$97,075.36` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 140\text{ pci}$, deepest treatment depth = `10 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`IMPROVED_SPREAD`** at **`$77,075.36`** (saves **`$59,246.77`** in pad construction cost before rig mobilisation).

### CR-P2 Selected Foundation Schedule and Engineering Checks (`IMPROVED_SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 13.5 | 646.6 | 888.3 | `126 × 126 × 27` | `0.002216` (`#7 @ 10"`) | 5.865 | **5.934** [6.11 / 5.80 / 5.57] | 98.8% | 0.818 | 0.00037 | 8 × 30" × 10' (Ra=0.356, qg=13945) | `BEARING` | $6,251.70 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 12.1 | 1250.8 | 1719.3 | `174 × 174 × 39` | `0.002150` (`#7 @ 7"`) | 5.949 | **6.024** [6.25 / 6.01 / 5.57] | 98.8% | 0.926 | 0.00037 | 15 × 30" × 9' (Ra=0.350, qg=14329) | `BEARING` | $13,020.80 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 10.9 | 1505.2 | 2070.2 | `189 × 189 × 42` | `0.002222` (`#8 @ 8"`) | 6.068 | **6.068** [6.31 / 6.09 / 5.59] | 100.0% | 0.976 | 0.00025 | 18 × 30" × 8' (Ra=0.356, qg=14428) | `BEARING` | $15,519.26 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 10.0 | 1038.8 | 1428.9 | `159 × 159 × 33` | `0.002473` (`#9 @ 12"`) | 5.917 | **5.987** [6.20 / 5.94 / 5.56] | 98.8% | 0.929 | 0.00088 | 12 × 30" × 8' (Ra=0.336, qg=14720) | `BEARING` | $9,879.10 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 9.3 | 551.2 | 757.9 | `117 × 117 × 24` | `0.002467` (`#7 @ 10"`) | 5.798 | **5.931** [6.09 / 5.76 / 5.58] | 97.8% | 0.802 | 0.00182 | 7 × 30" × 8' (Ra=0.361, qg=13633) | `BEARING` | $4,911.29 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 9.0 | 1749.0 | 2378.6 | `159 × 288 × 30` | `0.003439` (`#6 @ 4"`) | 5.500 | **5.583** [5.86 / 5.23 / 5.03] | 98.5% | 0.911 | 0.00182 | 22 × 30" × 8' (Ra=0.340, qg=13559) | `BEARING` | $17,993.22 |

### CR-P2 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 750.5\text{ kips}, H_x = 101.8\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.58} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 1749.0\text{ kips}, H_x = 101.8\text{ kips}, M_y = 932.8\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{7.49\text{ in}} \le B/6 = 26.50\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 1250.8\text{ kips}, P_{\text{uplift}} = -275.6\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{3.06} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P2 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 132 | 6 | `[186, 195, 105, 87, 63, 60]` | `[27, 39, 36, 30, 21, 18]` | 1.000 | 0.00129 | 0 / 0 LF | $0.00 | $136,322.13 |
| `IMPROVED_SPREAD` | 42 | 0 | `[126, 174, 189, 159, 117, 159]` | `[27, 39, 42, 33, 24, 30]` | 0.976 | 0.00182 | 82 / 687 LF | $9,500.00 | $77,075.36 |

## CR-P3 — Electrical Yard Building

- **Occupancy & Bearing Factor of Safety:** `Light Industrial, Public` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 3.5$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 210\text{ ksf}$) linearly interpolated from `5.5 ft` at STA `0.0 ft` (`F1`) to `7.0 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1700\text{ ksf}$) thickness = `16.0 ft`; Stratum III ($E_{s,III} = 3700\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 19.0\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.07%` $\rightarrow$ Exposure `S0` (`EM 1110-2-2000` Table 2-2); combined classes `['F1', 'S0', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 4000\text{ psi}$ ($196.00/CY) and $\text{w/cm} \le 0.50$.
- **Pad-Level Governing Constraint:** `SETTLEMENT`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$30,061.33` (bearing depth $D_f = 42\text{ in} = 3.50\text{ ft}$, dewatering = `0` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$48,531.58` excluding rig mobilisation (`$68,531.58` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 210\text{ pci}$, deepest treatment depth = `8 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`SPREAD`** at **`$30,061.33`** (saves **`$18,470.25`** in pad construction cost before rig mobilisation).

### CR-P3 Selected Foundation Schedule and Engineering Checks (`SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 5.5 | 439.2 | 603.4 | `102 × 102 × 21` | `0.002349` (`#7 @ 12"`) | 6.079 | **6.142** [6.14 / 6.01 / 5.75] | 99.0% | 0.765 | 0.00079 | None (0 piers) | `BEARING` | $2,316.24 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 6.0 | 849.6 | 1167.8 | `141 × 141 × 30` | `0.002363` (`#8 @ 11"`) | 6.154 | **6.371** [6.37 / 6.44 / 5.82] | 96.6% | 0.992 | 0.00079 | None (0 piers) | `SETTLEMENT` | $5,111.21 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 6.4 | 1022.4 | 1406.2 | `168 × 168 × 33` | `0.002421` (`#9 @ 12"`) | 5.216 | **6.579** [6.58 / 6.77 / 5.93] | 79.3% | 0.995 | 0.00007 | None (0 piers) | `SETTLEMENT` | $7,597.93 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 6.7 | 705.6 | 970.6 | `138 × 138 × 27` | `0.002446` (`#7 @ 9"`) | 5.335 | **6.349** [6.35 / 6.41 / 5.81] | 84.0% | 0.983 | 0.00011 | None (0 piers) | `SETTLEMENT` | $4,650.48 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 6.9 | 374.4 | 514.8 | `96 × 96 × 21` | `0.002029` (`#6 @ 10"`) | 5.850 | **6.120** [6.12 / 5.95 / 5.75] | 95.6% | 0.966 | 0.00042 | None (0 piers) | `SETTLEMENT` | $2,027.35 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 7.0 | 1188.0 | 1615.7 | `126 × 288 × 24` | `0.002879` (`#8 @ 11"`) | 4.714 | **5.806** [5.81 / 5.33 / 5.13] | 81.2% | 0.991 | 0.00042 | None (0 piers) | `SETTLEMENT` | $8,358.12 |

### CR-P3 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 509.8\text{ kips}, H_x = 69.1\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.62} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 1188.0\text{ kips}, H_x = 69.1\text{ kips}, M_y = 633.6\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{7.10\text{ in}} \le B/6 = 21.00\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 849.6\text{ kips}, P_{\text{uplift}} = -187.2\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{3.09} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P3 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 42 | 0 | `[102, 141, 168, 138, 96, 126]` | `[21, 30, 33, 27, 21, 24]` | 0.995 | 0.00079 | 0 / 0 LF | $0.00 | $30,061.33 |
| `IMPROVED_SPREAD` | 42 | 0 | `[102, 141, 153, 129, 96, 108]` | `[21, 30, 33, 27, 21, 21]` | 0.694 | 0.00136 | 54 / 432 LF | $9,500.00 | $48,531.58 |

## CR-P4 — Administration and Operations Building

- **Occupancy & Bearing Factor of Safety:** `Apartments, Office` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 3.0$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 130\text{ ksf}$) linearly interpolated from `6.0 ft` at STA `0.0 ft` (`F1`) to `9.5 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1600\text{ ksf}$) thickness = `15.0 ft`; Stratum III ($E_{s,III} = 3600\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 8.0\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.11%` $\rightarrow$ Exposure `S1` (`EM 1110-2-2000` Table 2-2); combined classes `['F1', 'S1', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 4000\text{ psi}$ ($196.00/CY) and $\text{w/cm} \le 0.50$.
- **Pad-Level Governing Constraint:** `BEARING`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$58,913.93` (bearing depth $D_f = 42\text{ in} = 3.50\text{ ft}$, dewatering = `0` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$40,576.95` excluding rig mobilisation (`$60,576.95` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 195\text{ pci}$, deepest treatment depth = `8 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`IMPROVED_SPREAD`** at **`$40,576.95`** (saves **`$18,336.99`** in pad construction cost before rig mobilisation).

### CR-P4 Selected Foundation Schedule and Engineering Checks (`IMPROVED_SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 6.0 | 384.3 | 527.9 | `90 × 90 × 21` | `0.001880` (`#6 @ 11"`) | 6.832 | **6.887** [7.03 / 6.54 / 6.57] | 99.2% | 0.682 | 0.00012 | 4 × 30" × 8' (Ra=0.349, qg=16496) | `BEARING` | $2,698.13 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 7.1 | 743.4 | 1021.9 | `126 × 126 × 30` | `0.001949` (`#7 @ 10"`) | 6.743 | **6.845** [7.05 / 6.65 / 6.45] | 98.5% | 0.718 | 0.00023 | 8 × 30" × 8' (Ra=0.356, qg=16033) | `BEARING` | $5,801.60 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 8.0 | 894.6 | 1230.4 | `138 × 138 × 30` | `0.002378` (`#8 @ 11"`) | 6.764 | **6.860** [7.07 / 6.71 / 6.44] | 98.6% | 0.773 | 0.00045 | 9 × 30" × 8' (Ra=0.334, qg=16884) | `BEARING` | $6,966.68 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 8.7 | 617.4 | 849.2 | `114 × 114 × 27` | `0.001925` (`#7 @ 11"`) | 6.841 | **6.841** [7.03 / 6.60 / 6.47] | 100.0% | 0.687 | 0.00062 | 7 × 30" × 8' (Ra=0.381, qg=15454) | `BEARING` | $4,704.22 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 9.3 | 327.6 | 450.4 | `87 × 87 × 18` | `0.002374` (`#6 @ 10"`) | 6.233 | **6.900** [7.03 / 6.54 / 6.59] | 90.3% | 0.598 | 0.00088 | 4 × 30" × 8' (Ra=0.374, qg=14288) | `BEARING` | $2,540.19 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 9.5 | 1039.5 | 1413.7 | `90 × 288 × 21` | `0.002205` (`#6 @ 9"`) | 5.775 | **5.856** [6.06 / 5.31 / 5.39] | 98.6% | 0.651 | 0.00088 | 13 × 30" × 8' (Ra=0.355, qg=13781) | `BEARING` | $8,366.13 |

### CR-P4 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 446.0\text{ kips}, H_x = 60.5\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.55} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 1039.5\text{ kips}, H_x = 60.5\text{ kips}, M_y = 554.4\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{7.08\text{ in}} \le B/6 = 15.00\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 743.4\text{ kips}, P_{\text{uplift}} = -163.8\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{3.01} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P4 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 42 | 0 | `[111, 186, 228, 195, 135, 267]` | `[21, 30, 33, 27, 21, 27]` | 0.994 | 0.00011 | 0 / 0 LF | $0.00 | $58,913.93 |
| `IMPROVED_SPREAD` | 42 | 0 | `[90, 126, 138, 114, 87, 90]` | `[21, 30, 30, 27, 18, 21]` | 0.773 | 0.00088 | 45 / 360 LF | $9,500.00 | $40,576.95 |

## CR-P5 — Logistics and Spares Warehouse

- **Occupancy & Bearing Factor of Safety:** `Warehouse` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 2.5$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 250\text{ ksf}$) linearly interpolated from `4.5 ft` at STA `0.0 ft` (`F1`) to `5.5 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1800\text{ ksf}$) thickness = `18.0 ft`; Stratum III ($E_{s,III} = 3800\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 21.0\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.05%` $\rightarrow$ Exposure `S0` (`EM 1110-2-2000` Table 2-2); combined classes `['F3', 'S0', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 5000\text{ psi}$ ($228.00/CY) and $\text{w/cm} \le 0.40$.
- **Pad-Level Governing Constraint:** `BEARING`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$14,992.23` (bearing depth $D_f = 42\text{ in} = 3.50\text{ ft}$, dewatering = `0` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$34,612.14` excluding rig mobilisation (`$54,612.14` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 230\text{ pci}$, deepest treatment depth = `8 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`SPREAD`** at **`$14,992.23`** (saves **`$19,619.91`** in pad construction cost before rig mobilisation).

### CR-P5 Selected Foundation Schedule and Engineering Checks (`SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 4.5 | 335.5 | 460.9 | `78 × 78 × 18` | `0.002068` (`#5 @ 8"`) | 7.941 | **8.531** [8.53 / 8.13 / 8.11] | 93.1% | 0.559 | 0.00068 | None (0 piers) | `BEARING` | $1,396.30 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 4.8 | 649.0 | 892.1 | `105 × 105 × 24` | `0.002488` (`#7 @ 10"`) | 8.477 | **8.617** [8.62 / 8.46 / 8.05] | 98.4% | 0.754 | 0.00068 | None (0 piers) | `BEARING` | $2,820.69 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 5.1 | 781.0 | 1074.2 | `114 × 114 × 27` | `0.002324` (`#6 @ 7"`) | 8.654 | **8.679** [8.68 / 8.59 / 8.06] | 99.7% | 0.867 | 0.00047 | None (0 piers) | `BEARING` | $3,465.57 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 5.3 | 539.0 | 741.4 | `96 × 96 × 21` | `0.002616` (`#6 @ 8"`) | 8.422 | **8.569** [8.57 / 8.33 / 8.05] | 98.3% | 0.845 | 0.00065 | None (0 piers) | `BEARING` | $2,251.58 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 5.4 | 286.0 | 393.3 | `72 × 72 × 18` | `0.001800` (`#5 @ 9"`) | 7.944 | **8.543** [8.54 / 8.07 / 8.15] | 93.0% | 0.752 | 0.00083 | None (0 piers) | `BEARING` | $1,196.15 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 5.5 | 907.5 | 1234.2 | `66 × 288 × 15` | `0.002728` (`#6 @ 10"`) | 6.875 | **7.049** [7.05 / 6.32 / 6.51] | 97.5% | 0.802 | 0.00083 | None (0 piers) | `BEARING` | $3,861.94 |

### CR-P5 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 389.4\text{ kips}, H_x = 52.8\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.49} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 907.5\text{ kips}, H_x = 52.8\text{ kips}, M_y = 484.0\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{6.87\text{ in}} \le B/6 = 11.00\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 649.0\text{ kips}, P_{\text{uplift}} = -143.0\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{2.95} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P5 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 42 | 0 | `[78, 105, 114, 96, 72, 66]` | `[18, 24, 27, 21, 18, 15]` | 0.867 | 0.00083 | 0 / 0 LF | $0.00 | $14,992.23 |
| `IMPROVED_SPREAD` | 42 | 0 | `[87, 114, 120, 105, 75, 66]` | `[18, 24, 27, 21, 18, 15]` | 0.667 | 0.00123 | 37 / 296 LF | $9,500.00 | $34,612.14 |

## CR-P6 — Data Hall 3

- **Occupancy & Bearing Factor of Safety:** `Light Industrial, Public` (`UFC 3-220-01` Table 2-3) $\rightarrow \text{FS}_{\text{bearing}} = 3.5$
- **Subsurface & Groundwater Profile:** Base of Stratum I (`CL-ML`, $E_{s,I} = 95\text{ ksf}$) linearly interpolated from `14.0 ft` at STA `0.0 ft` (`F1`) to `6.5 ft` at STA `77.0 ft` (`W1`); Stratum II (`SM`, $E_{s,II} = 1450\text{ ksf}$) thickness = `13.0 ft`; Stratum III ($E_{s,III} = 3450\text{ ksf}$) below; stabilised groundwater depth $D_{\text{GWT}} = 8.5\text{ ft}$.
- **Sulfate & Concrete Durability:** Maximum Stratum I water-soluble sulfate = `0.26%` $\rightarrow$ Exposure `S2` (`EM 1110-2-2000` Table 2-2); combined classes `['F1', 'S2', 'W1', 'C1']` (`UFGS 03 30 00` §2.5.2) require $f'_c = 4500\text{ psi}$ ($211.00/CY) and $\text{w/cm} \le 0.45$.
- **Pad-Level Governing Constraint:** `BEARING`
- **Shallow-vs.-Improved Decision & Cost Comparison:**
  - **Spread-Only Alternative (`SPREAD`):** `$113,106.63` (bearing depth $D_f = 102\text{ in} = 8.50\text{ ft}$, dewatering = `0` days at $4,200/day).
  - **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`):** `$75,045.38` excluding rig mobilisation (`$95,045.38` including $20,000 half-rig share of one $40,000 rig serving 2 pads; $D_f = 42\text{ in} = 3.50\text{ ft}$, $k_g = 155\text{ pci}$, deepest treatment depth = `11 ft`, includes 1 production modulus test at $9,500).
  - **Selected Strategy:** **`IMPROVED_SPREAD`** at **`$75,045.38`** (saves **`$38,061.25`** in pad construction cost before rig mobilisation).

### CR-P6 Selected Foundation Schedule and Engineering Checks (`IMPROVED_SPREAD`, $D_f = 42\text{ in}$)

| Unit | Type | STA (ft) | Stratum I Base (ft) | Service $P$ (kips) | Strength $P_u$ (kips) | Plan $B \times L \times T$ (in) | Reinf. $\rho$ (Bar @ Spacing) | Applied $q_{\text{net}}$ (ksf) | Allowable $q_{\text{allow,net}}$ (ksf) [Vesic / Meyerhof / Hansen] | Bearing Util. | Settlement $s$ (in) | Max Angular Distortion ($\le 0.00200$) | Piers ($N \times d_p \times L_p$, $R_a$, $q_g$ psf) | Governing Constraint | Unit Cost (USD) |
| :---: | :--- | :---: | :---: | ---: | ---: | :---: | :---: | ---: | :---: | :---: | ---: | :---: | :---: | :--- | ---: |
| `F1` | `ISOLATED_COLUMN` | 0.0 | 14.0 | 622.2 | 854.8 | `126 × 126 × 27` | `0.002130` (`#7 @ 10"`) | 5.644 | **5.900** [6.08 / 5.75 / 5.55] | 95.7% | 0.712 | 0.00053 | 8 × 30" × 11' (Ra=0.356, qg=13419) | `BEARING` | $6,446.01 |
| `F2` | `ISOLATED_COLUMN` | 24.0 | 11.7 | 1203.6 | 1654.4 | `171 × 171 × 36` | `0.002443` (`#6 @ 5"`) | 5.927 | **5.983** [6.20 / 5.95 / 5.55] | 99.1% | 0.863 | 0.00053 | 14 × 30" × 9' (Ra=0.338, qg=14650) | `BEARING` | $12,251.35 |
| `F3` | `ISOLATED_COLUMN` | 44.0 | 9.7 | 1448.4 | 1992.1 | `189 × 189 × 39` | `0.002507` (`#8 @ 8"`) | 5.839 | **6.035** [6.26 / 6.04 / 5.57] | 96.8% | 0.892 | 0.00035 | 17 × 30" × 8' (Ra=0.336, qg=14497) | `BEARING` | $15,044.26 |
| `F4` | `ISOLATED_COLUMN` | 60.0 | 8.2 | 999.6 | 1375.0 | `156 × 156 × 33` | `0.002360` (`#8 @ 10"`) | 5.915 | **5.946** [6.15 / 5.88 / 5.54] | 99.5% | 0.825 | 0.00080 | 12 × 30" × 8' (Ra=0.349, qg=14298) | `BEARING` | $9,549.53 |
| `F5` | `ISOLATED_COLUMN` | 72.0 | 7.0 | 530.4 | 729.3 | `114 × 114 × 24` | `0.002343` (`#7 @ 10"`) | 5.877 | **5.897** [6.06 / 5.71 / 5.57] | 99.7% | 0.711 | 0.00151 | 7 × 30" × 8' (Ra=0.381, qg=13277) | `BEARING` | $4,723.70 |
| `W1` | `CONTINUOUS_WALL` | 77.0 | 6.5 | 1683.0 | 2288.9 | `156 × 288 × 30` | `0.003230` (`#8 @ 8"`) | 5.394 | **5.518** [5.79 / 5.15 / 4.99] | 97.8% | 0.801 | 0.00151 | 22 × 30" × 8' (Ra=0.346, qg=13108) | `BEARING` | $17,530.53 |

### CR-P6 Continuous Shear-Wall Footing (`W1`) Lateral & Uplift Stability Checks

- **Sliding Check (`0.6D_PLUS_W`: $P = 722.2\text{ kips}, H_x = 97.9\text{ kips}$):** Base friction angle $\delta = \frac{2}{3}\phi' = 17.33^\circ$ (`EM 1110-2-2502` §4-5b); $\text{FS}_{\text{sliding}} = \mathbf{2.59} \ge 2.00$ (`UFC 3-220-01` §2-4.6.3) — **PASS**.
- **Overturning / Resultant Eccentricity Check (`SERVICE_D_PLUS_L_PLUS_W`: $P = 1683.0\text{ kips}, H_x = 97.9\text{ kips}, M_y = 897.6\text{ kip-ft}$):** Resultant eccentricity $e = \mathbf{7.47\text{ in}} \le B/6 = 26.00\text{ in}$ (`EM 1110-2-2502` §4-5a, middle-third rule) — **PASS**.
- **Net Wind Uplift Check (`UPLIFT_W` with `DEAD_ONLY`: $P_{\text{dead}} = 1203.6\text{ kips}, P_{\text{uplift}} = -265.2\text{ kips}$):** Resisted by $0.6 \times (W_{\text{footing}} + W_{\text{soil}} + P_{\text{dead}})$ (`AV-CR-2604_load_combination_memo.docx` §3); $\text{FS}_{\text{uplift}} = \mathbf{3.06} \ge 1.50$ (`UFC 3-220-20` §5-5 Eq. 5-35) — **PASS**.

### CR-P6 Competing Alternative Comparison Table (`SPREAD` vs. `IMPROVED_SPREAD`)

| Alternative | Bearing Depth $D_f$ (in) | Dewatering Days | Footing Widths `F1..W1` $B$ (in) | Footing Thicknesses `F1..W1` $T$ (in) | Max Settlement $s_{\max}$ (in) | Max Angular Distortion | Total Piers / Pier LF | Verification Test Cost | Total Pad Cost (USD) |
| :--- | :---: | :---: | :--- | :--- | :---: | :---: | :---: | ---: | ---: |
| `SPREAD` | 102 | 0 | `[234, 279, 219, 93, 69, 66]` | `[27, 39, 42, 30, 21, 21]` | 0.996 | 0.00163 | 0 / 0 LF | $0.00 | $113,106.63 |
| `IMPROVED_SPREAD` | 42 | 0 | `[126, 171, 189, 156, 114, 156]` | `[27, 36, 39, 33, 24, 30]` | 0.892 | 0.00151 | 80 / 678 LF | $9,500.00 | $75,045.38 |

